import logo from "./logo.svg";
import "./App.css";
import Header from "./Components/Home/Header";
import Home from "./Components/Home/Home";
import Cover from "./Components/Home/Cover";
import Footer from "./Components/Home/Footer";
import WhatsNew from "./Components/Home/WhatsNew";
import Signup from "./Components/Registration/Signup";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import pic from "./Components/Registration/color.jpg";
import Registration from "./Components/Registration/Registration";
import Login from "./Components/Login/Login";
import { createContext, useEffect, useReducer, useState } from "react";
import { initialState, reducer } from "./useReducer";
import OrgChart from "./Components/OrgChart/BasicOrgChart";
import LastSeen from "./Components/LastSeen/LastSeen";
import Update from "./Components/Update/Update";
import Admin from "./Components/Admin/Admin";
import BasicOrgChart from "./Components/OrgChart/BasicOrgChart";
import Check from "./Components/OrgChart/Check";

import ContentHeader from "./Components/Content/ContentHeader";
import LegalDomainIntroduction from "./Components/Content/LegalDomainIntroduction";
import OverviewOfLaw from "./Components/Content/OverviewOfLaw";
import ExploreMore from "./Components/Content/ExploreMore";
import KnowYourMentor from "./Components/Content/KnowYourMentor";
import OnBoarding from "./Components/Content/OnBoarding";
import ClientOnBoarding from "./Components/Content/ClientOnboarding";
import InductionPlanJava from "./Components/Content/InductionPlanJava";
import InductionPlanDotNet from "./Components/Content/InductionPlanDotNet";
import TrainingMaterials from "./Components/Content/TrainingMaterials";
import FunctionalDetails from "./Components/Content/FunctionalDetails";
import LAWhatsNext from "./Components/Content/LAWhatsNext";
import DayInDevelopersLife from "./Components/Content/DayInDevelopersLife";
import PullRequestGuidelines from "./Components/Content/PullRequestGuidelines";
import VersionOneGuidelines from "./Components/Content/VersionOneGuidelines";
import LADefinitionOfDone from "./Components/Content/LADefinitionOfDone";
import LADefinitionOfReady from "./Components/Content/LADefinitionOfReady";
import HowToImproveCodeQuality from "./Components/Content/HowToImproveCodeQuality";
import SolidPrinciples from "./Components/Content/SolidPrinciples";
import AgileGuidelines from "./Components/Content/AgileGuidelines";
import JavaCodeQualityGuidelines from "./Components/Content/JavaCodeQualityGuidelines";
import JavaCodeReviewChecklist from "./Components/Content/JavaCodeReviewChecklist";
import JavaStaticCodeAnalysis from "./Components/Content/JavaStaticCodeAnalysis";
import JavaPerformanceAnalysis from "./Components/Content/JavaPerformanceAnalysis";
import JavaUnitTestingFramework from "./Components/Content/JavaUnitTestingFramework";
import JavaCodeReferenceSlice from "./Components/Content/JavaCodeReferenceSlice";
import Content from "./Components/Content/Content";
import NetCodeQualityGuidelines from "./Components/Content/NetCodeQualityGuidelines";
import NetCodeReviewChecklist from "./Components/Content/NetCodeReviewChecklist";
import NetCodeReferenceSlice from "./Components/Content/NetCodeReferenceSlice";
import NetStaticCodeAnalysis from "./Components/Content/NetStaticCodeAnalysis";
import NetPerformanceAnalysis from "./Components/Content/NetPerformanceAnalysis";
import NetUnitTestingFramework from "./Components/Content/NetUnitTestingFramework";
import SecurityAwareness from "./Components/Content/SecurityAwareness";
import OthersCodeQualityGuidelines from "./Components/Content/OthersCodeQualityGuidelines";
import OthersCodeReviewChecklist from "./Components/Content/OthersCodeReviewChecklist";
import OthersCodeReferenceSlice from "./Components/Content/OthersCodeReferenceSlice";
import OthersStaticCodeAnalysis from "./Components/Content/OthersStaticCodeAnalysis";
import OthersPerformanceAnalysis from "./Components/Content/OthersPerformanceAnalysis";
import OthersUnitTestingFramework from "./Components/Content/OthersUnitTestingFramework";
import OJRWhatsNext from "./Components/Content/OJRWhatsNext";
import ModuleLead from "./Components/Content/ModuleLead";
import ProjectLead from "./Components/Content/ProjectLead";
import JavaEvaluationTemplate from "./Components/Content/JavaEvaluationTemplate";
import NetEvaluationTemplate from "./Components/Content/NetEvaluationTemplate";
import PMRTemplate from "./Components/Content/PMRTemplate";
import RolesResponsibilitiesManager from "./Components/Content/RolesResponsibilitiesManager";
import CIIIgniter from "./Components/Content/CIIIgniter";
import PMHWhatsNext from "./Components/Content/PMHWhatsNext";
import BCP from "./Components/Content/BCP";
import BCSecurityPolicy from "./Components/Content/BCSecurityPolicy";
import Trutime from "./Components/Content/Trutime";
import Timesheet from "./Components/Content/Timesheet";
import OrgMandatoryCourses from "./Components/Content/OrgMandatoryCourses";
import DefectPreventionPlan from "./Components/Content/DefectPreventionPlan";
import BCWhatsNext from "./Components/Content/BCWhatsNext";
import LNTT from "./Components/Content/LNTT";
import ContentNewHeader from "./Components/Content/ContentNewHeader";
import Charts from "./Components/Admin/Charts";

import ImageUploadForm from "./Components/Admin/ImageUploadForm";
import AddAdmin from "./Components/Admin/AddAdmin";

export const UserContext = createContext();

function App() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const [isAdmin, setIsAdmin] = useState(false);
  const [isAssociate, setIsAssociate] = useState(false);

  useEffect(() => {
    if (localStorage.getItem("Role") === "Admin") {
      setIsAdmin(true);
    }
    if (localStorage.getItem("Role") === "Associate") {
      setIsAssociate(true);
    }
  });

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/check" element={<Check />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/update" element={<Update />} />
        <Route path="/" element={<Home />} />
        <Route path="/OrgChart" element={<BasicOrgChart />} />
        <Route path="/content" element={<LegalDomainIntroduction />} />
        <Route
          path="/legalDomainIntroduction"
          element={<LegalDomainIntroduction />}
        />
        <Route path="/overviewOfLaw" element={<OverviewOfLaw />} />
        <Route path="/exploremore" element={<ExploreMore />} />
        <Route path="/knowyourmentor" element={<KnowYourMentor />} />
        <Route path="/onboarding" element={<OnBoarding />} />
        <Route path="/clientOnboarding" element={<ClientOnBoarding />} />
        <Route path="/inductionPlanJava" element={<InductionPlanJava />} />
        <Route path="/inductionPlanDotNet" element={<InductionPlanDotNet />} />
        <Route path="/trainingMaterials" element={<TrainingMaterials />} />
        <Route path="/functionalDetails" element={<FunctionalDetails />} />
        <Route path="/laWhatsNext" element={<LAWhatsNext />} />
        <Route path="/dayInDevelopersLife" element={<DayInDevelopersLife />} />
        <Route
          path="/pullRequestGuidelines"
          element={<PullRequestGuidelines />}
        />
        <Route
          path="/versionOneGuidelines"
          element={<VersionOneGuidelines />}
        />
        <Route path="/laDefinitionOfDone" element={<LADefinitionOfDone />} />
        <Route path="/laDefinitionOfReady" element={<LADefinitionOfReady />} />
        <Route
          path="/howToImproveCodeQuality"
          element={<HowToImproveCodeQuality />}
        />
        <Route path="/solidPrinciples" element={<SolidPrinciples />} />
        <Route path="/agileGuideline" element={<AgileGuidelines />} />
        <Route
          path="/javaCodeQualityGuidelines"
          element={<JavaCodeQualityGuidelines />}
        />
        <Route
          path="/javaCodeReviewChecklist"
          element={<JavaCodeReviewChecklist />}
        />
        <Route
          path="/javaCodeReferenceSlice"
          element={<JavaCodeReferenceSlice />}
        />
        <Route
          path="/javaStaticCodeAnalysis"
          element={<JavaStaticCodeAnalysis />}
        />
        <Route
          path="/javaPerformanceAnalysis"
          element={<JavaPerformanceAnalysis />}
        />
        <Route
          path="/javaUnitTestingFramework"
          element={<JavaUnitTestingFramework />}
        />
        <Route
          path="/netCodeQualityGuidelines"
          element={<NetCodeQualityGuidelines />}
        />
        <Route
          path="/netCodeReviewChecklist"
          element={<NetCodeReviewChecklist />}
        />
        <Route
          path="/netCodeReferenceSlice"
          element={<NetCodeReferenceSlice />}
        />
        <Route
          path="/netStaticCodeAnalysis"
          element={<NetStaticCodeAnalysis />}
        />
        <Route
          path="/netPerformanceAnalysis"
          element={<NetPerformanceAnalysis />}
        />
        <Route
          path="/netUnitTestingFramework"
          element={<NetUnitTestingFramework />}
        />
        <Route path="/securityAwareness" element={<SecurityAwareness />} />
        <Route
          path="/othersCodeQualityGuidelines"
          element={<OthersCodeQualityGuidelines />}
        />
        <Route
          path="/othersCodeReviewChecklist"
          element={<OthersCodeReviewChecklist />}
        />
        <Route
          path="/othersCodeReferenceSlice"
          element={<OthersCodeReferenceSlice />}
        />
        <Route
          path="/othersStaticCodeAnalysis"
          element={<OthersStaticCodeAnalysis />}
        />
        <Route
          path="/othersPerformanceAnalysis"
          element={<OthersPerformanceAnalysis />}
        />
        <Route
          path="/othersUnitTestingFramework"
          element={<OthersUnitTestingFramework />}
        />
        <Route path="/ojrWhatsNext" element={<OJRWhatsNext />} />
        <Route path="/moduleLead" element={<ModuleLead />} />
        <Route path="/projectLead" element={<ProjectLead />} />
        <Route
          path="/javaEvaluationTemplate"
          element={<JavaEvaluationTemplate />}
        />
        <Route
          path="/netEvaluationTemplate"
          element={<NetEvaluationTemplate />}
        />
        <Route path="/pmrTemplate" element={<PMRTemplate />} />
        <Route
          path="/rolesResponsibilitiesManager"
          element={<RolesResponsibilitiesManager />}
        />
        <Route path="/ciiIgniter" element={<CIIIgniter />} />
        <Route path="/pmhWhatsnext" element={<PMHWhatsNext />} />
        <Route path="/bcp" element={<BCP />} />
        <Route path="/bcSecurityPolicy" element={<BCSecurityPolicy />} />
        <Route path="/trutime" element={<Trutime />} />
        <Route path="/timesheet" element={<Timesheet />} />
        <Route path="/orgMandatoryCourses" element={<OrgMandatoryCourses />} />
        <Route
          path="/defectPreventionPlan"
          element={<DefectPreventionPlan />}
        />
        <Route path="/bcWhatsNext" element={<BCWhatsNext />} />
        <Route path="/lntt" element={<LNTT />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/login" element={<Login />} />
        <Route path="/update" element={<Update />} />
        <Route path="/charts" element={<Charts />} />
        <Route path="/ImageUploadForm" element={<ImageUploadForm />} />
        <Route path="/addadmin" element={<AddAdmin />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
