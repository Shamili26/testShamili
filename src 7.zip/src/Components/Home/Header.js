import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./Header.css";
import "./Style.css";
import logo from "./logo.png";
import axios from "axios";

function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState("");
  const [role, setRole] = useState("");

  const [logState, setLogState] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  useEffect(() => {
    setIsLoggedIn(localStorage.getItem("isLoggedIn"));
    setRole(localStorage.getItem("Role"));

    if (isLoggedIn == "true") {
      setLogState(true);
    }
    if (role == "Admin") {
      setIsAdmin(true);
    }

    console.log(isLoggedIn);
    console.log(role);
  });

  const ManageLog = () => {
    console.log("ManageLog");
    //let count = 1;
    axios
      .get(
        "http://localhost:8081/logout/" +
          localStorage.getItem("username") +
          "/" +
          //localStorage.getItem("count")
          1
      )
      .then((response) => {
        alert("logged out successfully");
      });
    console.log(localStorage.getItem("username"));
    console.log(localStorage.getItem("count"));
    localStorage.setItem("isLoggedIn", "");
    localStorage.setItem("Role", "");
    localStorage.setItem("username", "");
    localStorage.setItem("count", "");
    setLogState(false);
    setIsAdmin(false);
  };
  const [navbar1, setNavbar] = useState(false);

  const changeScroll = () => {
    if (window.scrollY >= 80) {
      setNavbar(true);
    } else {
      setNavbar(false);
    }
  };
  window.addEventListener("scroll", changeScroll);
  return (
    <nav
      className={
        navbar1
          ? "navbar active navbar-expand-md bg-dark navbar-dark p-sm-3 sticky-top .bg-gradient  "
          : "navbar  navbar-expand-md bg-dark navbar-dark p-sm-3 sticky-top .bg-gradient "
      }
      style={{
        fontWeight: 450,
        fontSize: 20,
        position: "fixed",
        width: "100%",
        display: "block",
      }}
    >
      <div className="container-fluid">
        <Link to="/">
          <img src={logo} style={{ height: 60, width: 60 }} />
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div
          className="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul className="navbar-nav d-flex">
            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to={isAdmin ? "/addadmin" : "http://localhost:3000/"}
                className={isAdmin ? "nav-link" : "nav-link d-none"}
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                AddAdmin
              </Link>
            </li>

            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to={isAdmin ? "/admin" : "http://localhost:3000/"}
                className={isAdmin ? "nav-link" : "nav-link d-none"}
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                Panel
              </Link>
            </li>

            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to="/"
                className="nav-link "
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                Home
              </Link>
            </li>
            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to={logState ? "/content" : "http://localhost:3000/login"}
                className="nav-link "
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                Content
              </Link>
            </li>
            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to={
                  logState
                    ? isAdmin
                      ? "/ImageUploadForm"
                      : "OrgChart"
                    : "http://localhost:3000/login"
                }
                className="nav-link "
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                {isAdmin ? "Whats New" : "Org Chart"}
              </Link>
            </li>
            <li
              className="nav-item "
              style={{ paddingLeft: 30, paddingRight: 30 }}
            >
              <Link
                to={logState ? "/update" : "/register"}
                className={"nav-link"}
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                }}
              >
                {logState ? "Update" : "Register"}
              </Link>
            </li>
            <li className="nav-item ">
              <Link
                to={logState ? "/" : "/login"}
                className={"nav-link "}
                aria-current="page"
                style={{
                  color: navbar1 ? "white " : "black",
                  fontWeight: "bold",
                  paddingLeft: 30,
                  paddingRight: 30,
                }}
              >
                {logState ? localStorage.getItem("username") : "Login"}
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/login"
                className={logState ? "nav-link" : "nav-link d-none "}
                onClick={ManageLog}
                aria-current="page"
                style={{
                  color: navbar1 ? "white" : "black",
                  fontWeight: "bold",
                }}
              >
                LogOut
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Header;
