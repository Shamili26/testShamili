import Cover from "./Cover";
import Header from "./Header";
import Footer from "./Footer";
import WhatsNew from "./WhatsNew";

function Home() {
  return (
    <>
      <Header />
      <Cover />
      <WhatsNew />
      <Footer />
    </>
  );
}

export default Home;
