import React, { useContext } from "react";
import "./Style.css";
import "./Home.css";
import { Link } from "react-router-dom";

function Cover(props) {
  return (
    <div className="masthead">
      <div className="color-overlay1 d-flex justify-content-center align-items-center d-block">
        <div className="HomeCap d-inline">
          <h1 className="jsx-2391468037 title" style={{ color: "white" }}>
            LA PLAYBOOK <span className="d-lg-block"></span>
          </h1>
        </div>
      </div>
      <div className="color-overlay d-flex justify-content-center align-items-center d-block">
        <div className="HomeBut d-inline"></div>
      </div>
    </div>
  );
}

export default Cover;
