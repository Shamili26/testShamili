import React, { useState, useEffect } from "react";
import axios from "axios";
import "jquery/dist/jquery.min.js";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

function WhatsNew(props) {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8081/getAllFiles");
      setData(response.data.slice(0, 3));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  return (
    <div className="container mt-5 mb-5 shadow-lg border pb-5 rounded">
      <p className="h1 text-center font-weight-bold pt-5">What's New</p>
      <div className="row">
        <div className="col-md-7">
          <div className="container pt-4">
            <div className="row justify-content-center">
              <div
                id="carouselExampleCaptions"
                className="carousel slide"
                data-bs-ride="carousel"
              >
                <div className="carousel-indicators">
                  {data.map((_, index) => (
                    <button
                      key={index}
                      type="button"
                      data-bs-target="#carouselExampleCaptions"
                      data-bs-slide-to={index}
                      className={index === 0 ? "active" : ""}
                      aria-label={`Slide ${index + 1}`}
                    ></button>
                  ))}
                </div>

                <div className="carousel-inner">
                  {data.map((item, index) => (
                    <div
                      key={index}
                      className={`carousel-item ${index === 0 ? "active" : ""}`}
                    >
                      <a
                        href={item.caption}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <img
                          src={`data:${item.fileType};base64,${item.data}`}
                          className="d-block w-100"
                          alt="..."
                          style={{
                            maxWidth: "100%",
                            maxHeight: "300px",
                            objectFit: "contain",
                            cursor: "pointer",
                          }}
                        />
                      </a>

                      <div className="carousel-caption d-none d-md-block">
                        <h2>{item.title}</h2>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  className="carousel-control-prev"
                  type="button"
                  data-bs-target="#carouselExampleCaptions"
                  data-bs-slide="prev"
                >
                  <span
                    className="carousel-control-prev-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="visually-hidden">Previous</span>
                </button>

                <button
                  className="carousel-control-next"
                  type="button"
                  data-bs-target="#carouselExampleCaptions"
                  data-bs-slide="next"
                >
                  <span
                    className="carousel-control-next-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="visually-hidden">Next</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="container pt-4">
            <div className="row justify-content-center">
              <p
                style={{
                  fontSize: "18px",
                  color: "darkblue",
                  fontFamily: "Arial, sans-serif",
                  textAlign: "center",
                  fontWeight: "bold",
                  margin: "auto",
                  paddingTop: "70px",
                }}
              >
                Hi! welcome to LAPLAYBOOK. Platform for all the data you need
                about LEXISNEXIS. View our daily updates here. Click on the
                images to know more about them.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default WhatsNew;
