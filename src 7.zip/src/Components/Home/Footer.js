import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import logo from "./logo.png"
import "./Style.css"
import affinity from "./affinity.png"
import c1 from "./c1.png";
import meta from "./meta.jpg";
import pb from "./pb.png";



function Footer()
{
    
        return (
            <footer>
            <div className="container-fluid text-center">
              <div className="m-auto align-item-center pt-4 pb-4">
             
          
                
                <div className="row grid">
                  <div className="col-4" />
                  <div className="col-4">
                    <div className="row">
                      <div className="col-md-3" >
                       <Link to ="https://getbootstrap.com/docs/5.0/getting-started/introduction/"><img src={affinity} style={{ height: 80, width: 80 }} /></Link>
                      </div>
                      <div className="col-md-3" >
                      <Link to ="https://getbootstrap.com/docs/5.0/getting-started/introduction/"> <img src={c1} style={{ height: 80, width: 80 }} /></Link>
                      </div>
                      <div className="col-md-3" >
                      <Link to ="https://getbootstrap.com/docs/5.0/getting-started/introduction/"><img src={meta} style={{ height: 80, width: 80 }} /></Link>
                      </div>
                      <div className="col-md-3" >
                      <Link to ="https://getbootstrap.com/docs/5.0/getting-started/introduction/"><img src={pb} style={{ height: 80, width: 80 }} /></Link>
                      </div>
                    </div>
                  </div>
                  <div className="col-4" />
                </div>
                <br />
                
               
              </div>
            </div>
          </footer>
          
          
    );
}

export default Footer;