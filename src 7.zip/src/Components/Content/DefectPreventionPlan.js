import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function DefectPreventionPlan() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/DefectPreventionPlan').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section id="defectpreventionplan" className="defectpreventionplan">
                <div className="container">

                    <div className="section-title">
                        <span>Defect Prevention Plan</span>
                        <h2>Defect Prevention Plan</h2>
                        <p align="justify"><em>Defect Prevention Plan helps us to identify the actual reason on the Defect and to take necessary preventive actions to make sure that it will not happen again.</em></p>
                        <br />
                        <p align="justify">To explore more about the Defect Prevention Plan, Please go through the below course</p>
                        <br />
                        <table className="table table-sm table-striped" style={{ width: "80%", align: "center" }}>
                            <thead>
                                <tr>
                                    <th scope="col">Course Code</th>
                                    <th scope="col">Course Name</th>
                                    <th scope="col">Applicability</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td align="center">PS0242</td>
                                    <td align="center">Defect Prevention Plan</td>
                                    <td align="center">All Associates</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    {/*   <!--<img src="assets\img\LA Product suite.png" className="img-thumbnail" alt="Responsive image">--></img>*/}
                </div>
            </section>
            <Footer/>

        </>
    )
}