import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function NetPerformanceAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetPerformanceAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        
        </>
    )
}