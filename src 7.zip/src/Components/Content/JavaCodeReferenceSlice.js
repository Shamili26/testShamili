import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaCodeReferenceSlice()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaCodeReferenceSlice').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="java-codereferenceslice" className="java-codereferenceslice">
                    <div className="container">
                        <div className="section-title">
                            <span>Code Reference Slice</span>
                            <h2>Code Reference Slice</h2>
                        </div>
                        <ul className="nav nav-tabs" id="java-codereferenceslice-flters">
                            <li className="active"><a href="#swagger-crs">Swagger</a></li>
                            <li><a href="#java-crs">Java</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="swagger-crs" className="tab-pane fade in active">
                                <h3>Swagger</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={33cda73d-7d98-4cb1-ace0-b4d904759a34}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                            <div id="java-crs" className="tab-pane fade in active">
                                <h3>Java</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1c75c9e1-f66b-48fb-91a7-663cf60c2179}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer/>
        </>
    )
}