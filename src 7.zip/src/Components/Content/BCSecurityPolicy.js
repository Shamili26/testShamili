
import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function BCSecurityPolicy() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/BCSecurityPolicy').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <security id="bc-securitypolicy" className="bc-securitypolicy">
                <h3>Security Policy</h3>
                <p>
                    <em>Phishing is an attempt to acquire sensitive information such as usernames, passwords, business sensitive information, credit card details and sometimes, indirectly money as well. Its most often intended with malicious reasons, masquerading as a trustworthy entity in an electronic communication.</em>
                </p>
                <img align="center" src="assets/img/Phising_img.png" width="724px" height="380px" className="center" alt="Responsive image" />
                <br />
                <br />
                <ul>
                    <li>
                        <strong>EXTRA VIGILANCE: COVID-19 SCAM</strong> Indian government officials are warning citizens to expect a widespread COVID-19 phishing attack. The phishing email scam offers free testing to residents in major Indian cities. The COVID-19 phishing email is designed to steal personal data and financial information. The bad actors impersonate local government officials known to be tasked with supporting local testing and government aid distribution. The attackers create fake email addresses with these officials&rsquo; names or spoof the government authorities&rsquo; IDs. (Spoofing is the act of disguising a communication from an unknown source as being from a known, trusted source.)</li>
                    <li>A cyber security agency with knowledge of this specific attack warns: Do not open attachments in unsolicited emails. Do not click on URLs in an unsolicited email, even if the link seems benign. Cyber security agencies have seen multiple attacks related to COVID-19.</li>
                    <li>Every COVID-19 email should be read with skepticism. Question the message&rsquo;s intent.</li>
                    <li>Review all parts of the message before acting. Cognizant proactively blocks emails from malicious actors. Please use the ReportSpam action in Outlook to report this and any other suspected phishing attacks.</li>
                </ul>
                <h4>Follow below guidance if you receive a suspicious email:</h4>
                <ul>
                    <li>1. Approach Unsolicited Emails with Skepticism: Interacting with a phishing email can launch software, install ransomware, steal your stored credentials, etc. Be aware that an email related to COVID-19 is likely a phishing attempt.</li>
                    <li>2. Remain Vigilant: Fraudulent messages around vaccine information, special offers, breaking news, etc. are all designed to deceive you into acting on the promises of the email.</li>
                    <li>3. Question the Message: Cognizant and legitimate organizations will never ask for your credentials or sensitive information.</li>
                    <li>4. Analyze the Email: Question the message&rsquo;s intent&mdash; see where it originated from, if it was a legitimate domain, and analyze all the variables about the message before acting.</li>
                    <li>5. Attachments: Never open or download attachments from unknown sources.</li>
                    <li>6. Links: While Cognizant is using email to communicate with associates, the messages are also available on BeCognizant. You will not be directed to click a link or download a file from the email. Cognizant communications will instead direct you to a BeCognizant page.</li>
                    <li>7. Videos: Information such as ways you can protect yourself and your family should be viewed using personal devices on known, trusted websites. If a file promising this information is in a video attached to an email, do not open it. Report it.</li>
                    <li>Report suspicious emails using the ReportSpam plugin in Outlook or report by sending the suspicious email as an attachment to <a href="mailto:reportspam@cognizant.com">reportspam@cognizant.com</a></li>
                </ul>
                <br />
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6f207777-646d-4222-860f-0657d2110db6}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                <h3>Curious to know more !!</h3>
                <p align="center">
                    Associates can explore more about Security Policy by go through the below courses
                </p>
                <br />
                <table className="table table-sm table-striped" style={{ width: "50%", align: "center" }}>
                    <thead>
                        <tr>
                            <th scope="col">Course Code</th>
                            <th scope="col">Course Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>CIEHC156</td>
                            <td>Secure Application Development</td>
                        </tr>
                        <tr>
                            <td>CIEHC074</td>
                            <td>Secure Coding Practices in Java</td>
                        </tr>
                        <tr>
                            <td>BDODA2</td>
                            <td>Secure Coding Practices</td>
                        </tr>
                    </tbody>
                </table>

            </security>
            <Footer/>

        </>
    )
}