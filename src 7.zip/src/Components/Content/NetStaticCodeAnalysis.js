import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function NetStaticCodeAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetStaticCodeAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>

        <section id="net-staticcodeanalysis" className="net-staticcodeanalysis">
                    <div className="container">
                        <div className="section-title">
                            <span>Static Code Analysis</span>
                            <h2>Static Code Analysis</h2>
                        </div>
                        <ul className="nav nav-tabs" id="net-staticcodeanalysis-flters">
                            <li><a href="#csharp-sca">C#</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="csharp-sca" className="tab-pane fade in active">
                                <h3>C#</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f2b282fe-56c9-4983-a874-6d8fc7d8a045}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}