import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaPerformanceAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaPerformanceAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="java-performanceanalysis" className="java-performanceanalysis">
                    <div className="container">
                        <div className="section-title">
                            <span>Java Performance analysis</span>
                            <h2>Java Performance analysis</h2>
                        </div>
                        <ul className="nav nav-tabs" id="java-performanceanalysis-flters">
                            <li><a href="#jprofiler-crs">JProfiler</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="jprofiler-crs" className="tab-pane fade in">
                                <h3>JProfiler</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={ce9cc7b9-9f3b-4391-bfac-9a9e62ea2d4b}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>

                </section>

                <Footer/>
        </>
    )
}