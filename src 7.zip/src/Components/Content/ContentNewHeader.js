import Header from "../Home/Header";
import ContentHeader from "./ContentHeader";
import  pic from './adminblue.jpg'
export default function ContentNewHeader()
{
    return(
        <>
        <div style={{backgroundImage: `url(${pic})`, backgroundRepeat:"no-repeat", backgroundSize:"cover"}}>
      <Header/>
        <div style={{paddingTop:80}}>
        <ContentHeader/>
        </div>
        </div>
        </>
    )
}