import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OthersStaticCodeAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OthersStaticCodeAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="others-staticcodeanalysis" className="others-staticcodeanalysis">
                    <div className="container">
                        <div className="section-title">
                            <span>Static Code Analysis</span>
                            <h2>Static Code Analysis</h2>
                            <p><em>To build enterprise applications, which are reliable, scalable and maintainable, it is important for
                                development teams to adopt proven design techniques and good coding standards. The adoption of
                                coding standards results in code consistency, which makes it easier to understand, develop and maintain
                                the application. In addition by being aware of and following the right coding techniques at a granular
                                level, the programmer can make the code more efficient and performance effective.Static code analysis is a method
                                of debugging by examining source code before a program is run. It’s done by analyzing a set of code against
                                a set (or multiple sets) of coding rules.</em></p>
                        </div>
                        <ul className="nav nav-tabs" id="others-staticcodeanalysis-flters">
                            <li><a href="#pylint">Pylint for Eclipse</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="pylint" className="tab-pane fade in">
                                <h3>Pylint for Eclipse</h3>
                                <p>Pylint is a Python static code analysis tool which looks for programming errors, helps enforcing a coding standard, sniffs for code smells and offers simple refactoring suggestions.</p>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={0068eba4-f112-44c5-83a1-562ff987d0cc}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}