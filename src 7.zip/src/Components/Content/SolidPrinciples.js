import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function SolidPrinciples() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/SolidPrinciples').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section className="solidprinciples" id="solidprinciples">
                <h3>Solid Principles</h3>
                <p align="center">
                    <iframe src="Downloads\On_Job_Reference\General\SOLID Principles.pdf" width="722" height="565">Office<a />.</iframe></p>
            </section >
            <Footer/>

        </>
    )
}