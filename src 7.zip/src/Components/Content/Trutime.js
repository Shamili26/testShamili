import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function Trutime() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/Trutime').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section id="trutime" className="trutime">
                <h3>Trutime Guidelines</h3>
                <p><em>The TruTime app records your work hours for each day and provides a fortnightly, monthly and yearly average of time spent at work. While in office, work hours are captured automatically from your access card swipe-in and swipe-out. While working from home, work hours must be updated/applied using the TopUp feature in the TruTime app.

                    As a majority of us continue to work from home, it is imperative that each associate record work hours using the TopUp feature on the TruTime app regularly. We have noticed a dip in the number of working hours for some associates in the past couple of months and urge you to maintain compliance. Please note that TruTime compliance is mandatory for all India associates.</em></p>
                <p>
                    <ul>
                        <li>Log in to TruTime through One Cognizant (1C) and record your daily work hours using TopUp. Your updated work-from-home time will need to be approved by your project manager.</li>
                        <li>If you are working from a Cognizant facility, always register your first swipe-in and last swipe-out of the day at the TruTime Readers.</li>
                        <br />
                        <h5>Submission and approval timelines</h5>
                        <li>TopUp hours can be updated/applied only for the previous 15 calendar days from the current date. TopUp hours applied over and above the auto-approved hours will be routed to your respective project manager for approval.</li>
                        <li>TopUp hours that remain unapproved for the first fortnight of the previous month will be auto rejected at 10:30 a.m. on the 4th of every month.</li>
                        <li>TopUp hours that remain unapproved for the second fortnight of the previous month will be auto rejected at 10:30 a.m. on the 18th of every month.</li>
                        <li>If TopUp hours are rejected, they can be resubmitted within two business days from the date of rejection. TopUp cannot be resubmitted if rejected for the second time.</li>
                        <li>For more information, search for TruTime on Navigator <a href="https://onecognizant.cognizant.com/?globalappid=587">here</a> or access the user guide <a href="https://ecm.cognizant.com/cs/idcplg?IdcService=GET_FILE&RevisionSelectionMethod=Latest&dDocName=ctsecmin_25583931&Rendition=web&allowInterrupt=1&noSaveAs=1&fileName=ctsecmin_25583931.pdf">here</a>.</li>
                    </ul>
                </p>
            </section>

            <Footer/>

        </>
    )
}