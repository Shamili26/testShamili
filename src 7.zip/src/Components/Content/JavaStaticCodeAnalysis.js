import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaStaticCodeAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaStaticCodeAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="java-staticcodeanalysis" className="java-staticcodeanalysis">
                    <div className="container">
                        <div className="section-title">
                            <span>Static Code Analysis</span>
                            <h2>Static Code Analysis</h2>
                            <p><em>To build enterprise applications, which are reliable, scalable and maintainable, it is important for
                                development teams to adopt proven design techniques and good coding standards. The adoption of
                                coding standards results in code consistency, which makes it easier to understand, develop and maintain
                                the application. In addition by being aware of and following the right coding techniques at a granular
                                level, the programmer can make the code more efficient and performance effective.Static code analysis is a method
                                of debugging by examining source code before a program is run. It’s done by analyzing a set of code against
                                a set (or multiple sets) of coding rules.</em></p>
                        </div>
                        <ul className="nav nav-tabs" id="java-staticcodeanalysis-flters">
                            <li><a href="#sonarlint">Sonar Lint for Eclipse</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="sonarlint" className="tab-pane fade in active">
                                <h3>Sonar Lint for Eclipse</h3>
                                <p>SonarLint is an IDE extension that helps you detect and fix quality issues as you write code.
                                    Like a spell checker, SonarLint squiggles flaws so that they can be fixed before committing code.</p>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={290a7a84-b8ac-41ff-b7be-5fec67fb357d}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}