import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OthersCodeReferenceSlice() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OthersCodeReferenceSlice').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section id="others-codereferenceslice" className="others-codereferenceslice">
                <div className="container">
                    <div className="section-title">
                        <span>Code Reference Slice</span>
                        <h2>Code Reference Slice</h2>
                    </div>
                    <ul className="nav nav-tabs" id="others-codereferenceslice-flters">
                        <li><a href="#solr-crs">Solr</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="solr-crs" className="tab-pane fade in">
                            <h3>Solr</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={56533ec2-495e-4d2a-babd-4a4a7c9933a0}&amp;action=embedview&amp;wdStartOn=1&amp;wdEmbedCode=0" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            <Footer/>

        </>
    )
}