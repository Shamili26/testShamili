import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function LNTT() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/LNTT').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <div className="section-title">
                <div id="lntt" className="tab-pane fade in active">
                    <h2>Technical Materials</h2>
                </div>
                <ul className="nav nav-tabs" id="training-flters">
                    <li className="active"><a href="#lntt">Lexis Nexis Tech Talk</a></li>
                </ul>
                <p className="tab-content">
                    <h5>GraphQL</h5>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={358140ab-eb06-4552-97e7-b78877ffe387}&amp;action=embedview" width="722" height="565" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                    <h3>Debezium</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9c175e2d-df98-47fd-80ae-65d2df48aae9}&amp;action=embedview" width="722" height="565">Debezium<a />.</iframe></p>
                    <h3>AWSMacie</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1dc344f8-360e-4644-99b7-cf5352392cc8}&amp;action=embedview" width="722px" height="565px" frameborder="0"><a>AWSMacie</a>.</iframe></p>
                    <h3>AzureAPIManagement</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={a7d838e1-e046-4dd7-8de4-4561c801c853}&amp;action=embedview" width="722" height="565">AzureAPIManagement<a />.</iframe></p>

                    <h3>LightHouse</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f22c3b7a-eedf-48aa-8690-426c1dea4d6f}&amp;action=embedview" width="772" height="565" frameborder="0"><a>LightHouse</a>.</iframe></p>

                    <h3>Yarn</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9f138012-17a4-41cb-9af3-a988c37a6336}&amp;action=embedview" width="772" height="565" frameborder="0"><a>Yarn</a>.</iframe></p>

                    <h3>AzureDoor</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e5bb125a-df5f-4c1b-a436-9964c9ab68a7}&amp;action=embedview" width="772" height="565" frameborder="0"><a>AzureDoor</a>.</iframe></p>


                    <h3>Application Gateway</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/2116805_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={984cf91b-43af-4151-9ced-885ff15bd453}&amp;action=embedview" width="772" height="565" frameborder="0"><a>Application Gateway</a>.</iframe></p>
                </p>
            </div>

            <Footer/>




        </>
    )
}