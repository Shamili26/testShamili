import Footer from "../Home/Footer";

import ContentNewHeader from "./ContentNewHeader";
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AgileGuidelines() {

    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/AgileGuidelines').then((response) => {

        }
        )
    }, [])



    return (
        <>
            <ContentNewHeader />
            <section className="agileguideline" id="agileguideline">
                <h3>Agile Guideline</h3>
                <p align="center">
                    <iframe src="Downloads\On_Job_Reference\General\AGILEGUIDELINES.pdf" width="722" height="565">Office<a />.</iframe></p>
            </section >
            <Footer />

        </>
    )
}