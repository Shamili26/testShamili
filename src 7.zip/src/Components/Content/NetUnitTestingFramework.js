import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function NetUnitTestingFramework() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetUnitTestingFramework').then((response) => {

        }
        )
    }, [])

    return (
        <>

            <ContentNewHeader />
            <section id="net-unittestingframework" className="net-unittestingframework">
                <div className="container">
                    <div className="section-title">
                        <span>Unit Testing Framework</span>
                        <h2>Unit Testing Framework</h2>
                    </div>
                    <ul className="nav nav-tabs" id="net-unittestingframework-flters">
                        <li><a href="#javascript-utf">JavaScript</a></li>
                        <li><a href="#csharp-utf">C#</a></li>
                        <li><a href="#cypress-utf">Cypress</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="javascript-utf" className="tab-pane fade in">
                            <h3>Mocha and Chai</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={5ac7066d-e7a6-497e-8914-8216ff120f75}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="csharp-utf" className="tab-pane fade in">
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7da7069a-3de9-441f-9982-da558fa0e295}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="cypress-utf" className="tab-pane fade in">
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c6990911-5c82-4a3f-a19d-b168ff6aec38}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            <Footer/>
        </>
    )
}