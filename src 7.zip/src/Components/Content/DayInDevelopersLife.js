
import Footer from "../Home/Footer";
import ContentNewHeader from "./ContentNewHeader";
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function DayInDevelopersLife() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/DayInDevelopersLife').then((response) => {

        }
        )
    }, [])

    return (
        <>
        <ContentNewHeader/>
            <section className="ojr-dayindeveloperlife" id="ojr-dayindeveloperlife">
                <h3>A Day in Developer's life</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={5d934581-7362-4833-bf29-65a702275540}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>
            <Footer/>

        </>
    )
}