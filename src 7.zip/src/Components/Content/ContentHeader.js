import React, { useState, useEffect } from "react";

function ContentHeader() {
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  const handleScroll = () => {
    if (window.pageYOffset > 0) {
      setIsScrolled(true);
    } else {
      setIsScrolled(false);
    }
  };
  const navbarStyle = {
    position: "fixed",
    top: 80,
    // left: 0,
    // width: "100%",
    height: "50px",
    backgroundColor: "#333",
    color: "#fff",
    // display: "flex",
    // alignItems: "center",
    // justifyContent: "center",
    // zIndex: 1,
  };

  return (
    <>
      <header className=" d-flex justify-content-center align-items-center">
        <nav
          className="nav-menu d-none d-lg-block justify-content-center"
          style={
            isScrolled ? navbarStyle : {}
            //position: "fixed",
          }
        >
          <ul>
            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                About Legal
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/legalDomainIntroduction"
                  >
                    Legal Domain Introduction{" "}
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/overviewOfLaw"
                  >
                    Overview of LAW
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/exploremore"
                  >
                    Explore More !!
                  </a>
                </li>
              </ul>
            </li>

            {/* <!-- New Joiner Handbook -->*/}
            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                New Joiner Handbook
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/knowyourmentor"
                  >
                    Know Your Mentor
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/onboarding"
                  >
                    Onboarding
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/clientOnboarding"
                  >
                    Client Onboarding
                  </a>
                </li>
                <li className="dropdown-submenu">
                  <a href="/" tabindex="-1">
                    Induction Plan
                  </a>

                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/inductionPlanJava"
                      >
                        Java
                      </a>
                    </li>
                  </ul>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/inductionPlanDotNet"
                      >
                        .Net
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/trainingMaterials"
                  >
                    Technical Materials
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/functionalDetails"
                  >
                    Functional Materials
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/laWhatsNext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="/" className="dropdown-toggle" data-toggle="dropdown">
                On Job References
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/dayInDevelopersLife"
                  >
                    A Day in Developer's life
                  </a>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    General
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/pullRequestGuidelines"
                      >
                        Pull Request Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/versionOneGuidelines"
                      >
                        Version One Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/laDefinitionOfDone"
                      >
                        LA - Definition of Done
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/laDefinitionOfReady"
                      >
                        LA - Definition of Ready
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/howToImproveCodeQuality"
                      >
                        Code Quality Improvement Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/solidPrinciples"
                      >
                        Solid Principles
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/agileGuideline"
                      >
                        Agile Guidelines
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Java
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaCodeQualityGuidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaCodeReviewChecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaCodeReferenceSlice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaStaticCodeAnalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaPerformanceAnalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaUnitTestingFramework"
                      >
                        Testing Framework
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    .Net
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netCodeQualityGuidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netCodeReviewChecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netCodeReferenceSlice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netStaticCodeAnalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netPerformanceAnalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netUnitTestingFramework"
                      >
                        Testing Framework
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/securityAwareness"
                      >
                        Security Awareness
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Others
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersCodeQualityGuidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersCodeReviewChecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersCodeReferenceSlice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersStaticCodeAnalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersPerformanceAnalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/othersUnitTestingFramework"
                      >
                        Testing Framework
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/ojrWhatsNext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                Lead Handbook
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/moduleLead"
                  >
                    Module Lead
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/projectLead"
                  >
                    Project Lead
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                Project Manager Handbook
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Evaluation Template
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/javaEvaluationTemplate"
                      >
                        Java
                      </a>
                    </li>
                  </ul>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="/netEvaluationTemplate"
                      >
                        .Net
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/pmrTemplate"
                  >
                    PMR Template
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/rolesResponsibilitiesManager"
                  >
                    Roles and Responsibilities of Manager
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/ciiIgniter"
                  >
                    CII
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/pmhWhatsnext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                BeCognizant
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a className="dropdown-item" id="dropDownItem" href="/bcp">
                    BCP
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/bcSecurityPolicy"
                  >
                    Security Policy
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/trutime"
                  >
                    Trutime Guidelines
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/timesheet"
                  >
                    Timesheet Guidelines
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/orgMandatoryCourses"
                  >
                    Org Mandatory Courses
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/defectPreventionPlan"
                  >
                    Defect Prevention Plan
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/bcWhatsNext"
                  >
                    What's Next
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" id="dropDownItem" href="/lntt">
                    Technical Materials
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </nav>
      </header>
    </>
  );
}
export default ContentHeader;
