import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function PMHWhatsNext() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/PMHWhatsNext').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section className="pmh-whatsnext" id="pmh-whatsnext">
                <h3>What's Next</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={92d8bbf2-6bbc-400b-9a76-2d85c718c2b6}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>

            <Footer/>

        </>
    )
}