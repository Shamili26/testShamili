import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OthersPerformanceAnalysis()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OthersPerformanceAnalysis').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        
        </>
    )
}