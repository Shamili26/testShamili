import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function LAWhatsNext() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/LAWhatsNext').then((response) => {

        }
        )
    }, [])

    return (
        <>
        <ContentNewHeader/>
            <section className="njh-whatsnext" id="njh-whatsnext">
                <h3>What's Next</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1a2e3924-707f-4fad-b4ce-af57f9c5ecdd}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>
            <Footer/>
        </>
    )
}