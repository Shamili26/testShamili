import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function NetCodeReviewChecklist()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetCodeReviewChecklist').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="net-codereviewchecklist" className="net-codereviewchecklist">
                    <div className="container">
                        <div className="section-title">
                            <span>Code Review Checklist</span>
                            <h2>Code Review Checklist</h2>
                        </div>
                        <ul className="nav nav-tabs" id="net-codereviewchecklist-flters">
                            <li className="active"><a href="#csharp-crc">C#</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="csharp-crc" className="tab-pane fade in active">
                                <h3>C#</h3>
                                <p align="center">
                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2d1a284d-8b08-4003-91fa-1006c55c7881}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&ed1JS=false"></iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer/>
        
        </>
    )
}