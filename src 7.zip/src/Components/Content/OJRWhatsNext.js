import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OJRWhatsNext() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OJRWhatsNext').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            < section className="ojr-whatsnext" id="ojr-whatsnext" >
                <h3>What's Next</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={bb8fdb25-6ea0-4827-a554-d9966f271599}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section >
            <Footer/>
        </>
    )
}