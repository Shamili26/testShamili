import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaEvaluationTemplate()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaEvaluationTemplate').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section className="java-evaluationtemplate" id="java-evaluationtemplate">
                    <h3>Evaluation Template - Java</h3>
                    <p align="center">
                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7532ffe8-7307-4e42-9f34-1e8364bf11aa}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                    </p>
        </section>

        <Footer/>

        </>
    )
}