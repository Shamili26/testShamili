
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from './ContentNewHeader';
import pic from './adminblue.jpg'
import Header from '../Home/Header';
import Footer from '../Home/Footer';
function LegalDomainIntroduction()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/LegalDomainIntroduction').then((response) => {

        }
        )
    }, [])

    return(
        <>
        
        <ContentNewHeader/>
          <section id="ld-introduction" className="ld-introduction">
                    <div className="container">
                        <div className="section-title">
                      {/*      <span>Legal Domain - Introduction</span> */}
                            <h2>Legal Domain - Introduction</h2>
                        </div>
                        <ul className="nav nav-tabs" id="ld-introduction-flters">
                            <li><a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
                            <li className="active"><a href="#introductiontold">Introduction to Legal Domain</a></li>
                        </ul>

                        <div className="tab-content">
                         {/*   <div id="introductiontold" className="tab-pane fade in active">*/}
                         <div id="introductiontold">
                                <h3>Introduction to Legal Domain</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={4848560b-3481-42d1-9ca1-daf7d5337372}&amp;action=embedview" width="722" height="565">Office</iframe></p>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer/>
                
        </>

    )
}
export default LegalDomainIntroduction;