import React, { useEffect, useState } from "react";
import "./registerstyle.css";
import "./registerstyle1.css";
import "./style.css";
import $ from "jquery";

function Content() {
  {
    /*
    useEffect(() => {

        const jQuery = () => {
            var scrolltoOffset = $('#header').outerHeight() - 21;
            $(document).on('click', '.nav-menu a, .mobile-nav a, .scrollto', function (e) {
                if (window.location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && window.location.hostname == this.hostname) {
                    var target = $(this.hash);
                    if (target.length) {
                        e.preventDefault();

                        var scrollto = target.offset().top - scrolltoOffset;

                        $('html, body').animate({
                            scrollTop: scrollto
                        }, 1500, 'easeInOutExpo');

                        if ($(this).parents('.nav-menu, .mobile-nav').length) {
                            $('.nav-menu .active, .mobile-nav .active').removeClass('active');
                            $(this).closest('li').addClass('active');
                        }

                        if ($('body').hasClass('mobile-nav-active')) {
                            $('body').removeClass('mobile-nav-active');
                            $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
                            $('.mobile-nav-overly').fadeOut();
                        }
                        return false;
                    }
                }
            });

            // Activate smooth scroll on page load with hash links in the url
            $(document).ready(function () {
                if (window.location.hash) {
                    var initial_nav = window.location.hash;
                    if ($(initial_nav).length) {
                        var scrollto = $(initial_nav).offset().top - scrolltoOffset;
                        $('html, body').animate({
                            scrollTop: scrollto
                        }, 1500, 'easeInOutExpo');
                    }
                }
            });

            // Mobile Navigation
            if ($('.nav-menu').length) {
                var $mobile_nav = $('.nav-menu').clone().prop({
                    class: 'mobile-nav d-lg-none'
                });
                $('body').append($mobile_nav);
                $('body').prepend('<button type="button" class="mobile-nav-toggle d-lg-none"><i class="icofont-navigation-menu"></i></button>');
                $('body').append('<div class="mobile-nav-overly"></div>');

                $(document).on('click', '.mobile-nav-toggle', function (e) {
                    $('body').toggleClass('mobile-nav-active');
                    $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
                    $('.mobile-nav-overly').toggle();
                });

                $(document).on('click', '.mobile-nav .drop-down > a', function (e) {
                    e.preventDefault();
                    $(this).next().slideToggle(300);
                    $(this).parent().toggleClass('active');
                });

                $(document).click(function (e) {
                    var container = $(".mobile-nav, .mobile-nav-toggle");
                    if (!container.is(e.target) && container.has(e.target).length === 0) {
                        if ($('body').hasClass('mobile-nav-active')) {
                            $('body').removeClass('mobile-nav-active');
                            $('.mobile-nav-toggle i').toggleClass('icofont-navigation-menu icofont-close');
                            $('.mobile-nav-overly').fadeOut();
                        }
                    }
                });
            } else if ($(".mobile-nav, .mobile-nav-toggle").length) {
                $(".mobile-nav, .mobile-nav-toggle").hide();
            }

            // Navigation active state on scroll
            var nav_sections = $('section');
            var main_nav = $('.nav-menu, .mobile-nav');

            $(window).on('scroll', function () {
                var cur_pos = $(this).scrollTop() + 200;

                nav_sections.each(function () {
                    var top = $(this).offset().top,
                        bottom = top + $(this).outerHeight();

                    if (cur_pos >= top && cur_pos <= bottom) {
                        if (cur_pos <= bottom) {
                            main_nav.find('li').removeClass('active');
                        }
                        main_nav.find('a[href="#' + $(this).attr('id') + '"]').parent('li').addClass('active');
                    }
                    if (cur_pos < 300) {
                        $(".nav-menu ul:first li:first").addClass('active');
                    }
                });
            });

            // Toggle .header-scrolled class to #header when page is scrolled
            $(window).scroll(function () {
                if ($(this).scrollTop() > 100) {
                    $('#header').addClass('header-scrolled');
                } else {
                    $('#header').removeClass('header-scrolled');
                }
            });

            if ($(window).scrollTop() > 100) {
                $('#header').addClass('header-scrolled');
            }

            // Back to top button
            $(window).scroll(function () {
                if ($(this).scrollTop() > 100) {
                    $('.back-to-top').fadeIn('slow');
                } else {
                    $('.back-to-top').fadeOut('slow');
                }
            });

            $('.back-to-top').click(function () {
                $('html, body').animate({
                    scrollTop: 0
                }, 1500, 'easeInOutExpo');
                return false;
            });

            // jQuery counterUp
            $('[data-toggle="counter-up"]').counterUp({
                delay: 10,
                time: 1000
            });

            // Skills section
            $('.skills-content').waypoint(function () {
                $('.progress .progress-bar').each(function () {
                    $(this).css("width", $(this).attr("aria-valuenow") + '%');
                });
            }, {
                offset: '80%'
            });

            // Testimonials carousel (uses the Owl Carousel library)
            $(".testimonials-carousel").owlCarousel({
                autoplay: true,
                dots: true,
                loop: true,
                items: 1
            });

            // Porfolio isotope and filter
            $(window).on('load', function () {
                var portfolioIsotope = $('.portfolio-container').isotope({
                    itemSelector: '.portfolio-item'
                });

                $('#portfolio-flters li').on('click', function () {
                    $("#portfolio-flters li").removeClass('filter-active');
                    $(this).addClass('filter-active');

                    portfolioIsotope.isotope({
                        filter: $(this).data('filter')
                    });
                });

                // Initiate venobox (lightbox feature used in portofilo)
                $(document).ready(function () {
                    $('.venobox').venobox();
                });
            });

            // Portfolio details carousel
            $(".portfolio-details-carousel").owlCarousel({
                autoplay: true,
                dots: true,
                loop: true,
                items: 1
            });

            $(document).ready(function () {
                $(".nav-tabs a").click(function () {
                    $(this).tab('show');
                });
            });

        }
    })
*/
  }
  return (
    <>
      <header
        id="header"
        className="fixed-top  d-flex justify-content-center align-items-center header-transparent"
      >
        <nav className="nav-menu d-none d-lg-block">
          <ul>
            {/*<!-- <li className="active"><a href="index.html">Home</a></li> -->*/}

            {/* <!-- About Legal -->*/}
            <li className="dropdown">
              <a href="/" className="dropdown-toggle" data-toggle="dropdown">
                Home
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="/OrgChart"
                  >
                    OrgChart{" "}
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" id="dropDownItem" href="/update">
                    Update Profile
                  </a>
                </li>
              </ul>
            </li>
            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                About Legal
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#ld-introduction"
                  >
                    Legal Domain Introduction{" "}
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#overviewoflaw"
                  >
                    Overview of LAW
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#la-exploremore"
                  >
                    Explore More !!
                  </a>
                </li>
              </ul>
            </li>

            {/* <!-- New Joiner Handbook -->*/}
            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                New Joiner Handbook
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#knowyourmentor"
                  >
                    Know Your Mentor
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#onboarding"
                  >
                    Onboarding
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#clientonboarding"
                  >
                    Client Onboarding
                  </a>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Induction Plan
                  </a>

                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-inductionplan"
                      >
                        Java
                      </a>
                    </li>
                  </ul>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-inductionplan"
                      >
                        .Net
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#training"
                  >
                    Technical Materials
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#lafunctionaldetails"
                  >
                    Functional Materials
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#njh-whatsnext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                On Job References
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#ojr-dayindeveloperlife"
                  >
                    A Day in Developer's life
                  </a>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    General
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#pullrequestguidelines"
                      >
                        Pull Request Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#versiononeguidelines"
                      >
                        Version One Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#ladefinitionofdone"
                      >
                        LA - Definition of Done
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#ladefinitionofready"
                      >
                        LA - Definition of Ready
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#howtoimprovecodequality"
                      >
                        Code Quality Improvement Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#solidprinciples"
                      >
                        Solid Principles
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#agileguideline"
                      >
                        Agile Guidelines
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Java
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-codequalityguidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-codereviewchecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-codereferenceslice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-staticcodeanalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-performanceanalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-unittestingframework"
                      >
                        Testing Framework
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    .Net
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-codequalityguidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-codereviewchecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-codereferenceslice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-staticcodeanalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-performanceanalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-unittestingframework"
                      >
                        Testing Framework
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-securityawarness"
                      >
                        Security Awarness
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Others
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-codequalityguidelines"
                      >
                        Code Quality Guidelines
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-codereviewchecklist"
                      >
                        Code Review Checklist
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-codereferenceslice"
                      >
                        Code Reference Slice
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-staticcodeanalysis"
                      >
                        Static Code Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-performanceanalysis"
                      >
                        Performance Analysis
                      </a>
                    </li>
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#others-unittestingframework"
                      >
                        Testing Framework
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#ojr-whatsnext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                Lead Handbook
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#modulelead"
                  >
                    Module Lead
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#projectlead"
                  >
                    Project Lead
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                Project Manager Handbook
              </a>
              <ul
                className="dropdown-menu multi-level"
                role="menu"
                aria-labelledby="dropdownMenu"
              >
                <li className="dropdown-submenu">
                  <a href="#" tabindex="-1">
                    Evaluation Template
                  </a>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#java-evaluationtemplate"
                      >
                        Java
                      </a>
                    </li>
                  </ul>
                  <ul className="dropdown-menu">
                    <li>
                      <a
                        className="dropdown-item"
                        id="dropDownItem"
                        href="#net-evaluationtemplate"
                      >
                        .Net
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#pmr-template"
                  >
                    PMR Template
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#roles-responsibilities-manager"
                  >
                    Roles and Responsibilities of Manager
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#cii-igniter"
                  >
                    CII
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#pmh-whatsnext"
                  >
                    What's Next
                  </a>
                </li>
              </ul>
            </li>

            <li className="dropdown">
              <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                BeCognizant
              </a>
              <ul className="dropdown-menu">
                <li>
                  <a className="dropdown-item" id="dropDownItem" href="#bcp">
                    BCP
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#bc-securitypolicy"
                  >
                    Security Policy
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#trutime"
                  >
                    Trutime Guidelines
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#timesheet"
                  >
                    Timesheet Guidelines
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#orgmandatorycourses"
                  >
                    Org Mandatory Courses
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#defectpreventionplan"
                  >
                    Defect Prevention Plan
                  </a>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    id="dropDownItem"
                    href="#bc-whatsnext"
                  >
                    What's Next
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" id="dropDownItem" href="#lntt">
                    Technical Materials
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </nav>
      </header>

      <section id="hero">
        <div className="hero-container">
          <h1>
            Learning Today,
            <br />
            Leading Tomorrow
          </h1>
          <h2>Cognizant LA Playbook - One stopshop for Induction</h2>
          <a href="#about" className="btn-scroll scrollto" title="Scroll Down">
            <i className="bx bx-chevron-down"></i>
          </a>
        </div>
      </section>

      <main id="main">
        <section id="ld-introduction" className="ld-introduction">
          <div className="container">
            <div className="section-title">
              <span>Legal Domain - Introduction</span>
              <h2>Legal Domain - Introduction</h2>
            </div>
            <ul className="nav nav-tabs" id="ld-introduction-flters">
              <li>
                <a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li className="active">
                <a href="#introductiontold">Introduction to Legal Domain</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="introductiontold" className="tab-pane fade in active">
                <h3>Introduction to Legal Domain</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={4848560b-3481-42d1-9ca1-daf7d5337372}&amp;action=embedview"
                    width="722"
                    height="565"
                  >
                    Office
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="overviewoflaw" className="overviewoflaw">
          <div className="container">
            <div className="section-title">
              <span>Overview of Law</span>
              <h2>Overview of Law</h2>
            </div>
            <ul className="nav nav-tabs" id="overviewoflaw-flters">
              <li className="active">
                <a href="#whatislaw">Law</a>
              </li>
              <li>
                <a href="#typesoflaw">Types of Law</a>
              </li>
              <li>
                <a href="#whoexecuteslaw">Who executes Law</a>
              </li>
              <li>
                <a href="#howdolawyerswork">How do Lawyers Work</a>
              </li>
              <li>
                <a href="#whohelplawyersprotectthelaw">
                  How Lawyers Protect the Law
                </a>
              </li>
              <li>
                <a href="#paralegal">Paralegal</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="whatislaw" className="tab-pane fade in active">
                <h3>What is Law</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={a511b2b5-8928-46a9-93b3-89450d6129fd}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="typesoflaw" className="tab-pane fade">
                <h3>Types of Law</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c61b02a8-7d2c-448e-a3f5-a300074bca95}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="whoexecuteslaw" className="tab-pane fade">
                <h3>Who executes Law</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={571e8c65-cb3d-4f06-8129-8bbeea048d01}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="howdolawyerswork" className="tab-pane fade">
                <h3>How do Lawyers work</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6018afe8-76a6-4906-b880-8a39722d7295}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="whohelplawyersprotectthelaw" className="tab-pane fade">
                <h3>Who help Lawyers protect the law</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={be446fc3-092f-4afc-92b9-f83f0d0a2231}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="paralegal" className="tab-pane fade">
                <h3>Paralegal</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e6107045-c78b-4dff-91e5-27976d2d140d}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="la-exploremore" className="la-exploremore">
          <div className="container">
            <div className="section-title">
              <span>Explore More !!</span>
              <h2>Explore More !!</h2>
            </div>
            <ul className="nav nav-tabs" id="la-exploremore-flters">
              <li className="active">
                <a href="#deliveringfuture">
                  Delivering the future of Legal Research
                </a>
              </li>
              <li>
                <a href="#howtousela">How to use Legal Advance</a>
              </li>
              <li>
                <a href="#exploringlexisplus">Exploring Lexis+</a>
              </li>
              <li>
                <a href="#seelexisplus">See Lexis+ for yourself</a>
              </li>
              <li>
                <a href="#laquicklaw">LA QuickLaw Tutorial</a>
              </li>
              <li>
                <a href="#shepardizing">Introduction to Shepardizing</a>
              </li>
              <li>
                <a href="#workfolders">WorkFolders</a>
              </li>
              <li>
                <a href="#termsandconnectors">Terms & Connectors</a>
              </li>
              <li>
                <a href="#ravelview">Ravel View</a>
              </li>
              <li>
                <a href="#lpaforms">LPA Forms</a>
              </li>
              <li>
                <a href="#histandrmap">History & Research Map</a>
              </li>
              <li>
                <a href="#booleansearching">Boolean Searching</a>
              </li>
              <li>
                <a href="#canadianlegislative">Canadian Legislative Pulse</a>
              </li>
              <li>
                <a href="#headnotes">HeadNotes</a>
              </li>
              <li>
                <a href="#copycitation">Copy Citation</a>
              </li>
              <li>
                <a href="#lacontext">Context</a>
              </li>
              <li>
                <a href="#laalerts">Alerts</a>
              </li>
              <li>
                <a href="#lacourtlink">Courtlink</a>
              </li>
              <li>
                <a href="#lalpa">LPA</a>
              </li>
              <li>
                <a href="#lalexisoverview">Lexis Overview</a>
              </li>
              <li>
                <a href="#laintrotolexisplus">Introduction to Lexis+</a>
              </li>
              <li>
                <a href="#contextattorney">Context Attorney Analytics</a>
              </li>
              <li>
                <a href="#judgecourtanalytics">Judge & Court Analytics</a>
              </li>
              <li>
                <a href="#courtlinkov">Courtlink Overview</a>
              </li>
              <li>
                <a href="#searchcapabilities">LA - Search Capabilities</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="deliveringfuture" className="tab-pane fade">
                <h3>LexisNexis: Delivering the Future of Legal Research</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/u1J2z5j0yyA"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="howtousela" className="tab-pane fade">
                <h3>How to Use Lexis Advance</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/ob68qgEbDgE"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="exploringlexisplus" className="tab-pane fade">
                <h3>Exploring Lexis+</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/VHcP8_MfpUk"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="seelexisplus" className="tab-pane fade">
                <h3>See Lexis+ for Yourself</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/KRfRLDODMyw"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="courtlinkov" className="tab-pane fade">
                <h3>Courtlink Overview</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/QiZHndXQIHQ"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="judgecourtanalytics" className="tab-pane fade">
                <h3>Judge & Court Analytics</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/fSNXN0AfEVc"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="contextattorney" className="tab-pane fade">
                <h3>Context Attorney Analytics</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/Y_crEnE9-NY&list=PLvUHkxs32huWAHlqu966Y4bRoxkshd1u2"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="laintrotolexisplus" className="tab-pane fade">
                <h3>Introduction to Lexis+</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/QFFXF9tYc-A"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="lalexisoverview" className="tab-pane fade">
                <h3>Lexis Overview</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/QXqz8sXQ9Lw"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="lalpa" className="tab-pane fade">
                <h3>LPA</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/1v3Y3R3cjT0"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="lacourtlink" className="tab-pane fade">
                <h3>Courtlink</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/Ti10l82x_tk"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="laalerts" className="tab-pane fade">
                <h3>Alerts</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/sa3_Qe8M9OE"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="lacontext" className="tab-pane fade">
                <h3>LA Context</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/6bb712CzHEA"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="copycitation" className="tab-pane fade">
                <h3>Copy Citation</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/jNtxsci1h9c"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="headnotes" className="tab-pane fade">
                <h3>Head Notes</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/7bagONYyAd8"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="canadianlegislative" className="tab-pane fade">
                <h3>Canadian Legislative Pulse</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/WxGSbceMfWQ"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="booleansearching" className="tab-pane fade">
                <h3>Boolean Searching</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/3wUa0Wp58SQ"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="histandrmap" className="tab-pane fade">
                <h3>History & Research Maps</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/o-Q-_82EI-4"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="lpaforms" className="tab-pane fade">
                <h3>LPA Forms</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/k-aQHSH_-Ak"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="ravelview" className="tab-pane fade">
                <h3>Ravel View</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/hkMDqm7JE2s"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="seelexisplus" className="tab-pane fade">
                <h3>LA QuickLaw Tutorial</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/Ud6Xhz6l324"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="shepardizing" className="tab-pane fade">
                <h3>Introduction to Shepardizing</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/Rsl7mlwDq4Q"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="workfolders" className="tab-pane fade">
                <h3>WorkFolders</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/zHEqj7ux8K0"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="termsandconnectors" className="tab-pane fade">
                <h3>Terms & Connectors</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="https://www.youtube.com/embed/SigKGfz28Rs"
                    title="YouTube video player"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                  ></iframe>
                </p>
              </div>
              <div id="searchcapabilities" className="tab-pane fade">
                <h3>Search Capabilities</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    src="Downloads\On_Job_Reference\General\LA Search Capabilities.pdf"
                    title="LA Search Capabilities"
                    frameborder="0"
                  ></iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="knowyourmentor" className="knowyourmentor">
          <div className="container">
            <div className="section-title">
              <span>Know Your Mentor</span>
              <h2>Know Your Mentor</h2>
              <p>
                Once associates got on boarded to LA program, they get to know
                about their mentor through 'Know Your Mentor' program.
                Associates can clarify both technical and project related
                queries such as onboarding activities, timesheet submission, and
                other org initiatives with their Mentor. On the absence of
                mentor/trainer, Associates can reach out to their supervisors
                for any queries that needs immediate attention. Associates can
                find the below document to get to know about organization
                structure of the project.
              </p>
              <br />
              <p>
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/:p:/r/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc=%7BFEB71777-3F35-456C-A4AA-0DD02348677A%7D&file=LN-LA-Development_Cognizant_Org_Chart.pptx&action=edit&mobileredirect=true"
                  width="722px"
                  height="565px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  presentation, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                </iframe>
              </p>
            </div>
          </div>
        </section>

        <section id="training" className="training">
          <div className="container">
            <div className="section-title">
              <span>Technical Materials</span>
              <h2>Event Recording & Quiz Links </h2>
              <p align="center">
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/:p:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Technical%20materials/Event%20Recording%20and%20Quiz%20Links/Cloud_DevOps_101.pptx?d=w1bb11e6e5c514de9ac9a93ea4e2e8d0a&csf=1&web=1&e=spWzbu"
                  width="722px"
                  height="565px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  presentation, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                  .
                </iframe>
              </p>
              <p align="center">
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/:p:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Technical%20materials/Event%20Recording%20and%20Quiz%20Links/Cloud_DevOps_101.pptx?d=w1bb11e6e5c514de9ac9a93ea4e2e8d0a&csf=1&web=1&e=spWzbu"
                  width="722px"
                  height="565px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  presentation, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                  .
                </iframe>
              </p>
              <p align="center">
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/:p:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Technical%20materials/Event%20Recording%20and%20Quiz%20Links/Containerization_201_V1.1_Updated.pptx?d=w3671e8e4e6e548d4ab49d9e9d00e0b1f&csf=1&web=1&e=ANh47i"
                  width="722px"
                  height="565px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  presentation, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                  .
                </iframe>
              </p>
              <p align="center">
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f17911a1-f430-4917-b7d5-35a617a23477}&amp;action=embedview"
                  width="476px"
                  height="288px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  document, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                  .
                </iframe>
              </p>
            </div>
          </div>
        </section>

        <section id="onboarding" className="onboarding">
          <div className="container">
            <div className="section-title">
              <span>Onboarding</span>
              <h2>Onboarding</h2>
            </div>
            <ul className="nav nav-tabs" id="onboarding-flters">
              <li className="active">
                <a href="#onboarding-nda">NDA</a>
              </li>
              <li>
                <a href="#onboarding-Security-Policy">Security Policy</a>
              </li>
              <li>
                <a href="#onboarding-assign-asset">Asset Allocaton</a>
              </li>

              <li>
                <a href="#onboarding-add-yourself-project-dl">
                  Enrollment to Project DL
                </a>
              </li>

              <li>
                <a href="#onboarding-add-yourself-odcaccess-dl">
                  Enrollment to ODC Access
                </a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="onboarding-nda" className="tab-pane fade in active">
                <h3>Non-Disclosure Agreement</h3>
                <p>
                  <em>
                    A non-disclosure agreement (NDA) is a signed formal
                    agreement in which LN agrees to give Cognizant confidential
                    information about its business or products and Cognizant
                    agrees not to share this information with anyone else.
                    Non-disclosure agreements are common in technology companies
                    where products are jointly developed.
                  </em>
                </p>

                <ul>
                  <li>
                    Fill up the NDA (Non-Disclosure Agreement) form with the
                    help of the sample filled NDA form which is also attached
                    here.
                  </li>
                  <li>
                    Download{" "}
                    <a href="https://cognizantonline-my.sharepoint.com/:w:/g/personal/389934_cognizant_com/ETGfb04RyutDrBiruA615I0BVFDOkSoDN-l_NGZI-HAp3Q?email=Krishnan.Thandavarayan%40cognizant.com&e=rDUeHe">
                      NDA
                    </a>
                    ,{" "}
                    <a href="https://cognizantonline-my.sharepoint.com/:b:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Onboarding/Sample%20NDA.pdf?csf=1&web=1&e=bmym2C">
                      Sample NDA
                    </a>
                  </li>
                  <li>
                    Take a print out of the filled form and sign in the form;
                    Scan the signed form & share with your Manager
                  </li>
                </ul>
                <br />
                <table className="table table-sm table-striped">
                  <thead>
                    <tr>
                      <th scope="col">Associate ID</th>
                      <th scope="col">Associate Name</th>
                      <th scope="col">
                        Category
                        <br />
                        (ELT/Lateral/
                        <br />
                        Contractor)
                      </th>
                      <th scope="col">Solution Line</th>
                      <th scope="col">Project</th>
                      <th scope="col">Project ID</th>
                      <th scope="col">Requestor Name</th>
                      <th scope="col">Expected Date</th>
                      <th scope="col">Expected Billability Date</th>
                      <th scope="col">
                        VISA available
                        <br />
                        (Y/N)
                      </th>
                      <th scope="col">VISA type</th>
                      <th scope="col">Expiry Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>123456</td>
                      <td>Associate's Name</td>
                      <td>Lateral</td>
                      <td>New Lexis</td>
                      <td>LN-LA-Development</td>
                      <td>1000046633</td>
                      <td>Manager Name</td>
                      <td>20-Aug-2020</td>
                      <td>23-Aug-2020</td>
                      <td>N</td>
                      <td>N/A</td>
                      <td>N/A</td>
                    </tr>
                  </tbody>
                </table>
                <br />
                <li>
                  Once the background verification is done, please follow up the
                  manager to raise the request for LN ID and VDI creation.
                </li>
                <li>Processing time: 1 month.</li>
                <li>
                  If it takes more than a month, check with the manager about
                  the status of BG check and VDI creation.{" "}
                </li>
                <li>
                  Follow it up with them until the VDI is created for you.
                </li>

                <div id="onboarding-Security-Policy" className="tab-pane fade">
                  <h3>Security Policy</h3>
                  <p>
                    <em>
                      Phishing is an attempt to acquire sensitive information
                      such as usernames, passwords, business sensitive
                      information, credit card details and sometimes, indirectly
                      money as well. Its most often intended with malicious
                      reasons, masquerading as a trustworthy entity in an
                      electronic communication.
                    </em>
                  </p>
                  <img
                    align="center"
                    src="assets/img/Phising_img.png"
                    width="724px"
                    height="380px"
                    className="center"
                    alt="Responsive image"
                  />
                  <br />
                  <br />
                  <ul>
                    <li>
                      <strong>EXTRA VIGILANCE: COVID-19 SCAM</strong> Indian
                      government officials are warning citizens to expect a
                      widespread COVID-19 phishing attack. The phishing email
                      scam offers free testing to residents in major Indian
                      cities. The COVID-19 phishing email is designed to steal
                      personal data and financial information. The bad actors
                      impersonate local government officials known to be tasked
                      with supporting local testing and government aid
                      distribution. The attackers create fake email addresses
                      with these officials&rsquo; names or spoof the government
                      authorities&rsquo; IDs. (Spoofing is the act of disguising
                      a communication from an unknown source as being from a
                      known, trusted source.)
                    </li>
                    <li>
                      A cyber security agency with knowledge of this specific
                      attack warns: Do not open attachments in unsolicited
                      emails. Do not click on URLs in an unsolicited email, even
                      if the link seems benign. Cyber security agencies have
                      seen multiple attacks related to COVID-19.
                    </li>
                    <li>
                      Every COVID-19 email should be read with skepticism.
                      Question the message&rsquo;s intent.
                    </li>
                    <li>
                      Review all parts of the message before acting. Cognizant
                      proactively blocks emails from malicious actors. Please
                      use the ReportSpam action in Outlook to report this and
                      any other suspected phishing attacks.
                    </li>
                  </ul>
                  <h4>
                    Follow below guidance if you receive a suspicious email:
                  </h4>
                  <ul>
                    <li>
                      1. Approach Unsolicited Emails with Skepticism:
                      Interacting with a phishing email can launch software,
                      install ransomware, steal your stored credentials, etc. Be
                      aware that an email related to COVID-19 is likely a
                      phishing attempt.
                    </li>
                    <li>
                      2. Remain Vigilant: Fraudulent messages around vaccine
                      information, special offers, breaking news, etc. are all
                      designed to deceive you into acting on the promises of the
                      email.
                    </li>
                    <li>
                      3. Question the Message: Cognizant and legitimate
                      organizations will never ask for your credentials or
                      sensitive information.
                    </li>
                    <li>
                      4. Analyze the Email: Question the message&rsquo;s
                      intent&mdash; see where it originated from, if it was a
                      legitimate domain, and analyze all the variables about the
                      message before acting.
                    </li>
                    <li>
                      5. Attachments: Never open or download attachments from
                      unknown sources.
                    </li>
                    <li>
                      6. Links: While Cognizant is using email to communicate
                      with associates, the messages are also available on
                      BeCognizant. You will not be directed to click a link or
                      download a file from the email. Cognizant communications
                      will instead direct you to a BeCognizant page.
                    </li>
                    <li>
                      7. Videos: Information such as ways you can protect
                      yourself and your family should be viewed using personal
                      devices on known, trusted websites. If a file promising
                      this information is in a video attached to an email, do
                      not open it. Report it.
                    </li>
                    <li>
                      Report suspicious emails using the ReportSpam plugin in
                      Outlook or report by sending the suspicious email as an
                      attachment to{" "}
                      <a href="mailto:reportspam@cognizant.com">
                        reportspam@cognizant.com
                      </a>
                    </li>
                  </ul>
                  <br />
                  <p align="center">
                    <iframe
                      src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6f207777-646d-4222-860f-0657d2110db6}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                      width="722px"
                      height="565px"
                      frameborder="0"
                    >
                      This is an embedded{" "}
                      <a target="_blank" href="https://office.com">
                        Microsoft Office
                      </a>{" "}
                      presentation, powered by{" "}
                      <a target="_blank" href="https://office.com/webapps">
                        Office
                      </a>
                      .
                    </iframe>
                  </p>
                </div>

                <div id="onboarding-assign-asset" className="tab-pane fade in">
                  <h3>Asset Allocation</h3>
                  <p align="center">
                    <iframe
                      src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d52174ac-cd33-4166-baeb-d1369d97788b}&amp;action=embedview"
                      width="722px"
                      height="565px"
                      frameborder="0"
                    >
                      This is an embedded{" "}
                      <a target="_blank" href="https://office.com">
                        Microsoft Office
                      </a>{" "}
                      document, powered by{" "}
                      <a target="_blank" href="https://office.com/webapps">
                        Office
                      </a>
                      .
                    </iframe>
                  </p>
                </div>

                <div
                  id="onboarding-update-location-seat"
                  className="tab-pane fade in"
                >
                  <h3>Seat Allocation</h3>
                  <p align="center">
                    <iframe
                      src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8cc5e343-640c-4102-aab9-b7d77627b160}&amp;action=embedview"
                      width="722px"
                      height="565px"
                      frameborder="0"
                    >
                      This is an embedded{" "}
                      <a target="_blank" href="https://office.com">
                        Microsoft Office
                      </a>{" "}
                      document, powered by{" "}
                      <a target="_blank" href="https://office.com/webapps">
                        Office
                      </a>
                      .
                    </iframe>
                  </p>
                </div>

                <div
                  id="onboarding-add-yourself-project-dl"
                  className="tab-pane fade in"
                >
                  <h3>Enrollment to Project DL</h3>
                  <p align="center">
                    <iframe
                      src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9b628978-09d5-48bc-8654-90d522104689}&amp;action=embedview"
                      width="722px"
                      height="565px"
                      frameborder="0"
                    >
                      This is an embedded{" "}
                      <a target="_blank" href="https://office.com">
                        Microsoft Office
                      </a>{" "}
                      document, powered by{" "}
                      <a target="_blank" href="https://office.com/webapps">
                        Office
                      </a>
                      .
                    </iframe>
                  </p>
                </div>

                <div
                  id="onboarding-add-yourself-odcaccess-dl"
                  className="tab-pane fade in"
                >
                  <h3>Enrollment to ODC Access</h3>
                  <p>
                    <em>
                      A New Associates who are coming to office for the first
                      time they need to get access to the ODC. Becuase our ODC
                      is an Secure ODC to get access to ODC they can contact
                      249495(<b>Jeyaraman</b>) and 321499(
                      <b>Sathyanarayanana</b>)
                    </em>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="clientonboarding" className="clientonboarding">
          <div className="container">
            <div className="section-title">
              <span>Client Onboarding</span>
              <h2>Client Onboarding</h2>
            </div>
            <ul className="nav nav-tabs" id="clientonboarding-flters">
              <li className="active">
                <a href="#clientonboarding-vdiaccess">VDI Access</a>
              </li>
              <li>
                <a href="#clientonboarding-vdiissues">
                  VDI Access - Common Issues & Solutions
                </a>
              </li>
              <li>
                <a href="#clientonboarding-msteamsissues">
                  LN VDI MS-Teams Issues & Solutions
                </a>
              </li>
              <li>
                <a href="#clientonboarding-visualstudio">
                  Visual Studio Installation
                </a>
              </li>
            </ul>

            <div className="tab-content">
              <div
                id="clientonboarding-vdiaccess"
                className="tab-pane fade in active"
              >
                <h3>VDI Access</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9e574d00-69f0-45b4-9734-7f09cc5a151e}&amp;action=embedview&amp;wdEmbedCode=1&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>

              <div id="clientonboarding-vdiissues" className="tab-pane fade">
                <h3>VDI Access - Issues & Solutions</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3db36610-0c05-4ee6-8d89-a745d5f79ab8}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>

              <div
                id="clientonboarding-msteamsissues"
                className="tab-pane fade"
              >
                <h3>LN VDI MS-Teams Issues & Solutions</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={13a49b41-23a0-4f53-8ad4-76c115d0de6d}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>

              <div
                id="clientonboarding-visualstudio"
                className="tab-pane fade in"
              >
                <h3>Visual Studio Installation</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={924a46d1-819a-4307-9d5d-edeea18c0595}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="java-inductionplan" className="java-inductionplan">
          <div className="container">
            <div className="section-title">
              <span>Induction Plan - Java</span>
              <h2>Induction Plan - Java</h2>
              <p>
                <em>
                  As part of Induction , the new joiners will be trained on LA
                  specific technolgies along with Org manadate which the
                  associate should be compliant. This Induction plan comprises
                  of technical trainings, LA Functional trainings and Assessment
                  details. The topics are categorized as "Self Training" ,
                  "Mentor Instructed" & "Instructor led". Training materials are
                  available in playbook for reference. we have both detailed
                  induction and induction lite template available for
                  associates. Please contact your mentor for induction type
                  chosen.
                </em>
              </p>
            </div>
            <ul className="nav nav-tabs" id="java-inductionplan-flters">
              <li className="active">
                <a href="#inductionplan-detailed">Induction Plan - Detailed</a>
              </li>
              <li>
                <a href="#inductionplan-lite">Induction Plan - Lite</a>
              </li>
            </ul>

            <div className="tab-content">
              <div
                id="inductionplan-detailed"
                className="tab-pane fade in active"
              >
                <h3>Induction Plan - Detailed</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={baac7700-385c-4329-991b-c351b951e9f3}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True"
                  ></iframe>
                </p>
              </div>
              <div id="inductionplan-lite" className="tab-pane fade">
                <h3>Induction Plan - Lite</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={4c1e84b8-b085-4450-8fd3-0b638f0cc235}&action=embedview&wdAllowInteractivity=False&wdDownloadButton=True&wdInConfigurator=True"
                  ></iframe>
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="net-inductionplan" id="net-inductionplan">
          <h3>Induction Plan - .Net</h3>
          <p>
            <em>
              As part of Induction , the new joiners will be trained on LA
              specific technolgies along with Org manadate which the associate
              should be compliant. This Induction plan comprises of technical
              trainings, LA Functional trainings and Assessment details. The
              topics are categorized as "Self Training" , "Mentor Instructed" &
              "Instructor led". Training materials are available in playbook for
              reference.we have both detailed induction and induction lite
              template available for associates. Please contact your mentor for
              induction type chosen.
            </em>
          </p>
          <p align="center">
            <iframe
              width="722"
              height="565"
              frameborder="0"
              scrolling="no"
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={839a1d26-5168-44b2-bb92-efaddcb2052d}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True"
            ></iframe>
          </p>
        </section>

        <section id="training" className="training">
          <div className="container">
            <div className="section-title">
              <span>Technical Materials</span>
              <h2>Technical Materials</h2>
            </div>
            <ul className="nav nav-tabs" id="training-flters">
              <li className="active">
                <a href="#restfulwebservices">Restful Web Services</a>
              </li>
              <li>
                <a href="#marklogic">Marklogic</a>
              </li>
              <li>
                <a href="#xpathandxquery">Xpath and Xquery</a>
              </li>
              <li>
                <a href="#angulardiv">ANGULAR</a>
              </li>
              <li>
                <a href="#awsdiv">AWS</a>
              </li>
              <li>
                <a href="#devops">DevOPs</a>
              </li>
              <li>
                <a href="#bdd">BDD</a>
              </li>
              <li>
                <a href="#aspvideos">ASP.NET PROGRAM</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="restfulwebservices" className="tab-pane fade in active">
                <h3>Restful Web Services</h3>
                <p>
                  Representational State Transfer (REST) is an architectural
                  style that specifies constraints, such as the uniform
                  interface, that if applied to a web service induce desirable
                  properties, such as performance, scalability, and
                  modifiability, that enable services to work best on the Web.
                  In the REST architectural style, data and functionality are
                  considered resources and are accessed using Uniform Resource
                  Identifiers (URIs), typically links on the Web. The resources
                  are acted upon by using a set of simple, well-defined
                  operations.
                </p>
                <p>
                  The REST architectural style constrains an architecture to a
                  client/server architecture and is designed to use a stateless
                  communication protocol, typically HTTP. In the REST
                  architecture style, clients and servers exchange
                  representations of resources by using a standardized interface
                  and protocol.
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d9e0cc86-95e0-4fa9-87da-f3bfa8db4db5}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="marklogic" className="tab-pane fade in">
                <h3>MarkLogic</h3>
                <p>
                  MarkLogic Server is a document-oriented database developed by
                  MarkLogic. It is a NoSQL multi-model database that evolved
                  from an XML database to natively store JSON documents and RDF
                  triples, the data model for semantics. MarkLogic is designed
                  to be a data hub for operational and analytical data.
                </p>
                <p>
                  MarkLogic uses documents without upfront schemas to maintain a
                  flexible data model. In addition to having a flexible data
                  model, MarkLogic uses a distributed, scale-out architecture
                  that can handle hundreds of billions of documents and hundreds
                  of terabytes of data. It has received Common Criteria
                  certification, and has high availability and disaster
                  recovery. MarkLogic is designed to run on-premises and within
                  public or private cloud environments like Amazon Web Services.
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7a4115a7-6f25-48df-9773-e059033aec6a}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="xpathandxquery" className="tab-pane fade in">
                <h3>XPath & XQuery</h3>
                <p>
                  XPath (XML Path Language) is a query language for selecting
                  nodes from an XML document. XPath is an important and core
                  component of XSLT standard. It is used to traverse the
                  elements and attributes in an XML document. XPath is a W3C
                  recommendation. XPath provides different types of expressions
                  to retrieve relevant information from the XML document. It is
                  syntax for defining parts of an XML document.
                </p>
                <p>
                  XQuery is a functional query language used to retrieve
                  information stored in XML format. It is same as for XML what
                  SQL is for databases. It queries and transforms collections of
                  structured and unstructured data, usually in the form of XML,
                  text and with vendor-specific extensions for other data
                  formats (JSON, binary, etc.)
                </p>

                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={de4ad06f-8f08-4dcf-a544-654481801759}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="awsdiv" className="tab-pane fade in">
                <section id="aws" className="aws">
                  <div className="container">
                    <div className="section-title">
                      <span>AWS</span>
                      <h2>AWS</h2>
                      <p>
                        <em>
                          Amazon Web Services is a cloud computing platform that
                          provides customers with a wide array of cloud
                          services. We can define AWS (Amazon Web Services) as a
                          secured cloud services platform that offers compute
                          power, database storage, content delivery and various
                          other functionalities.
                        </em>
                      </p>
                    </div>
                    <ul className="nav nav-tabs" id="aws-flters">
                      <li className="active">
                        <a href="#awsintroduction">Introduction</a>
                      </li>
                      <li>
                        <a href="#iam">IAM</a>
                      </li>
                      <li>
                        <a href="#awsecs">ECS</a>
                      </li>
                      <li>
                        <a href="#awslambda">Lambda</a>
                      </li>
                      <li>
                        <a href="#awscloudformation">CloudFormation</a>
                      </li>
                      <li>
                        <a href="#awsdynamodb">DynamoDB</a>
                      </li>
                      <li>
                        <a href="#s3">S3</a>
                      </li>
                      <li>
                        <a href="#awscloudwatch">CloudWatch</a>
                      </li>
                      <li>
                        <a href="#awsec2">EC2</a>
                      </li>
                      <li>
                        <a href="#awselbandroute53">ELB & Route53</a>
                      </li>
                      <li>
                        <a href="#awsotherservices">Other Services</a>
                      </li>
                    </ul>

                    <div className="tab-content">
                      <div
                        id="awsintroduction"
                        className="tab-pane fade in active"
                      >
                        <h3>Introduction</h3>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={154c8b05-33c3-4a51-9256-df772fdb0fc4}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="iam" className="tab-pane fade in active">
                        <h3>AWS Identity and Access Management</h3>
                        <p>
                          AWS Identity and Access Management (IAM) enables you
                          to manage access to AWS services and resources
                          securely. Using IAM, you can create and manage AWS
                          users and groups, and use permissions to allow and
                          deny their access to AWS resources. IAM enables the
                          organization to create multiple users, each with its
                          own security credentials, controlled and billed to a
                          single aws account. IAM allows the user to do only
                          what they need to do as a part of the user's job.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={796f8662-df6b-47ad-9e7c-550e93e37800}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awsecs" className="tab-pane fade in active">
                        <h3>AWS Elatic Container Service</h3>
                        <p>
                          Amazon Elastic Container Service (Amazon ECS) is a
                          highly scalable, fast container management service
                          that makes it easy to run, stop, and manage containers
                          on a cluster. Your containers are defined in a task
                          definition that you use to run individual tasks or
                          tasks within a service.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={ea879f7d-6b84-4c28-a537-23a86187db3c}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awslambda" className="tab-pane fade in active">
                        <h3>AWS Lambda</h3>
                        <p>
                          AWS Lambda is a serverless compute service that lets
                          you run code without provisioning or managing servers,
                          creating workload-aware cluster scaling logic,
                          maintaining event integrations, or managing runtimes.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2a427841-f18c-4d5d-9f9f-c59a393f284f}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div
                        id="awscloudformation"
                        className="tab-pane fade in active"
                      >
                        <h3>AWS CloudFormation</h3>
                        <p>
                          AWS CloudFormation gives you an easy way to model a
                          collection of related AWS and third-party resources,
                          provision them quickly and consistently, and manage
                          them throughout their lifecycles, by treating
                          infrastructure as code. A CloudFormation template
                          describes your desired resources and their
                          dependencies so you can launch and configure them
                          together as a stack.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8be78da8-7b7d-482b-bcdb-322d391555e0}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awsdynamodb" className="tab-pane fade in active">
                        <h3>AWS DynamoDB</h3>
                        <p>
                          Amazon DynamoDB is a key-value and document database
                          that delivers single-digit millisecond performance at
                          any scale. It's a fully managed, multi-region,
                          multi-active, durable database with built-in security,
                          backup and restore, and in-memory caching for
                          internet-scale applications.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7520faa5-85d2-4ee4-b1c0-3d6f91fd219e}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="s3" className="tab-pane fade">
                        <h3>AWS Simple Storage Service</h3>
                        <p>
                          Amazon Simple Storage Service (S3) is an object
                          storage service that offers industry-leading
                          scalability, data availability, security, and
                          performance. This means customers of all sizes and
                          industries can use it to store and protect any amount
                          of data for a range of use cases, such as websites,
                          mobile applications, backup and restore, archive,
                          enterprise applications, IoT devices, and big data
                          analytics. Amazon S3 provides easy-to-use management
                          features so you can organize your data and configure
                          finely-tuned access controls to meet your specific
                          business, organizational, and compliance requirements.{" "}
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={0f4b88e5-52b0-4106-90f3-26948459db04}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awscloudwatch" className="tab-pane fade">
                        <h3>AWS Cloudwatch</h3>
                        <p>
                          Amazon CloudWatch is a monitoring and management
                          service that provides data and actionable insights for
                          AWS, hybrid, and on-premises applications and
                          infrastructure resources. With CloudWatch, you can
                          collect and access all your performance and
                          operational data in form of logs and metrics from a
                          single platform.{" "}
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d7ff2036-3ee8-4ac8-9f30-f6a724d9bb91}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awsec2" className="tab-pane fade">
                        <h3> AWS Elastic Compute Cloud (EC2)</h3>
                        <p>
                          Amazon Elastic Compute Cloud (EC2) is a web service
                          that provides secure, resizable compute capacity in
                          the cloud. It is designed to make web-scale cloud
                          computing easier for developers. Amazon EC2’s simple
                          web service interface allows you to obtain and
                          configure capacity with minimal friction. It provides
                          you with complete control of your computing resources
                          and lets you run on Amazon’s proven computing
                          environment.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3535acf8-1618-460b-8984-d6c83320ef2e}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awselbandroute53" className="tab-pane fade">
                        <h3>AWS ELB and Route 53</h3>
                        <p>
                          Elastic Load Balancing (ELB) automatically distributes
                          incoming application traffic across multiple targets,
                          such as Amazon EC2 instances, containers, IP
                          addresses, and Lambda functions. It can handle the
                          varying load of your application traffic in a single
                          Availability Zone or across multiple Availability
                          Zones. Elastic Load Balancing offers three types of
                          load balancers (Application LB, Network LB, Classic
                          LB) that all feature the high availability, automatic
                          scaling, and robust security necessary to make your
                          applications fault tolerant.
                        </p>
                        <p>
                          Amazon Route 53 is a highly available and scalable
                          cloud Domain Name System (DNS) web service. It is
                          designed to give developers and businesses an
                          extremely reliable and cost effective way to route end
                          users to Internet applications by translating names
                          like www.example.com into the numeric IP addresses
                          like 192.0.2.1 that computers use to connect to each
                          other.
                        </p>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d036c1a4-4162-419a-9465-9fec1014515d}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                      <div id="awsotherservices" className="tab-pane fade">
                        <h3>AWS Other Services</h3>
                        <p align="center">
                          <iframe
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e4089c5e-b5e1-479f-bc9e-bc62942a1dfb}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                            width="722px"
                            height="565px"
                            frameborder="0"
                          >
                            This is an embedded{" "}
                            <a target="_blank" href="https://office.com">
                              Microsoft Office
                            </a>{" "}
                            presentation, powered by{" "}
                            <a
                              target="_blank"
                              href="https://office.com/webapps"
                            >
                              Office
                            </a>
                            .
                          </iframe>
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
              <div id="devops" className="tab-pane fade in">
                <h3>DevOps</h3>
                <p>
                  DevOps is a set of practices that combines software
                  development and IT operations. DevOps is about removing the
                  barriers between traditionally siloed teams, development and
                  operations. Under a DevOps model, development and operations
                  teams work together across the entire software application
                  life cycle, from development and test through deployment to
                  operations.
                </p>{" "}
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8702342d-d54c-40f8-bb00-abacc9775b75}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="angulardiv" className="tab-pane fade in">
                <h3>Angular</h3>
                <p>
                  Angular is a platform and framework for building single-page
                  client applications using HTML and TypeScript. Angular is
                  written in TypeScript. It implements core and optional
                  functionality as a set of TypeScript libraries that you import
                  into your apps.
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={47238b35-8205-40e5-b775-dab4080ef9a2}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
                <h3>Introduction To Angular</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/1.%20Introduction%20to%20Angular.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Angular Components and Data Binding</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/2.%20Angular%20components%20and%20data%20binding.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Angular - Directives</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/3.%20Angular%20-%20Directives.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Angular - Forms</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/4.%20Angular%20-%20Angular%20Forms.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Angular - Service and Dependency Injection</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/5.%20Angular%20-%20Services%20%26%20dependency%20injection.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Routing</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Routing.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Pipes</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Pipes.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Making HTTP Requests</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Making%20Http%20requests.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
                <h3>Observables & Working with NgRX</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Observables%20%26%20Working%20with%20NgRX.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
              </div>
              <div id="bdd" className="tab-pane fade in">
                <h3>Behavior Driven Development</h3>
                <p>
                  Behavior Driven Development (BDD) is an Agile software
                  development process that encourages collaboration among
                  developers, QA and non-technical or business participants in a
                  software project. It encourages teams to use conversation and
                  concrete examples to formalize a shared understanding of how
                  the application should behave. It emerged from test-driven
                  development (TDD). Behavior-driven development combines the
                  general techniques and principles of TDD with ideas from
                  domain-driven design and object-oriented analysis and design
                  to provide software development and management teams with
                  shared tools and a shared process to collaborate on software
                  development.
                </p>

                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={fb667785-d17d-4f33-be6a-6fe671a89150}&amp;action=embedview&amp;wdAr=1.3333333333333333"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="aspvideos" className="tab-pane fade in">
                <h3>ASP.Net Core Program</h3>
                <p>
                  Technical sessions where conducted related to topics like MVC,
                  Entity framework,ASP.NET & C# to Trainee Associates.Videos
                  related to the session are listed below for reference.
                </p>

                <ul className="nav nav-tabs" id="asp-flters">
                  <li className="active">
                    <a href="#aspsession1">Session 1</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession2">Session 2</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession3">Session 3</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession4">Session 4</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession5">Session 5</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession6">Session 6</a>
                  </li>
                  <br />
                  <li className="active">
                    <a href="#aspsession7">Session 7</a>
                  </li>
                  <br />
                </ul>
                <div className="tab-content">
                  <div id="aspsession1" className="tab-pane fade in active">
                    <h4>Session 1</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-5dd37116-5333-4355-a8b1-2cadd2613786/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession2" className="tab-pane fade in active">
                    <h4>Session 2</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-ba5ac149-cafd-4053-a16d-cf5f089affd7/nv4/embedded"
                        allowFullScreen
                        webkitallowFullScreen
                        mozallowFullScreen
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession3" className="tab-pane fade in active">
                    <h4>Session 3</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-547d7692-d4af-4002-873f-de17eaf85e1b/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession4" className="tab-pane fade in active">
                    <h4>Session 4</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-8f2db37f-a1e2-4b1c-85c6-38df24c68bf8/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession5" className="tab-pane fade in active">
                    <h4>Session 5</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-fdd38edc-96ba-4bf1-a4fc-d99620d1cf86/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession6" className="tab-pane fade in active">
                    <h4>Session 6</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-2381aa59-523f-47b9-905c-d91204dba45d/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                  <div id="aspsession7" className="tab-pane fade in active">
                    <h4>Session 7</h4>
                    <p align="center">
                      <iframe
                        src="https://cognizant.kpoint.com/web/videos/gcc-45f30fcf-aed8-4c0e-8fef-d34246ff4b23/nv4/embedded"
                        width="640"
                        height="360"
                        rel="nofollow"
                        style={{ border: "0px" }}
                      >
                        This is an embedded{" "}
                        <a target="_blank" href="https://office.com">
                          Microsoft Office
                        </a>{" "}
                        presentation, powered by{" "}
                        <a target="_blank" href="https://office.com/webapps">
                          Office
                        </a>
                        .
                      </iframe>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="lafunctionaldetails" id="lafunctionaldetails">
          <h3>Functional Materials</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={02f3cd52-9269-4b2a-a007-587462e29306}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <section className="njh-whatsnext" id="njh-whatsnext">
          <h3>What's Next</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1a2e3924-707f-4fad-b4ce-af57f9c5ecdd}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <section
          id="java-codequalityguidelines"
          className="java-codequalityguidelines"
        >
          <div className="container">
            <div className="section-title">
              <span>Coding Standard</span>
              <h2>Coding Standard</h2>
              <p>
                <em>
                  To build enterprise applications, which are reliable, scalable
                  and maintainable, it is important for development teams to
                  adopt proven design techniques and good coding standards. The
                  adoption of coding standards results in code consistency,
                  which makes it easier to understand, develop and maintain the
                  application. In addition by being aware of and following the
                  right coding techniques at a granular level, the programmer
                  can make the code more efficient and performance effective.
                </em>
              </p>
            </div>
            <ul className="nav nav-tabs" id="java-codequalityguidelines-flters">
              <li className="active">
                <a href="#java">Java</a>
              </li>
              <li>
                <a href="#oracle">Oracle</a>
              </li>
              <li>
                <a href="#xquery">XQuery</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="java" className="tab-pane fade in active">
                <h3>Java</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={67460d48-2463-4935-8e6e-78ef36257579}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="oracle" className="tab-pane fade">
                <h3>Oracle</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6cb50bf8-3963-4c0d-b623-89585b5ee732}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="xquery" className="tab-pane fade">
                <h3>XQuery</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c39fddfd-0a30-41ee-b994-06d2c25afbb8}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="java-codereviewchecklist"
          className="java-codereviewchecklist"
        >
          <div className="container">
            <div className="section-title">
              <span>Code Review Checklist</span>
              <h2>Code Review Checklist</h2>
            </div>
            <ul className="nav nav-tabs" id="java-codereviewchecklist-flters">
              <li className="active">
                <a href="#java-crc">Java</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="java-crc" className="tab-pane fade in active">
                <h3>Java</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e9a9873e-0700-4fb6-b4fe-8f189161079f}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="java-codereferenceslice"
          className="java-codereferenceslice"
        >
          <div className="container">
            <div className="section-title">
              <span>Code Reference Slice</span>
              <h2>Code Reference Slice</h2>
            </div>
            <ul className="nav nav-tabs" id="java-codereferenceslice-flters">
              <li className="active">
                <a href="#swagger-crs">Swagger</a>
              </li>
              <li>
                <a href="#java-crs">Java</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="swagger-crs" className="tab-pane fade in active">
                <h3>Swagger</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={33cda73d-7d98-4cb1-ace0-b4d904759a34}&amp;action=embedview&amp;wdAr=1.7777777777777777"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="java-crs" className="tab-pane fade in active">
                <h3>Java</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1c75c9e1-f66b-48fb-91a7-663cf60c2179}&amp;action=embedview&amp;wdAr=1.7777777777777777"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="java-staticcodeanalysis"
          className="java-staticcodeanalysis"
        >
          <div className="container">
            <div className="section-title">
              <span>Static Code Analysis</span>
              <h2>Static Code Analysis</h2>
              <p>
                <em>
                  To build enterprise applications, which are reliable, scalable
                  and maintainable, it is important for development teams to
                  adopt proven design techniques and good coding standards. The
                  adoption of coding standards results in code consistency,
                  which makes it easier to understand, develop and maintain the
                  application. In addition by being aware of and following the
                  right coding techniques at a granular level, the programmer
                  can make the code more efficient and performance
                  effective.Static code analysis is a method of debugging by
                  examining source code before a program is run. It’s done by
                  analyzing a set of code against a set (or multiple sets) of
                  coding rules.
                </em>
              </p>
            </div>
            <ul className="nav nav-tabs" id="java-staticcodeanalysis-flters">
              <li>
                <a href="#sonarlint">Sonar Lint for Eclipse</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="sonarlint" className="tab-pane fade in active">
                <h3>Sonar Lint for Eclipse</h3>
                <p>
                  SonarLint is an IDE extension that helps you detect and fix
                  quality issues as you write code. Like a spell checker,
                  SonarLint squiggles flaws so that they can be fixed before
                  committing code.
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={290a7a84-b8ac-41ff-b7be-5fec67fb357d}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="java-performanceanalysis"
          className="java-performanceanalysis"
        >
          <div className="container">
            <div className="section-title">
              <span>Java Performance analysis</span>
              <h2>Java Performance analysis</h2>
            </div>
            <ul className="nav nav-tabs" id="java-performanceanalysis-flters">
              <li>
                <a href="#jprofiler-crs">JProfiler</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="jprofiler-crs" className="tab-pane fade in">
                <h3>JProfiler</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={ce9cc7b9-9f3b-4391-bfac-9a9e62ea2d4b}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="java-unittestingframework"
          className="java-unittestingframework"
        >
          <div className="container">
            <div className="section-title">
              <span>Unit Testing Framework</span>
              <h2>Unit Testing Framework</h2>
            </div>
            <ul className="nav nav-tabs" id="java-unittestingframework-flters">
              <li>
                <a href="#mockito-utf">Mockito</a>
              </li>
              <li>
                <a href="#cucuzzi-utf">Cucuzzi</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="mockito-utf" className="tab-pane fade in">
                <h3>Mockito</h3>
                <p align="center">
                  <iframe
                    src="Downloads\On_Job_Reference\Unit Testing Framework\Mockito.pdf"
                    width="722"
                    height="565"
                  >
                    Office
                  </iframe>
                </p>

                <h3>Mockito TestCases</h3>
                <p align="center">
                  <video width="600" height="400" controls>
                    <source
                      src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/On_Job_Reference/Unit%20Testing%20Framework/Java/Session%20on%20Mockito%20Testcases%20by%20Pradnya-20211217_153235-Meeting%20Recording.mp4"
                      type="video/mp4"
                    />
                  </video>
                </p>
              </div>
              <div id="cucuzzi-utf" className="tab-pane fade in">
                <h3>Cucuzzi</h3>
                <p align="center">
                  <iframe
                    src="Downloads\On_Job_Reference\Unit Testing Framework\Cucuzzi Test Framework.pdf"
                    width="722"
                    height="565"
                  >
                    Office
                    <a />
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="net-codequalityguidelines"
          className="net-codequalityguidelines"
        >
          <div className="container">
            <div className="section-title">
              <span>Coding Standard</span>
              <h2>Coding Standard</h2>
              <p>
                <em>
                  To build enterprise applications, which are reliable, scalable
                  and maintainable, it is important for development teams to
                  adopt proven design techniques and good coding standards. The
                  adoption of coding standards results in code consistency,
                  which makes it easier to understand, develop and maintain the
                  application. In addition by being aware of and following the
                  right coding techniques at a granular level, the programmer
                  can make the code more efficient and performance effective.
                </em>
              </p>
            </div>
            <ul className="nav nav-tabs" id="net-codequalityguidelines-flters">
              <li className="active">
                <a href="#angular">Angular</a>
              </li>
              <li>
                <a href="#angularbestpractices">Angular - Best Practices</a>
              </li>
              <li>
                <a href="#csharp">C#</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="angular" className="tab-pane fade">
                <h3>Angular</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8cb7cd79-0a9e-445d-9cc2-c4ca585d79e4}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="angularbestpractices" className="tab-pane fade">
                <h3>Angular - Best Practices</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={cb4c2ccb-dafa-4478-8dae-3af06d4ff5e3}&amp;action=embedview&amp;wdAr=1.7777777777777777"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="csharp" className="tab-pane fade">
                <h3>C#</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={385c80dc-cc8a-4262-979e-ac86764e87d1}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="net-codereviewchecklist"
          className="net-codereviewchecklist"
        >
          <div className="container">
            <div className="section-title">
              <span>Code Review Checklist</span>
              <h2>Code Review Checklist</h2>
            </div>
            <ul className="nav nav-tabs" id="net-codereviewchecklist-flters">
              <li className="active">
                <a href="#csharp-crc">C#</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="csharp-crc" className="tab-pane fade in active">
                <h3>C#</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2d1a284d-8b08-4003-91fa-1006c55c7881}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&ed1JS=false"
                  ></iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="net-codereferenceslice" className="net-codereferenceslice">
          <div className="container">
            <div className="section-title">
              <span>Code Reference Slice</span>
              <h2>Code Reference Slice</h2>
            </div>
            <ul className="nav nav-tabs" id="net-codereferenceslice-flters">
              <li>
                <a href="#angular-crs">Angular</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="angular-crs" className="tab-pane fade in">
                <h3>Angular</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={82a26c25-2a5d-4b3a-8137-0bdbd0f2c1d8}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="net-staticcodeanalysis" className="net-staticcodeanalysis">
          <div className="container">
            <div className="section-title">
              <span>Static Code Analysis</span>
              <h2>Static Code Analysis</h2>
            </div>
            <ul className="nav nav-tabs" id="net-staticcodeanalysis-flters">
              <li>
                <a href="#csharp-sca">C#</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="csharp-sca" className="tab-pane fade in active">
                <h3>C#</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f2b282fe-56c9-4983-a874-6d8fc7d8a045}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="net-unittestingframework"
          className="net-unittestingframework"
        >
          <div className="container">
            <div className="section-title">
              <span>Unit Testing Framework</span>
              <h2>Unit Testing Framework</h2>
            </div>
            <ul className="nav nav-tabs" id="net-unittestingframework-flters">
              <li>
                <a href="#javascript-utf">JavaScript</a>
              </li>
              <li>
                <a href="#csharp-utf">C#</a>
              </li>
              <li>
                <a href="#cypress-utf">Cypress</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="javascript-utf" className="tab-pane fade in">
                <h3>Mocha and Chai</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={5ac7066d-e7a6-497e-8914-8216ff120f75}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="csharp-utf" className="tab-pane fade in">
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7da7069a-3de9-441f-9982-da558fa0e295}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="cypress-utf" className="tab-pane fade in">
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c6990911-5c82-4a3f-a19d-b168ff6aec38}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="others-codequalityguidelines"
          className="others-codequalityguidelines"
        >
          <div className="container">
            <div className="section-title">
              <span>Coding Standard</span>
              <h2>Coding Standard</h2>
              <p>
                <em>
                  To build enterprise applications, which are reliable, scalable
                  and maintainable, it is important for development teams to
                  adopt proven design techniques and good coding standards. The
                  adoption of coding standards results in code consistency,
                  which makes it easier to understand, develop and maintain the
                  application. In addition by being aware of and following the
                  right coding techniques at a granular level, the programmer
                  can make the code more efficient and performance effective.
                </em>
              </p>
            </div>
            <ul
              className="nav nav-tabs"
              id="others-codequalityguidelines-flters"
            >
              <li>
                <a href="#python">Python</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="python" className="tab-pane fade in active">
                <h3>Python</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={15afa0fd-0390-4f23-a165-3a6749f6735a}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="others-staticcodeanalysis"
          className="others-staticcodeanalysis"
        >
          <div className="container">
            <div className="section-title">
              <span>Static Code Analysis</span>
              <h2>Static Code Analysis</h2>
              <p>
                <em>
                  To build enterprise applications, which are reliable, scalable
                  and maintainable, it is important for development teams to
                  adopt proven design techniques and good coding standards. The
                  adoption of coding standards results in code consistency,
                  which makes it easier to understand, develop and maintain the
                  application. In addition by being aware of and following the
                  right coding techniques at a granular level, the programmer
                  can make the code more efficient and performance
                  effective.Static code analysis is a method of debugging by
                  examining source code before a program is run. It’s done by
                  analyzing a set of code against a set (or multiple sets) of
                  coding rules.
                </em>
              </p>
            </div>
            <ul className="nav nav-tabs" id="others-staticcodeanalysis-flters">
              <li>
                <a href="#pylint">Pylint for Eclipse</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="pylint" className="tab-pane fade in">
                <h3>Pylint for Eclipse</h3>
                <p>
                  Pylint is a Python static code analysis tool which looks for
                  programming errors, helps enforcing a coding standard, sniffs
                  for code smells and offers simple refactoring suggestions.
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={0068eba4-f112-44c5-83a1-562ff987d0cc}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="others-codereferenceslice"
          className="others-codereferenceslice"
        >
          <div className="container">
            <div className="section-title">
              <span>Code Reference Slice</span>
              <h2>Code Reference Slice</h2>
            </div>
            <ul className="nav nav-tabs" id="others-codereferenceslice-flters">
              <li>
                <a href="#solr-crs">Solr</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="solr-crs" className="tab-pane fade in">
                <h3>Solr</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={56533ec2-495e-4d2a-babd-4a4a7c9933a0}&amp;action=embedview&amp;wdStartOn=1&amp;wdEmbedCode=0"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="others-unittestingframework"
          className="others-unittestingframework"
        >
          <div className="container">
            <div className="section-title">
              <span>Unit Testing Framework</span>
              <h2>Unit Testing Framework</h2>
            </div>
            <ul
              className="nav nav-tabs"
              id="others-unittestingframework-flters"
            >
              <li>
                <a href="#pytest-utf">PyTest</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="pytest-utf" className="tab-pane fade in">
                <h3>PyTest</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={65210795-16fd-449a-800a-97b70bad4a52}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="others-securityawarness"
          className="others-securityawarness"
        >
          <div className="container">
            <div className="section-title">
              <span>Security Awarness</span>
              <h2>Malicious NuGet packages</h2>
            </div>
            <div className="tab-content">
              <p align="center">
                <iframe
                  src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f934e2d7-3b20-4db2-80c1-240148da1db3}&amp;action=embedview"
                  width="722px"
                  height="565px"
                  frameborder="0"
                >
                  This is an embedded{" "}
                  <a target="_blank" href="https://office.com">
                    Microsoft Office
                  </a>{" "}
                  document, powered by{" "}
                  <a target="_blank" href="https://office.com/webapps">
                    Office
                  </a>
                  .
                </iframe>{" "}
              </p>
            </div>
          </div>
        </section>

        {/*< !--< section className="sonarlint" id="sonarlint" >
                                                <h3>Sonar Lint for Eclipse</h3>
                                                <p>SonarLint is an IDE extension that helps you detect and fix quality issues as you write code.
                                                    Like a spell checker, SonarLint squiggles flaws so that they can be fixed before committing code.</p>
                                                <p align="center">
                                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={290a7a84-b8ac-41ff-b7be-5fec67fb357d}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                                </p>
                                            </section >
                                            Sonar Lint

                                            PyLint
                                            < section className="pylint" id="pylint" >
                                                <h3>PyLint for Eclipse</h3>
                                                <p>Pylint is a Python static code analysis tool which looks for programming errors, helps enforcing a coding standard, sniffs for code smells and offers simple refactoring suggestions.</p>
                                                <p align="center">
                                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={0068eba4-f112-44c5-83a1-562ff987d0cc}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                                </p>
                                            </section >
    PyLint-- >*/}

        <section className="ojr-dayindeveloperlife" id="ojr-dayindeveloperlife">
          <h3>A Day in Developer's life</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={5d934581-7362-4833-bf29-65a702275540}&amp;action=embedview&amp;wdAr=1.7777777777777777"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              presentation, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <section className="pullrequestguidelines" id="pullrequestguidelines">
          <h3>Pull Request Guideline</h3>
          <p>
            Code review is a very important part of the software development
            cycle. Pull requests are used to review code on branches before it
            reaches master. It is also one of the most difficult and
            time-consuming part of the software development process, often
            requiring experienced team members to spend time reading, thinking,
            evaluating, and responding to implementations of new features or
            systems.To help your software development team, here are some
            guidelines for your pull requests.
          </p>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8e9ecbdc-e821-4aad-be8a-58e80ac46e41}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <section className="versiononeguidelines" id="versiononeguidelines">
          <div className="container">
            <div className="section-title">
              <span>Version One Guidelines</span>
              <h2>Version One Guidelines</h2>
            </div>
            <ul className="nav nav-tabs" id="versiononeguidelines-flters">
              <li className="active">
                <a href="#agilebestpractices">Agile Best Practices</a>
              </li>
              <li>
                <a href="#estimation">Estimation</a>
              </li>
            </ul>
            <div className="tab-content">
              <div id="agilebestpractices" className="tab-pane fade in active">
                <h3>Agile Best Practices</h3>
                <p> 1. Assign the user story to your name </p>
                <p>
                  {" "}
                  2. Add tasks as in LA Definition of Done , this is to ensure
                  Definition of done is adhered to{" "}
                </p>
                <p> 3. Provide estimate for each task </p>
                <p>
                  {" "}
                  4. Update the effort burnt down for that day & reduce the
                  remaining hours before the Daily stand up{" "}
                </p>
                <p>
                  {" "}
                  5. Utilize “Conversations” to update the details that the
                  feature team should know , for their reference{" "}
                </p>
                <p>
                  {" "}
                  6. Attach the screenshots of UI before & after development ,
                  if the story is for UI changes , where the UX is not provided
                  due to minor changes{" "}
                </p>
                <p>
                  {" "}
                  7. Update “Technical Notes” for Spikes /design changes , for
                  later references{" "}
                </p>
                <p>
                  {" "}
                  8. Tag “Blocker” to the User story with the reason of
                  impediment , when you are unable to proceed with the user
                  story due to dependency. This needs to be called out in
                  Retrospection{" "}
                </p>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1e1e87c7-fcba-4088-a8cf-5c0a50f7b764}&amp;action=embedview&amp;wdAr=1.7777777777777777"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    presentation, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="estimation" className="tab-pane fade">
                <h3>Estimation</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={03327167-4d1f-47a4-a0cb-7033ad16a5d3}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="ladefinitionofdone" id="ladefinitionofdone">
          <h3>LA - Definition of Done</h3>
          <img
            src="assets\img\LA_Definition_Of_Done.jpg"
            width="722px"
            height="565px"
            className="img-thumbnail"
            alt="Responsive image"
          />
        </section>

        <section className="ladefinitionofready" id="ladefinitionofready">
          <h3>LA - Definition of Ready</h3>
          <img
            src="assets\img\LA_Definition_Of_Ready.jpg"
            width="722px"
            height="565px"
            className="img-thumbnail"
            alt="Responsive image"
          />
        </section>

        <section
          className="howtoimprovecodequality"
          id="howtoimprovecodequality"
        >
          <h3>Code Quality Improvement Guidelines</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8608c023-3fc4-4b9b-a455-d1a7bc90fd7a}&amp;action=embedview&amp;wdStartOn=1"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>{" "}
          </p>
        </section>

        <section className="solidprinciples" id="solidprinciples">
          <h3>Solid Principles</h3>
          <p align="center">
            <iframe
              src="Downloads\On_Job_Reference\General\SOLID Principles.pdf"
              width="722"
              height="565"
            >
              Office
              <a />.
            </iframe>
          </p>
        </section>

        <section className="agileguideline" id="agileguideline">
          <h3>Agile Guideline</h3>
          <p align="center">
            <iframe
              src="Downloads\On_Job_Reference\General\AGILEGUIDELINES.pdf"
              width="722"
              height="565"
            >
              Office
              <a />.
            </iframe>
          </p>
        </section>

        <section className="ojr-whatsnext" id="ojr-whatsnext">
          <h3>What's Next</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={bb8fdb25-6ea0-4827-a554-d9966f271599}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <section id="bcp" className="bcp">
          <div className="container">
            <div className="section-title">
              <span>BCP</span>
              <h2>BCP</h2>
            </div>
            <ul className="nav nav-tabs" id="bcp-flters">
              <li className="active">
                <a href="#calltreetest">Call Tree Test</a>
              </li>
              <li>
                <a href="#swt">SWT</a>
              </li>
              <li>
                <a href="#usermanuals">User Manuals</a>
              </li>
              <li>
                <a href="#bcp-curioustoknowmore">Curious to know more !!</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="calltreetest" className="tab-pane fade in active">
                <h3>Call Tree Test</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={13b336af-2cd6-4c59-9392-8bc50babe1c3}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="swt" className="tab-pane fade">
                <h3>Structured Walkthrough Test</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7500084c-20e6-4665-8acb-82a40d17e1ee}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="usermanuals" className="tab-pane fade">
                <h3>User Manuals</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={32f37533-5ca7-47d5-8627-32c7432f5b8b}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="bcp-curioustoknowmore" className="tab-pane fade">
                <h3>Curious to know more !!</h3>
                <p align="center">
                  Associates can explore more about BCP by go through the below
                  courses
                </p>
                <br />
                <table
                  className="table table-sm table-striped"
                  style={{ width: "50%", align: "center" }}
                >
                  <thead>
                    <tr>
                      <th scope="col">Course Code</th>
                      <th scope="col">Course Name</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>COPCO002</td>
                      <td>Business Continuity Management</td>
                    </tr>
                    <tr>
                      <td>COPOS004</td>
                      <td>BCM Cognizance</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        <security id="bc-securitypolicy" className="bc-securitypolicy">
          <h3>Security Policy</h3>
          <p>
            <em>
              Phishing is an attempt to acquire sensitive information such as
              usernames, passwords, business sensitive information, credit card
              details and sometimes, indirectly money as well. Its most often
              intended with malicious reasons, masquerading as a trustworthy
              entity in an electronic communication.
            </em>
          </p>
          <img
            align="center"
            src="assets/img/Phising_img.png"
            width="724px"
            height="380px"
            className="center"
            alt="Responsive image"
          />
          <br />
          <br />
          <ul>
            <li>
              <strong>EXTRA VIGILANCE: COVID-19 SCAM</strong> Indian government
              officials are warning citizens to expect a widespread COVID-19
              phishing attack. The phishing email scam offers free testing to
              residents in major Indian cities. The COVID-19 phishing email is
              designed to steal personal data and financial information. The bad
              actors impersonate local government officials known to be tasked
              with supporting local testing and government aid distribution. The
              attackers create fake email addresses with these officials&rsquo;
              names or spoof the government authorities&rsquo; IDs. (Spoofing is
              the act of disguising a communication from an unknown source as
              being from a known, trusted source.)
            </li>
            <li>
              A cyber security agency with knowledge of this specific attack
              warns: Do not open attachments in unsolicited emails. Do not click
              on URLs in an unsolicited email, even if the link seems benign.
              Cyber security agencies have seen multiple attacks related to
              COVID-19.
            </li>
            <li>
              Every COVID-19 email should be read with skepticism. Question the
              message&rsquo;s intent.
            </li>
            <li>
              Review all parts of the message before acting. Cognizant
              proactively blocks emails from malicious actors. Please use the
              ReportSpam action in Outlook to report this and any other
              suspected phishing attacks.
            </li>
          </ul>
          <h4>Follow below guidance if you receive a suspicious email:</h4>
          <ul>
            <li>
              1. Approach Unsolicited Emails with Skepticism: Interacting with a
              phishing email can launch software, install ransomware, steal your
              stored credentials, etc. Be aware that an email related to
              COVID-19 is likely a phishing attempt.
            </li>
            <li>
              2. Remain Vigilant: Fraudulent messages around vaccine
              information, special offers, breaking news, etc. are all designed
              to deceive you into acting on the promises of the email.
            </li>
            <li>
              3. Question the Message: Cognizant and legitimate organizations
              will never ask for your credentials or sensitive information.
            </li>
            <li>
              4. Analyze the Email: Question the message&rsquo;s intent&mdash;
              see where it originated from, if it was a legitimate domain, and
              analyze all the variables about the message before acting.
            </li>
            <li>
              5. Attachments: Never open or download attachments from unknown
              sources.
            </li>
            <li>
              6. Links: While Cognizant is using email to communicate with
              associates, the messages are also available on BeCognizant. You
              will not be directed to click a link or download a file from the
              email. Cognizant communications will instead direct you to a
              BeCognizant page.
            </li>
            <li>
              7. Videos: Information such as ways you can protect yourself and
              your family should be viewed using personal devices on known,
              trusted websites. If a file promising this information is in a
              video attached to an email, do not open it. Report it.
            </li>
            <li>
              Report suspicious emails using the ReportSpam plugin in Outlook or
              report by sending the suspicious email as an attachment to{" "}
              <a href="mailto:reportspam@cognizant.com">
                reportspam@cognizant.com
              </a>
            </li>
          </ul>
          <br />
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6f207777-646d-4222-860f-0657d2110db6}&amp;action=embedview&amp;wdAr=1.3333333333333333"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              presentation, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
          <h3>Curious to know more !!</h3>
          <p align="center">
            Associates can explore more about Security Policy by go through the
            below courses
          </p>
          <br />
          <table
            className="table table-sm table-striped"
            style={{ width: "50%", align: "center" }}
          >
            <thead>
              <tr>
                <th scope="col">Course Code</th>
                <th scope="col">Course Name</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>CIEHC156</td>
                <td>Secure Application Development</td>
              </tr>
              <tr>
                <td>CIEHC074</td>
                <td>Secure Coding Practices in Java</td>
              </tr>
              <tr>
                <td>BDODA2</td>
                <td>Secure Coding Practices</td>
              </tr>
            </tbody>
          </table>
        </security>

        <section id="trutime" className="trutime">
          <h3>Trutime Guidelines</h3>
          <p>
            <em>
              The TruTime app records your work hours for each day and provides
              a fortnightly, monthly and yearly average of time spent at work.
              While in office, work hours are captured automatically from your
              access card swipe-in and swipe-out. While working from home, work
              hours must be updated/applied using the TopUp feature in the
              TruTime app. As a majority of us continue to work from home, it is
              imperative that each associate record work hours using the TopUp
              feature on the TruTime app regularly. We have noticed a dip in the
              number of working hours for some associates in the past couple of
              months and urge you to maintain compliance. Please note that
              TruTime compliance is mandatory for all India associates.
            </em>
          </p>
          <p>
            <ul>
              <li>
                Log in to TruTime through One Cognizant (1C) and record your
                daily work hours using TopUp. Your updated work-from-home time
                will need to be approved by your project manager.
              </li>
              <li>
                If you are working from a Cognizant facility, always register
                your first swipe-in and last swipe-out of the day at the TruTime
                Readers.
              </li>
              <br />
              <h5>Submission and approval timelines</h5>
              <li>
                TopUp hours can be updated/applied only for the previous 15
                calendar days from the current date. TopUp hours applied over
                and above the auto-approved hours will be routed to your
                respective project manager for approval.
              </li>
              <li>
                TopUp hours that remain unapproved for the first fortnight of
                the previous month will be auto rejected at 10:30 a.m. on the
                4th of every month.
              </li>
              <li>
                TopUp hours that remain unapproved for the second fortnight of
                the previous month will be auto rejected at 10:30 a.m. on the
                18th of every month.
              </li>
              <li>
                If TopUp hours are rejected, they can be resubmitted within two
                business days from the date of rejection. TopUp cannot be
                resubmitted if rejected for the second time.
              </li>
              <li>
                For more information, search for TruTime on Navigator{" "}
                <a href="https://onecognizant.cognizant.com/?globalappid=587">
                  here
                </a>{" "}
                or access the user guide{" "}
                <a href="https://ecm.cognizant.com/cs/idcplg?IdcService=GET_FILE&RevisionSelectionMethod=Latest&dDocName=ctsecmin_25583931&Rendition=web&allowInterrupt=1&noSaveAs=1&fileName=ctsecmin_25583931.pdf">
                  here
                </a>
                .
              </li>
            </ul>
          </p>
        </section>

        <section id="timesheet" className="timesheet">
          <h3>Timesheet Guidelines</h3>
          <h5>
            <b>Associate with Billable assignment in LN_LA_Development</b>
          </h5>
          <p>
            <em>
              Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated
              in any of the projects within the account
            </em>
          </p>
          <p>
            <em>
              Associate can see his allocation in “View Assignment” app in 1C.
            </em>
          </p>
          <b>Timesheet submission guidelines:</b>
          <ul>
            <li>
              If the associate is tagged against LN-LA-Development, then the
              associate will have to submit LN timesheet.
            </li>
            <li>
              The timesheet entries should be verified using the timesheet
              guideline mail received every Friday.
            </li>
            <li>
              No of days submitted in Cognizant Timesheet should always be equal
              to no of days submitted in LN Timesheet
            </li>
            <li>
              In case of a planned & approved leave, leave should be applied in
              1C and timesheet should be submitted without the entry for the
              leave date.
            </li>
            <li>
              In case if a leave is not approved, and compensation is planned,
              then timesheet in LN should be submitted as a usual business day,
              in Cognizant timesheet, 8 hours should be added against the date
              on which the compensation is done.
            </li>
          </ul>
          <br />
          <h5>
            <b>Associate with Buffer/NBL assignment in LN_LA_Development</b>
          </h5>
          <p>
            <em>
              Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated
              in entirely in LN_LA_Development project or partially in
              LN_LA_Development.
            </em>
          </p>
          <p>
            <em>
              Associate can see his allocation in “View Assignment” app in 1C.
            </em>
          </p>
          <b>Timesheet submission guidelines:</b>
          <ul>
            <li>
              Buffer associate will be guided by the their team’s leave POC.
            </li>
            <li>If the associate is tagged only against LN-LA-Development,</li>
            <ul>
              <li>
                Then the associate will have to submit LN timesheet on the days
                given by the timesheet POC. Other days can be left blank.
              </li>
              <li>
                Similarly, in Cognizant timesheet, it should be submitted as
                billable only on the days given by timesheet POC, other days
                should be entered as Non billable.
              </li>
            </ul>
            <li>
              If the associate is tagged in multiply projects including
              LN-LA-Development,
            </li>
            <ul>
              <li>
                Then the associate will have to submit LN timesheet on the days
                given by the timesheet POC. Other days can be left blank.
              </li>
              <li>
                In Cognizant timesheet, it should be submitted as billable only
                on the days given by timesheet POC, other days should be entered
                as Billable in the other project where the associate has
                allocation.
              </li>
            </ul>
          </ul>
          <br />
          <h5>
            <b>
              Associate with Billable assignment in projects other than
              LN_LA_Development
            </b>
          </h5>
          <p>
            <em>
              Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated
              in any of the projects within the account
            </em>
          </p>
          <p>
            <em>
              Associate can see his allocation in “View Assignment” app in 1C.
            </em>
          </p>
          <b>Timesheet submission guidelines:</b>
          <ul>
            <li>
              If the associate is not tagged against LN-LA-Development, then the
              associate will not have to submit LN timesheet.
            </li>
            <li>
              In case of a planned & approved leave, leave should be applied in
              1C and timesheet should be submitted without the entry for the
              leave date.
            </li>
            <li>
              In case if a leave is not approved, and compensation is planned,
              in Cognizant timesheet, 8 hours should be added against the date
              on which the compensation is done. Entry for the day on which the
              leave is taken can be left as blank.
            </li>
          </ul>
        </section>

        <section id="orgmandatorycourses" className="orgmandatorycourses">
          <div className="container">
            <div className="section-title">
              <span>Org Mandatory Courses</span>
              <h2>Org Mandatory Courses</h2>
              <p align="justify">
                <em>
                  <b>
                    <u>Acceptable Use Policy </u>
                  </b>
                  This policy sets forth the Cognizant mandates with respect to
                  the acceptable and unacceptable usage of Cognizant and
                  Cognizant's Clients' information and information technology
                  resources.
                </em>
              </p>
              <br />
              <p align="justify">
                <em>
                  <b>
                    <u>Core Values and Standards of Business Conduct </u>
                  </b>
                  Cognizant expects all its associates to adhere to and uphold
                  the Core Values and Standards of Business Conduct (COBE).
                  Every Associate working with Cognizant is expected to take all
                  the possible steps to ensure and protect the interest of
                  Cognizant, discharge his/her duties with utmost integrity,
                  honesty, devotion and diligency and also to refrain from doing
                  anything which is inappropriate and unacceptable at Cognizant
                </em>
              </p>
              <br />
              <p align="justify">
                All associates are expected to complete the courses every year
              </p>
              <table
                className="table table-sm table-striped"
                style={{ width: "80%", align: "center" }}
              >
                <thead>
                  <tr>
                    <th scope="col">Course Code</th>
                    <th scope="col">Course Name</th>
                    <th scope="col">Applicability</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center">NA</td>
                    <td align="center">
                      <a
                        href="https://cognizant.kpoint.com/app/video/gcc-8ce69950-12c8-4ff1-80d9-580f4e7a3b1d"
                        target="_blank"
                      >
                        General Security Awareness Webinar{" "}
                      </a>
                      <a />
                    </td>
                    <td align="center">All Associates</td>
                  </tr>
                  <tr>
                    <td align="center">NA</td>
                    <td align="center">
                      <a
                        href="https://cognizant.kpoint.com/app/playlist/9054"
                        target="_blank"
                      >
                        Phishing Awareness video series
                      </a>
                    </td>
                    <td align="center">All Associates</td>
                  </tr>
                  <tr>
                    <td align="center">BQVCA2</td>
                    <td align="center">Acceptable Use Policy</td>
                    <td align="center">All Associates</td>
                  </tr>
                  <tr>
                    <td align="center">AIEIM018</td>
                    <td align="center">
                      Legal Systems - KNOWLEDGE BASED ASSESSMENT [101-BASICS]
                    </td>
                    <td align="center">All associates</td>
                  </tr>
                  <tr>
                    <td align="center">BQVCC1</td>
                    <td align="center">
                      Core Values and Standards of Business Conduct
                    </td>
                    <td align="center">All associates up to SA level</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          {/*<!--<img src="assets\img\LA Product suite.png" className="img-thumbnail" alt="Responsive image">--></img>*/}
        </section>

        <section id="defectpreventionplan" className="defectpreventionplan">
          <div className="container">
            <div className="section-title">
              <span>Defect Prevention Plan</span>
              <h2>Defect Prevention Plan</h2>
              <p align="justify">
                <em>
                  Defect Prevention Plan helps us to identify the actual reason
                  on the Defect and to take necessary preventive actions to make
                  sure that it will not happen again.
                </em>
              </p>
              <br />
              <p align="justify">
                To explore more about the Defect Prevention Plan, Please go
                through the below course
              </p>
              <br />
              <table
                className="table table-sm table-striped"
                style={{ width: "80%", align: "center" }}
              >
                <thead>
                  <tr>
                    <th scope="col">Course Code</th>
                    <th scope="col">Course Name</th>
                    <th scope="col">Applicability</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center">PS0242</td>
                    <td align="center">Defect Prevention Plan</td>
                    <td align="center">All Associates</td>
                  </tr>
                </tbody>
              </table>
            </div>
            {/*   <!--<img src="assets\img\LA Product suite.png" className="img-thumbnail" alt="Responsive image">--></img>*/}
          </div>
        </section>

        <section className="bc-whatsnext" id="bc-whatsnext">
          <h3>What's Next</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d7e86d05-ce23-429f-a43f-6b1b26e5eefa}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>

        <div className="section-title">
          <div id="lntt" className="tab-pane fade in active">
            <h2>Technical Materials</h2>
          </div>
          <ul className="nav nav-tabs" id="training-flters">
            <li className="active">
              <a href="#lntt">Lexis Nexis Tech Talk</a>
            </li>
          </ul>
          <p className="tab-content">
            <h5>GraphQL</h5>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={358140ab-eb06-4552-97e7-b78877ffe387}&amp;action=embedview"
                width="722"
                height="565"
                frameborder="0"
              >
                This is an embedded{" "}
                <a target="_blank" href="https://office.com">
                  Microsoft Office
                </a>{" "}
                document, powered by{" "}
                <a target="_blank" href="https://office.com/webapps">
                  Office
                </a>
                .
              </iframe>
            </p>
            <h3>Debezium</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9c175e2d-df98-47fd-80ae-65d2df48aae9}&amp;action=embedview"
                width="722"
                height="565"
              >
                Debezium
                <a />.
              </iframe>
            </p>
            <h3>AWSMacie</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1dc344f8-360e-4644-99b7-cf5352392cc8}&amp;action=embedview"
                width="722px"
                height="565px"
                frameborder="0"
              >
                <a>AWSMacie</a>.
              </iframe>
            </p>
            <h3>AzureAPIManagement</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={a7d838e1-e046-4dd7-8de4-4561c801c853}&amp;action=embedview"
                width="722"
                height="565"
              >
                AzureAPIManagement
                <a />.
              </iframe>
            </p>

            <h3>LightHouse</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f22c3b7a-eedf-48aa-8690-426c1dea4d6f}&amp;action=embedview"
                width="772"
                height="565"
                frameborder="0"
              >
                <a>LightHouse</a>.
              </iframe>
            </p>

            <h3>Yarn</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9f138012-17a4-41cb-9af3-a988c37a6336}&amp;action=embedview"
                width="772"
                height="565"
                frameborder="0"
              >
                <a>Yarn</a>.
              </iframe>
            </p>

            <h3>AzureDoor</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e5bb125a-df5f-4c1b-a436-9964c9ab68a7}&amp;action=embedview"
                width="772"
                height="565"
                frameborder="0"
              >
                <a>AzureDoor</a>.
              </iframe>
            </p>

            <h3>Application Gateway</h3>
            <p align="center">
              <iframe
                src="https://cognizantonline-my.sharepoint.com/personal/2116805_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={984cf91b-43af-4151-9ced-885ff15bd453}&amp;action=embedview"
                width="772"
                height="565"
                frameborder="0"
              >
                <a>Application Gateway</a>.
              </iframe>
            </p>
          </p>
        </div>

        <section id="modulelead" className="modulelead">
          <div className="container">
            <div className="section-title">
              <span>Module Lead</span>
              <h2>Module Lead</h2>
            </div>
            <ul className="nav nav-tabs" id="modulelead-flters">
              <li>
                <a href="#ml-handoverTurnoverDocumentTemplate">
                  HandOver TurnOver Document Template
                </a>
              </li>
              <li>
                <a href="#ml-rootcauseanalysis">Root Cause Analysis</a>
              </li>
              <li>
                <a href="#ml-trainingPlanTemplate">Training Plan Template</a>
              </li>
              <li>
                <a href="#ml-skillSetMatrixTemplate">
                  SkillSet Matrix Template
                </a>
              </li>
              <li>
                <a href="#ml-whatsnext">What's Next</a>
              </li>
            </ul>

            <div className="tab-content">
              <div
                id="ml-handoverTurnoverDocumentTemplate"
                className="tab-pane fade in"
              >
                <h3>HandOver TurnOver Document Template</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2f2c4a35-176a-4446-9fc6-dbdda9b14240}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="ml-rootcauseanalysis" className="tab-pane fade in">
                <h3>Root Cause Analysis</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={38cf173b-bc82-404c-a431-7a7ca3a09057}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"
                  ></iframe>
                </p>
              </div>
              <div id="ml-trainingPlanTemplate" className="tab-pane fade in">
                <h3>Training Plan Template</h3>
                <p align="center">
                  <iframe
                    width="722"
                    height="565"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6a0996ee-b4b5-4120-aff9-cf5784355cbe}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"
                  ></iframe>
                </p>
              </div>
              <div id="ml-skillSetMatrixTemplate" className="tab-pane fade in">
                <section
                  id="skillSetMatrixTemplate"
                  className="skillSetMatrixTemplate"
                >
                  <div className="container">
                    <div className="section-title">
                      <span>SkillSet Matrix Template</span>
                      <h2>SkillSet Matrix Template</h2>
                    </div>
                    <ul
                      className="nav nav-tabs"
                      id="skillSetMatrixTemplate-flters"
                    >
                      <li className="active">
                        <a href="#javaskillSetMatrixTemplate">Java</a>
                      </li>
                      <li>
                        <a href="#DotNetskillSetMatrixTemplate">.Net</a>
                      </li>
                    </ul>
                    <div className="tab-content">
                      <div
                        id="javaskillSetMatrixTemplate"
                        className="tab-pane fade in active"
                      >
                        <h3>Java</h3>
                        <p align="center">
                          <iframe
                            width="722"
                            height="565"
                            frameborder="0"
                            scrolling="no"
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={84e10542-32da-4c55-8743-03ee8aea5946}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"
                          ></iframe>
                        </p>
                      </div>
                      <div
                        id="DotNetskillSetMatrixTemplate"
                        className="tab-pane fade in active"
                      >
                        <h3>.Net</h3>
                        <p align="center">
                          <iframe
                            width="722"
                            height="565"
                            frameborder="0"
                            scrolling="no"
                            src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f64e78ec-f770-450a-b911-c188c9a4a06f}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"
                          ></iframe>
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
              <div id="ml-whatsnext" className="tab-pane fade in">
                <h3>What's Next</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={59d0d760-937f-4c2b-9d1a-01645bd234be}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="projectlead" className="projectlead">
          <div className="container">
            <div className="section-title">
              <span>Project Lead</span>
              <h2>Project Lead</h2>
            </div>
            <ul className="nav nav-tabs" id="projectlead-flters">
              <li className="active">
                <a href="#plresponsibilities">Roles and Responsibilities</a>
              </li>
              <li>
                <a href="#plhandover">Handover Turnover Template</a>
              </li>
              <li>
                <a href="#plskillsetmatrix">Skillset Matrix Template</a>
              </li>
              <li>
                <a href="#pl-whatsnext">What's Next</a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="plresponsibilities" className="tab-pane fade in active">
                <h3>Roles and Responsibilities</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3e117a46-4578-4606-8085-53f0288d6310}&amp;action=embedview&amp;wdStartOn=1"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="plhandover" className="tab-pane fade in active">
                <h3>Handover Turnover Template</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={47d88a9d-cd01-4c2c-a4ff-73203fe89990}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
              <div id="plskillsetmatrix" className="tab-pane fade in active">
                <h3>Skillset Matrix Template</h3>
                <p align="center">
                  <iframe
                    width="722px"
                    height="565px"
                    frameborder="0"
                    scrolling="no"
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f004b0b9-72bf-4ff7-86c4-87e45ae39697}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&waccluster=IN4&edesNext=False&resen=True"
                  ></iframe>
                </p>
              </div>
              <div id="pl-whatsnext" className="tab-pane fade in">
                <h3>What's Next</h3>
                <p align="center">
                  <iframe
                    src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={59d0d760-937f-4c2b-9d1a-01645bd234be}&amp;action=embedview"
                    width="722px"
                    height="565px"
                    frameborder="0"
                  >
                    This is an embedded{" "}
                    <a target="_blank" href="https://office.com">
                      Microsoft Office
                    </a>{" "}
                    document, powered by{" "}
                    <a target="_blank" href="https://office.com/webapps">
                      Office
                    </a>
                    .
                  </iframe>
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          className="java-evaluationtemplate"
          id="java-evaluationtemplate"
        >
          <h3>Evaluation Template - Java</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7532ffe8-7307-4e42-9f34-1e8364bf11aa}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>
        <section className="net-evaluationtemplate" id="net-evaluationtemplate">
          <h3>Evalualtion Template - .Net</h3>
          <p align="center">
            <iframe
              width="722"
              height="565"
              frameborder="0"
              scrolling="no"
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3e10b6a5-b035-48f0-a606-f5f9093a30be}&action=embedview&wdAllowInteractivity=False&wdDownloadButton=True&wdInConfigurator=True"
            ></iframe>
          </p>
        </section>
        <section className="pmr-template" id="pmr-template">
          <h3>PMR Template</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={06782c41-250d-4008-880e-d5d65737f694}&amp;action=embedview&amp;wdAr=1.7777777777777777&amp;wdEaa=0"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              presentation, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>
        <section className="cii-igniter" id="cii-igniter">
          <h3>CII Igniter Sessions</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e04306c6-ad1c-40fc-b6e0-ea95280d8129}&amp;action=embedview&amp;wdAr=1.7777777777777777"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              presentation, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>
        <section
          className="roles-responsibilities-manager"
          id="roles-responsibilities-manager"
        >
          <h3>Roles and Responsibilities of Manager</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={ad473b98-83ca-4f37-b191-7c8094803446}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>
        <section className="pmh-whatsnext" id="pmh-whatsnext">
          <h3>What's Next</h3>
          <p align="center">
            <iframe
              src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={92d8bbf2-6bbc-400b-9a76-2d85c718c2b6}&amp;action=embedview"
              width="722px"
              height="565px"
              frameborder="0"
            >
              This is an embedded{" "}
              <a target="_blank" href="https://office.com">
                Microsoft Office
              </a>{" "}
              document, powered by{" "}
              <a target="_blank" href="https://office.com/webapps">
                Office
              </a>
              .
            </iframe>
          </p>
        </section>
      </main>

      <footer id="footer">
        <div className="container">
          <h3>Cognizant</h3>

          <div className="copyright">
            &copy; Copyright{" "}
            <strong>
              <span>Cognizant</span>
            </strong>
            . All Rights Reserved
          </div>
        </div>
      </footer>
    </>
  );
}

export default Content;
