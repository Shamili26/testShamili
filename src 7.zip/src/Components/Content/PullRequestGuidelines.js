import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function PullRequestGuidelines() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/PullRequestGuidelines').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section className="pullrequestguidelines" id="pullrequestguidelines">
                <h3>Pull Request Guideline</h3>
                <p>Code review is a very important part of the software development cycle. Pull requests are used to review code on branches before it reaches master. It is also one of the most difficult and time-consuming part of the software development process, often requiring experienced team members to spend time reading, thinking, evaluating, and responding to implementations of new features or systems.To help your software development team, here are some guidelines for your pull requests.</p>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8e9ecbdc-e821-4aad-be8a-58e80ac46e41}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>

            <Footer/>

        </>
    )
}