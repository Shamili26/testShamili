import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

function OverviewOfLaw() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OverviewOfLaw').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section id="overviewoflaw" className="overviewoflaw">
                <div className="container">
                    <div className="section-title">
                        {/* <span>Overview of Law</span> */}
                        <h2>Overview of Law</h2>
                    </div>
                    <ul className="nav nav-tabs" id="overviewoflaw-flters">
                        <li className="active"><a href="#whatislaw">Law</a></li>
                        <li><a href="#typesoflaw">Types of Law</a></li>
                        <li><a href="#whoexecuteslaw">Who executes Law</a></li>
                        <li><a href="#howdolawyerswork">How do Lawyers Work</a></li>
                        <li><a href="#whohelplawyersprotectthelaw">How Lawyers Protect the Law</a></li>
                        <li><a href="#paralegal">Paralegal</a></li>
                    </ul>

                    <div className="tab-content">
                      {/*  <div id="whatislaw" className="tab-pane fade in active"> */}
                      <div id="whatislaw">
                            <h3>What is Law</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={a511b2b5-8928-46a9-93b3-89450d6129fd}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="typesoflaw" className="tab-pane fade">
                            <h3>Types of Law</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c61b02a8-7d2c-448e-a3f5-a300074bca95}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="whoexecuteslaw" className="tab-pane fade">
                            <h3>Who executes Law</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={571e8c65-cb3d-4f06-8129-8bbeea048d01}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="howdolawyerswork" className="tab-pane fade">
                            <h3>How do Lawyers work</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6018afe8-76a6-4906-b880-8a39722d7295}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="whohelplawyersprotectthelaw" className="tab-pane fade">
                            <h3>Who help Lawyers protect the law</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={be446fc3-092f-4afc-92b9-f83f0d0a2231}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="paralegal" className="tab-pane fade">
                            <h3>Paralegal</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e6107045-c78b-4dff-91e5-27976d2d140d}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            <Footer/>
        </>

    )
}
export default OverviewOfLaw;