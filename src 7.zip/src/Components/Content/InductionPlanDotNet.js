import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function InductionPlanDotNet() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/InductionPlanDotNet').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section className="net-inductionplan" id="net-inductionplan">
                <h3>Induction Plan - .Net</h3>
                <p><em>As part of Induction , the new joiners will be trained on LA specific technolgies along with Org manadate which the associate should be compliant. This Induction plan comprises of technical trainings, LA Functional trainings and Assessment details. The topics are categorized as "Self Training" , "Mentor Instructed" & "Instructor led". Training materials are available in playbook for reference.we have both detailed induction  and induction lite template available for associates. Please contact your mentor for induction type chosen.</em></p>
                <p align="center">
                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={839a1d26-5168-44b2-bb92-efaddcb2052d}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True"></iframe>
                </p>
            </section>

            <Footer/>

        </>
    )
}