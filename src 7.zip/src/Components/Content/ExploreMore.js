
import Footer from '../Home/Footer';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from './ContentNewHeader';

function ExploreMore()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/ExploreMore').then((response) => {

        }
        )
    }, [])

    return (
        <>
        <ContentNewHeader/>
        <section id="la-exploremore" className="la-exploremore">
                    <div className="container">
                        <div className="section-title">
                            <h2>Explore More !!</h2>
                        </div>
                        <ul className="nav nav-tabs" id="la-exploremore-flters">
                            <li className="active"><a href="#deliveringfuture">Delivering the future of Legal Research</a></li>
                            <li><a href="#howtousela">How to use Legal Advance</a></li>
                            <li><a href="#exploringlexisplus">Exploring Lexis+</a></li>
                            <li><a href="#seelexisplus">See Lexis+ for yourself</a></li>
                            <li><a href="#laquicklaw">LA QuickLaw Tutorial</a></li>
                            <li><a href="#shepardizing">Introduction to Shepardizing</a></li>
                            <li><a href="#workfolders">WorkFolders</a></li>
                            <li><a href="#termsandconnectors">Terms & Connectors</a></li>
                            <li><a href="#ravelview">Ravel View</a></li>
                            <li><a href="#lpaforms">LPA Forms</a></li>
                            <li><a href="#histandrmap">History & Research Map</a></li>
                            <li><a href="#booleansearching">Boolean Searching</a></li>
                            <li><a href="#canadianlegislative">Canadian Legislative Pulse</a></li>
                            <li><a href="#headnotes">HeadNotes</a></li>
                            <li><a href="#copycitation">Copy Citation</a></li>
                            <li><a href="#lacontext">Context</a></li>
                            <li><a href="#laalerts">Alerts</a></li>
                            <li><a href="#lacourtlink">Courtlink</a></li>
                            <li><a href="#lalpa">LPA</a></li>
                            <li><a href="#lalexisoverview">Lexis Overview</a></li>
                            <li><a href="#laintrotolexisplus">Introduction to Lexis+</a></li>
                            <li><a href="#contextattorney">Context Attorney Analytics</a></li>
                            <li><a href="#judgecourtanalytics">Judge & Court Analytics</a></li>
                            <li><a href="#courtlinkov">Courtlink Overview</a></li>
                            <li><a href="#searchcapabilities">LA - Search Capabilities</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="deliveringfuture" className="tab-pane fade">
                                <h3>LexisNexis: Delivering the Future of Legal Research</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/u1J2z5j0yyA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="howtousela" className="tab-pane fade">
                                <h3>How to Use Lexis Advance</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/ob68qgEbDgE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="exploringlexisplus" className="tab-pane fade">
                                <h3>Exploring Lexis+</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/VHcP8_MfpUk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="seelexisplus" className="tab-pane fade">
                                <h3>See Lexis+ for Yourself</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/KRfRLDODMyw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="courtlinkov" className="tab-pane fade">
                                <h3>Courtlink Overview</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/QiZHndXQIHQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="judgecourtanalytics" className="tab-pane fade">
                                <h3>Judge & Court Analytics</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/fSNXN0AfEVc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="contextattorney" className="tab-pane fade">
                                <h3>Context Attorney Analytics</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/Y_crEnE9-NY&list=PLvUHkxs32huWAHlqu966Y4bRoxkshd1u2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="laintrotolexisplus" className="tab-pane fade">
                                <h3>Introduction to Lexis+</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/QFFXF9tYc-A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="lalexisoverview" className="tab-pane fade">
                                <h3>Lexis Overview</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/QXqz8sXQ9Lw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="lalpa" className="tab-pane fade">
                                <h3>LPA</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/1v3Y3R3cjT0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="lacourtlink" className="tab-pane fade">
                                <h3>Courtlink</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/Ti10l82x_tk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="laalerts" className="tab-pane fade">
                                <h3>Alerts</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/sa3_Qe8M9OE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="lacontext" className="tab-pane fade">
                                <h3>LA Context</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/6bb712CzHEA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="copycitation" className="tab-pane fade">
                                <h3>Copy Citation</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/jNtxsci1h9c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="headnotes" className="tab-pane fade">
                                <h3>Head Notes</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/7bagONYyAd8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="canadianlegislative" className="tab-pane fade">
                                <h3>Canadian Legislative Pulse</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/WxGSbceMfWQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="booleansearching" className="tab-pane fade">
                                <h3>Boolean Searching</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/3wUa0Wp58SQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="histandrmap" className="tab-pane fade">
                                <h3>History & Research Maps</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/o-Q-_82EI-4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="lpaforms" className="tab-pane fade">
                                <h3>LPA Forms</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/k-aQHSH_-Ak" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="ravelview" className="tab-pane fade">
                                <h3>Ravel View</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/hkMDqm7JE2s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="laquicklaw" className="tab-pane fade">
                                <h3>LA QuickLaw Tutorial</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/Ud6Xhz6l324" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="shepardizing" className="tab-pane fade">
                                <h3>Introduction to Shepardizing</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/Rsl7mlwDq4Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="workfolders" className="tab-pane fade">
                                <h3>WorkFolders</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/zHEqj7ux8K0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="termsandconnectors" className="tab-pane fade">
                                <h3>Terms & Connectors</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="https://www.youtube.com/embed/SigKGfz28Rs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </p>
                            </div>
                            <div id="searchcapabilities" className="tab-pane fade">
                                <h3>Search Capabilities</h3>
                                <p align="center">
                                    <iframe width="722" height="565" src="Downloads\On_Job_Reference\General\LA Search Capabilities.pdf" title="LA Search Capabilities" frameborder="0" ></iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer/>
                </>

             
    )
}

export default ExploreMore; 