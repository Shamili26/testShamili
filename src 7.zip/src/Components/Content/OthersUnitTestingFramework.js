import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OthersUnitTestingFramework()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OthersUnitTestingFramework').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>

        <section id="others-unittestingframework" className="others-unittestingframework">
                    <div className="container">
                        <div className="section-title">
                            <span>Unit Testing Framework</span>
                            <h2>Unit Testing Framework</h2>
                        </div>
                        <ul className="nav nav-tabs" id="others-unittestingframework-flters">
                            <li><a href="#pytest-utf">PyTest</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="pytest-utf" className="tab-pane fade in">
                                <h3>PyTest</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={65210795-16fd-449a-800a-97b70bad4a52}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>

                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}