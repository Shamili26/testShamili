import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function ProjectLead()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/ProjectLead').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>

        <section id="projectlead" className="projectlead">
                    <div className="container">
                        <div className="section-title">
                            <span>Project Lead</span>
                            <h2>Project Lead</h2>
                        </div>
                        <ul className="nav nav-tabs" id="projectlead-flters">
                            <li className="active"><a href="#plresponsibilities">Roles and Responsibilities</a></li>
                            <li><a href="#plhandover">Handover Turnover Template</a></li>
                            <li><a href="#plskillsetmatrix">Skillset Matrix Template</a></li>
                            <li><a href="#pl-whatsnext">What's Next</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="plresponsibilities" className="tab-pane fade in active">
                                <h3>Roles and Responsibilities</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3e117a46-4578-4606-8085-53f0288d6310}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>
                            <div id="plhandover" className="tab-pane fade in active">
                                <h3>Handover Turnover Template</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={47d88a9d-cd01-4c2c-a4ff-73203fe89990}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>
                            <div id="plskillsetmatrix" className="tab-pane fade in active">
                                <h3>Skillset Matrix Template</h3>
                                <p align="center"><iframe width="722px" height="565px" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f004b0b9-72bf-4ff7-86c4-87e45ae39697}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&waccluster=IN4&edesNext=False&resen=True"></iframe></p>
                            </div>
                            <div id="pl-whatsnext" className="tab-pane fade in">
                                <h3>What's Next</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={59d0d760-937f-4c2b-9d1a-01645bd234be}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}