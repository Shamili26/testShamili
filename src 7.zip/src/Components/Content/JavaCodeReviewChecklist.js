import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaCodeReviewChecklist()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaCodeReviewChecklist').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="java-codereviewchecklist" className="java-codereviewchecklist">
                    <div className="container">
                        <div className="section-title">
                            <span>Code Review Checklist</span>
                            <h2>Code Review Checklist</h2>
                        </div>
                        <ul className="nav nav-tabs" id="java-codereviewchecklist-flters">
                            <li className="active"><a href="#java-crc">Java</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="java-crc" className="tab-pane fade in active">
                                <h3>Java</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e9a9873e-0700-4fb6-b4fe-8f189161079f}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>

        </>
    )
}