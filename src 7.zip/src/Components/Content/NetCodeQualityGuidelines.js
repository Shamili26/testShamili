import Footer from "../Home/Footer"
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader"

export default function NetCodeQualityGuidelines()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetCodeQualityGuidelines').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section id="net-codequalityguidelines" className="net-codequalityguidelines">
                <div className="container">
                    <div className="section-title">
                        <span>Coding Standard</span>
                        <h2>Coding Standard</h2>
                        <p><em>To build enterprise applications, which are reliable, scalable and maintainable, it is important for
                            development teams to adopt proven design techniques and good coding standards. The adoption of
                            coding standards results in code consistency, which makes it easier to understand, develop and maintain
                            the application. In addition by being aware of and following the right coding techniques at a granular
                            level, the programmer can make the code more efficient and performance effective.</em></p>
                    </div>
                    <ul className="nav nav-tabs" id="net-codequalityguidelines-flters">
                        <li className="active"><a href="#angular">Angular</a></li>
                        <li><a href="#angularbestpractices">Angular - Best Practices</a></li>
                        <li><a href="#csharp">C#</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="angular" className="tab-pane fade">
                            <h3>Angular</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8cb7cd79-0a9e-445d-9cc2-c4ca585d79e4}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                        </div>
                        <div id="angularbestpractices" className="tab-pane fade">
                            <h3>Angular - Best Practices</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={cb4c2ccb-dafa-4478-8dae-3af06d4ff5e3}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="csharp" className="tab-pane fade">
                            <h3>C#</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={385c80dc-cc8a-4262-979e-ac86764e87d1}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                        </div>
                    </div>
                </div>
            </section>

            <Footer/>

        </>
    )
}