
import Footer from '../Home/Footer';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from './ContentNewHeader';



function KnowYourMentor() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/KnowYourMentor').then((response) => {

        }
        )
    }, [])

    return (

        <>
        <ContentNewHeader/>
        <section id="knowyourmentor" className="knowyourmentor">
            <div className="container">

                <div className="section-title">
                    <span>Know Your Mentor</span>
                    <h2>Know Your Mentor</h2>
                    <p>Once associates got on boarded to LA program, they get to know about their mentor through 'Know Your Mentor' program. Associates can clarify both technical and project related queries such as onboarding activities, timesheet submission, and other org initiatives with their Mentor. On the absence of mentor/trainer, Associates can reach out to their supervisors for any queries that needs immediate attention. Associates can find the below document to get to know about organization structure of the project.</p>
                    <br />
                    <p>
                        <iframe src="https://cognizantonline-my.sharepoint.com/:p:/r/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc=%7BFEB71777-3F35-456C-A4AA-0DD02348677A%7D&file=LN-LA-Development_Cognizant_Org_Chart.pptx&action=edit&mobileredirect=true" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a></iframe>
                    </p>



                </div>
            </div>
        </section>

        <Footer/>



    </>
    )


}

export default KnowYourMentor; 