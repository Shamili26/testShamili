import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaUnitTestingFramework()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaUnitTestingFramework').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>

        <section id="java-unittestingframework" className="java-unittestingframework">
                    <div className="container">
                        <div className="section-title">
                            <span>Unit Testing Framework</span>
                            <h2>Unit Testing Framework</h2>
                        </div>
                        <ul className="nav nav-tabs" id="java-unittestingframework-flters">
                            <li><a href="#mockito-utf">Mockito</a></li>
                            <li><a href="#cucuzzi-utf">Cucuzzi</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="mockito-utf" className="tab-pane fade in">
                                <h3>Mockito</h3>
                                <p align="center">
                                    <iframe src="Downloads\On_Job_Reference\Unit Testing Framework\Mockito.pdf" width="722" height="565">Office</iframe></p>

                                <h3>Mockito TestCases</h3>
                                <p align="center">
                                    <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/On_Job_Reference/Unit%20Testing%20Framework/Java/Session%20on%20Mockito%20Testcases%20by%20Pradnya-20211217_153235-Meeting%20Recording.mp4" type="video/mp4" /></video>
                                </p>
                            </div>
                            <div id="cucuzzi-utf" className="tab-pane fade in">
                                <h3>Cucuzzi</h3>
                                <p align="center">
                                    <iframe src="Downloads\On_Job_Reference\Unit Testing Framework\Cucuzzi Test Framework.pdf" width="722" height="565">Office<a /></iframe>
                                </p>

                            </div>
                        </div>
                    </div>
                </section >

                <Footer/>
        
        </>
    )
}