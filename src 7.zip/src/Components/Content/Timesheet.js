import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function Timesheet() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/Timesheet').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section id="timesheet" className="timesheet">
                <h3>Timesheet Guidelines</h3>
                <h5><b>Associate with Billable assignment in LN_LA_Development</b></h5>
                <p>
                    <em>Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated in any of the projects within the account</em>
                </p>
                <p>
                    <em>Associate can see his allocation in “View Assignment” app in 1C.</em>
                </p>
                <b>Timesheet submission guidelines:</b>
                <ul>
                    <li>If the associate is tagged against LN-LA-Development, then the associate will have to submit LN timesheet.</li>
                    <li>The timesheet entries should be verified using the timesheet guideline mail received every Friday.</li>
                    <li>No of days submitted in Cognizant Timesheet should always be equal to no of days submitted in LN Timesheet</li>
                    <li>In case of a planned & approved leave, leave should be applied in 1C and timesheet should be submitted without the entry for the leave date.</li>
                    <li>In case if a leave is not approved, and compensation is planned, then timesheet in LN should be submitted as a usual business day, in Cognizant timesheet, 8 hours should be added against the date on which the compensation is done.</li>
                </ul>
                <br />
                <h5><b>Associate with Buffer/NBL assignment in LN_LA_Development</b></h5>
                <p>
                    <em>Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated in entirely in LN_LA_Development project or partially in LN_LA_Development.</em>
                </p>
                <p>
                    <em>Associate can see his allocation in “View Assignment” app in 1C.</em>
                </p>
                <b>Timesheet submission guidelines:</b>
                <ul>
                    <li>Buffer associate will be guided by the their team’s leave POC.</li>
                    <li>If the associate is tagged only against LN-LA-Development,</li>
                    <ul>
                        <li>Then the associate will have to submit LN timesheet on the days given by the timesheet POC. Other days can be left blank.</li>
                        <li>Similarly, in Cognizant timesheet, it should be submitted as billable only on the days given by timesheet POC, other days should be entered as Non billable.</li>
                    </ul>
                    <li>If the associate is tagged in multiply projects including LN-LA-Development,</li>
                    <ul>
                        <li>Then the associate will have to submit LN timesheet on the days given by the timesheet POC. Other days can be left blank.</li>
                        <li>In Cognizant timesheet, it should be submitted as billable only on the days given by timesheet POC, other days should be entered as Billable in the other project where the associate has allocation.</li>
                    </ul>
                </ul>
                <br />
                <h5><b>Associate with Billable assignment in projects other than LN_LA_Development</b></h5>
                <p>
                    <em>Project Allocation (INVMT,FB,LA-Dev): Associate can be allocated in any of the projects within the account</em>
                </p>
                <p>
                    <em>Associate can see his allocation in “View Assignment” app in 1C.</em>
                </p>
                <b>Timesheet submission guidelines:</b>
                <ul>
                    <li>If the associate is not tagged against LN-LA-Development, then the associate will not have to submit LN timesheet.</li>
                    <li>In case of a planned & approved leave, leave should be applied in 1C and timesheet should be submitted without the entry for the leave date.</li>
                    <li>In case if a leave is not approved, and compensation is planned, in Cognizant timesheet, 8 hours should be added against the date on which the compensation is done. Entry for the day on which the leave is taken can be left as blank.</li>
                </ul>
            </section>

            <Footer/>
        </>
    )
}