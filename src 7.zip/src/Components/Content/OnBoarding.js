
import Footer from '../Home/Footer';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from './ContentNewHeader';
function OnBoarding()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OnBoarding').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="onboarding" className="onboarding">
                    <div className="container">
                        <div className="section-title">
                            <span>Onboarding</span>
                            <h2>Onboarding</h2>
                        </div>
                        <ul className="nav nav-tabs" id="onboarding-flters">
                            <li className="active"><a href="#onboarding-nda">NDA</a></li>
                            <li><a href="#onboarding-Security-Policy">Security Policy</a></li>
                            <li><a href="#onboarding-assign-asset">Asset Allocaton</a></li>

                            <li><a href="#onboarding-add-yourself-project-dl">Enrollment to Project DL</a></li>

                            <li><a href="#onboarding-add-yourself-odcaccess-dl">Enrollment to ODC Access</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="onboarding-nda" className="tab-pane fade in active">

                                <h3>Non-Disclosure Agreement</h3>
                                <p><em>A non-disclosure agreement (NDA) is a signed formal agreement in which LN agrees to give Cognizant confidential information about its business or products and Cognizant agrees not to share this information with anyone else. Non-disclosure agreements are common in technology companies where products are jointly developed.</em></p>

                                <ul>
                                    <li>Fill up the NDA (Non-Disclosure Agreement) form with the help of the sample filled NDA form which is also attached here.</li>
                                    <li>Download <a href="https://cognizantonline-my.sharepoint.com/:w:/g/personal/389934_cognizant_com/ETGfb04RyutDrBiruA615I0BVFDOkSoDN-l_NGZI-HAp3Q?email=Krishnan.Thandavarayan%40cognizant.com&e=rDUeHe">NDA</a>, <a href="https://cognizantonline-my.sharepoint.com/:b:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Onboarding/Sample%20NDA.pdf?csf=1&web=1&e=bmym2C">Sample NDA</a></li>
                                    <li>Take a print out of the filled form and sign in the form; Scan the signed form & share with your Manager</li>

                                </ul>
                                <br />
                                <table className="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Associate ID</th>
                                            <th scope="col">Associate Name</th>
                                            <th scope="col">Category<br />(ELT/Lateral/<br />Contractor)</th>
                                            <th scope="col">Solution Line</th>
                                            <th scope="col">Project</th>
                                            <th scope="col">Project ID</th>
                                            <th scope="col">Requestor Name</th>
                                            <th scope="col">Expected Date</th>
                                            <th scope="col">Expected Billability Date</th>
                                            <th scope="col">VISA available<br />(Y/N)</th>
                                            <th scope="col">VISA type</th>
                                            <th scope="col">Expiry Date</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>123456</td>
                                            <td>Associate's Name</td>
                                            <td>Lateral</td>
                                            <td>New Lexis</td>
                                            <td>LN-LA-Development</td>
                                            <td>1000046633</td>
                                            <td>Manager Name</td>
                                            <td>20-Aug-2020</td>
                                            <td>23-Aug-2020</td>
                                            <td>N</td>
                                            <td>N/A</td>
                                            <td>N/A</td>
                                        </tr>

                                    </tbody>
                                </table>
                                <br />
                                <li>Once the background verification is done, please follow up the manager to raise the request for LN ID and VDI creation.</li>
                                <li>Processing time: 1 month.</li>
                                <li>If it takes more than a month, check with the manager about the status of BG check and VDI creation. </li>
                                <li>Follow it up with them until the VDI is created for you.</li>


                                <div id="onboarding-Security-Policy" className="tab-pane fade">
                                    <h3>Security Policy</h3>
                                    <p>
                                        <em>Phishing is an attempt to acquire sensitive information such as usernames, passwords, business sensitive information, credit card details and sometimes, indirectly money as well. Its most often intended with malicious reasons, masquerading as a trustworthy entity in an electronic communication.</em>
                                    </p>
                                    <img align="center" src="assets/img/Phising_img.png" width="724px" height="380px" className="center" alt="Responsive image" />
                                    <br />
                                    <br />
                                    <ul>
                                        <li>
                                            <strong>EXTRA VIGILANCE: COVID-19 SCAM</strong> Indian government officials are warning citizens to expect a widespread COVID-19 phishing attack. The phishing email scam offers free testing to residents in major Indian cities. The COVID-19 phishing email is designed to steal personal data and financial information. The bad actors impersonate local government officials known to be tasked with supporting local testing and government aid distribution. The attackers create fake email addresses with these officials&rsquo; names or spoof the government authorities&rsquo; IDs. (Spoofing is the act of disguising a communication from an unknown source as being from a known, trusted source.)</li>
                                        <li>A cyber security agency with knowledge of this specific attack warns: Do not open attachments in unsolicited emails. Do not click on URLs in an unsolicited email, even if the link seems benign. Cyber security agencies have seen multiple attacks related to COVID-19.</li>
                                        <li>Every COVID-19 email should be read with skepticism. Question the message&rsquo;s intent.</li>
                                        <li>Review all parts of the message before acting. Cognizant proactively blocks emails from malicious actors. Please use the ReportSpam action in Outlook to report this and any other suspected phishing attacks.</li>
                                    </ul>
                                    <h4>Follow below guidance if you receive a suspicious email:</h4>
                                    <ul>
                                        <li>1. Approach Unsolicited Emails with Skepticism: Interacting with a phishing email can launch software, install ransomware, steal your stored credentials, etc. Be aware that an email related to COVID-19 is likely a phishing attempt.</li>
                                        <li>2. Remain Vigilant: Fraudulent messages around vaccine information, special offers, breaking news, etc. are all designed to deceive you into acting on the promises of the email.</li>
                                        <li>3. Question the Message: Cognizant and legitimate organizations will never ask for your credentials or sensitive information.</li>
                                        <li>4. Analyze the Email: Question the message&rsquo;s intent&mdash; see where it originated from, if it was a legitimate domain, and analyze all the variables about the message before acting.</li>
                                        <li>5. Attachments: Never open or download attachments from unknown sources.</li>
                                        <li>6. Links: While Cognizant is using email to communicate with associates, the messages are also available on BeCognizant. You will not be directed to click a link or download a file from the email. Cognizant communications will instead direct you to a BeCognizant page.</li>
                                        <li>7. Videos: Information such as ways you can protect yourself and your family should be viewed using personal devices on known, trusted websites. If a file promising this information is in a video attached to an email, do not open it. Report it.</li>
                                        <li>Report suspicious emails using the ReportSpam plugin in Outlook or report by sending the suspicious email as an attachment to <a href="mailto:reportspam@cognizant.com">reportspam@cognizant.com</a></li>
                                    </ul>
                                    <br />
                                    <p align="center">
                                        <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6f207777-646d-4222-860f-0657d2110db6}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                </div>

                                <div id="onboarding-assign-asset" className="tab-pane fade in">
                                    <h3>Asset Allocation</h3>
                                    <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d52174ac-cd33-4166-baeb-d1369d97788b}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                </div>

                                <div id="onboarding-update-location-seat" className="tab-pane fade in">
                                    <h3>Seat Allocation</h3>
                                    <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8cc5e343-640c-4102-aab9-b7d77627b160}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                </div>

                                <div id="onboarding-add-yourself-project-dl" className="tab-pane fade in">
                                    <h3>Enrollment to Project DL</h3>
                                    <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9b628978-09d5-48bc-8654-90d522104689}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                </div>


                                <div id="onboarding-add-yourself-odcaccess-dl" className="tab-pane fade in">
                                    <h3>Enrollment to ODC Access</h3>
                                    <p><em>A New Associates who are coming to office for the first time they need to get access to the ODC. Becuase our ODC is an Secure ODC to get access to ODC they can contact 249495(<b>Jeyaraman</b>) and 321499(<b>Sathyanarayanana</b>)</em></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>

        </>

    )
}
export default OnBoarding;