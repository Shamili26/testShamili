import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function TrainingMaterials() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/TrainingMaterials').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section id="training" className="training">
                <div className="container">
                    <div className="section-title">
                        <span>Technical Materials</span>
                        <h2>Technical Materials</h2>
                    </div>
                    <ul className="nav nav-tabs" id="training-flters">
                        <li className="active"><a href="#restfulwebservices">Restful Web Services</a></li>
                        <li><a href="#marklogic">Marklogic</a></li>
                        <li><a href="#xpathandxquery">Xpath and Xquery</a></li>
                        <li><a href="#angulardiv">ANGULAR</a></li>
                        <li><a href="#awsdiv">AWS</a></li>
                        <li><a href="#devops">DevOPs</a></li>
                        <li><a href="#bdd">BDD</a></li>
                        <li><a href="#aspvideos">ASP.NET PROGRAM</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="restfulwebservices" className="tab-pane fade in active">
                            <h3>Restful Web Services</h3>
                            <p>Representational State Transfer (REST) is an architectural style that specifies constraints, such as the uniform interface, that if applied to a web service induce desirable properties, such as performance, scalability, and modifiability, that enable services to work best on the Web. In the REST architectural style, data and functionality are considered resources and are accessed using Uniform Resource Identifiers (URIs), typically links on the Web. The resources are acted upon by using a set of simple, well-defined operations.</p>
                            <p>The REST architectural style constrains an architecture to a client/server architecture and is designed to use a stateless communication protocol, typically HTTP. In the REST architecture style, clients and servers exchange representations of resources by using a standardized interface and protocol.</p>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d9e0cc86-95e0-4fa9-87da-f3bfa8db4db5}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="marklogic" className="tab-pane fade in">
                            <h3>MarkLogic</h3>
                            <p>MarkLogic Server is a document-oriented database developed by MarkLogic. It is a NoSQL multi-model database that evolved from an XML database to natively store JSON documents and RDF triples, the data model for semantics. MarkLogic is designed to be a data hub for operational and analytical data.</p>
                            <p>MarkLogic uses documents without upfront schemas to maintain a flexible data model. In addition to having a flexible data model, MarkLogic uses a distributed, scale-out architecture that can handle hundreds of billions of documents and hundreds of terabytes of data. It has received Common Criteria certification, and has high availability and disaster recovery. MarkLogic is designed to run on-premises and within public or private cloud environments like Amazon Web Services.</p>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7a4115a7-6f25-48df-9773-e059033aec6a}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="xpathandxquery" className="tab-pane fade in">
                            <h3>XPath & XQuery</h3>
                            <p>XPath (XML Path Language) is a query language for selecting nodes from an XML document. XPath is an important and core component of XSLT standard. It is used to traverse the elements and attributes in an XML document. XPath is a W3C recommendation. XPath provides different types of expressions to retrieve relevant information from the XML document. It is syntax for defining parts of an XML document.</p>
                            <p>XQuery is a functional query language used to retrieve information stored in XML format. It is same as for XML what SQL is for databases. It queries and transforms collections of structured and unstructured data, usually in the form of XML, text and with vendor-specific extensions for other data formats (JSON, binary, etc.)</p>

                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={de4ad06f-8f08-4dcf-a544-654481801759}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="awsdiv" className="tab-pane fade in">

                            <section id="aws" className="aws">
                                <div className="container">
                                    <div className="section-title">
                                        <span>AWS</span>
                                        <h2>AWS</h2>
                                        <p><em>Amazon Web Services is a cloud computing platform that provides customers with a wide array of cloud services. We can define AWS (Amazon Web Services) as a secured cloud services platform that offers compute power, database storage, content delivery and various other functionalities.</em></p>
                                    </div>
                                    <ul className="nav nav-tabs" id="aws-flters">
                                        <li className="active"><a href="#awsintroduction">Introduction</a></li>
                                        <li><a href="#iam">IAM</a></li>
                                        <li><a href="#awsecs">ECS</a></li>
                                        <li><a href="#awslambda">Lambda</a></li>
                                        <li><a href="#awscloudformation">CloudFormation</a></li>
                                        <li><a href="#awsdynamodb">DynamoDB</a></li>
                                        <li><a href="#s3">S3</a></li>
                                        <li><a href="#awscloudwatch">CloudWatch</a></li>
                                        <li><a href="#awsec2">EC2</a></li>
                                        <li><a href="#awselbandroute53">ELB & Route53</a></li>
                                        <li><a href="#awsotherservices">Other Services</a></li>
                                    </ul>

                                    <div className="tab-content">
                                        <div id="awsintroduction" className="tab-pane fade in active">
                                            <h3>Introduction</h3>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={154c8b05-33c3-4a51-9256-df772fdb0fc4}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="iam" className="tab-pane fade in active">
                                            <h3>AWS Identity and Access Management</h3>
                                            <p>AWS Identity and Access Management (IAM) enables you to manage access to AWS services and resources securely. Using IAM, you can create and manage AWS users and groups, and use permissions to allow and deny their access to AWS resources. IAM enables the organization to create multiple users, each with its own security credentials, controlled and billed to a single aws account. IAM allows the user to do only what they need to do as a part of the user's job.</p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={796f8662-df6b-47ad-9e7c-550e93e37800}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awsecs" className="tab-pane fade in active">
                                            <h3>AWS Elatic Container Service</h3>
                                            <p>Amazon Elastic Container Service (Amazon ECS) is a highly scalable, fast container management service that makes it easy to run, stop, and manage containers on a cluster. Your containers are defined in a task definition that you use to run individual tasks or tasks within a service.</p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={ea879f7d-6b84-4c28-a537-23a86187db3c}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awslambda" className="tab-pane fade in active">
                                            <h3>AWS Lambda</h3>
                                            <p>AWS Lambda is a serverless compute service that lets you run code without provisioning or managing servers, creating workload-aware cluster scaling logic, maintaining event integrations, or managing runtimes.</p>
                                            <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2a427841-f18c-4d5d-9f9f-c59a393f284f}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                        </div>
                                        <div id="awscloudformation" className="tab-pane fade in active">
                                            <h3>AWS CloudFormation</h3>
                                            <p>AWS CloudFormation gives you an easy way to model a collection of related AWS and third-party resources, provision them quickly and consistently, and manage them throughout their lifecycles, by treating infrastructure as code. A CloudFormation template describes your desired resources and their dependencies so you can launch and configure them together as a stack.</p>
                                            <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8be78da8-7b7d-482b-bcdb-322d391555e0}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                        </div>
                                        <div id="awsdynamodb" className="tab-pane fade in active">
                                            <h3>AWS DynamoDB</h3>
                                            <p>Amazon DynamoDB is a key-value and document database that delivers single-digit millisecond performance at any scale. It's a fully managed, multi-region, multi-active, durable database with built-in security, backup and restore, and in-memory caching for internet-scale applications.</p>
                                            <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7520faa5-85d2-4ee4-b1c0-3d6f91fd219e}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                                        </div>
                                        <div id="s3" className="tab-pane fade">
                                            <h3>AWS Simple Storage Service</h3>
                                            <p>Amazon Simple Storage Service (S3) is an object storage service that offers industry-leading scalability, data availability, security, and performance. This means customers of all sizes and industries can use it to store and protect any amount of data for a range of use cases, such as websites, mobile applications, backup and restore, archive, enterprise applications, IoT devices, and big data analytics. Amazon S3 provides easy-to-use management features so you can organize your data and configure finely-tuned access controls to meet your specific business, organizational, and compliance requirements. </p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={0f4b88e5-52b0-4106-90f3-26948459db04}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awscloudwatch" className="tab-pane fade">
                                            <h3>AWS Cloudwatch</h3>
                                            <p>Amazon CloudWatch is a monitoring and management service that provides data and actionable insights for AWS, hybrid, and on-premises applications and infrastructure resources. With CloudWatch, you can collect and access all your performance and operational data in form of logs and metrics from a single platform. </p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d7ff2036-3ee8-4ac8-9f30-f6a724d9bb91}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awsec2" className="tab-pane fade">
                                            <h3> AWS Elastic Compute Cloud (EC2)</h3>
                                            <p>Amazon Elastic Compute Cloud (EC2) is a web service that provides secure, resizable compute capacity in the cloud. It is designed to make web-scale cloud computing easier for developers. Amazon EC2’s simple web service interface allows you to obtain and configure capacity with minimal friction. It provides you with complete control of your computing resources and lets you run on Amazon’s proven computing environment.</p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3535acf8-1618-460b-8984-d6c83320ef2e}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awselbandroute53" className="tab-pane fade">
                                            <h3>AWS ELB and Route 53</h3>
                                            <p>Elastic Load Balancing (ELB) automatically distributes incoming application traffic across multiple targets, such as Amazon EC2 instances, containers, IP addresses, and Lambda functions. It can handle the varying load of your application traffic in a single Availability Zone or across multiple Availability Zones. Elastic Load Balancing offers three types of load balancers (Application LB, Network LB, Classic LB) that all feature the high availability, automatic scaling, and robust security necessary to make your applications fault tolerant.</p>
                                            <p>Amazon Route 53 is a highly available and scalable cloud Domain Name System (DNS) web service. It is designed to give developers and businesses an extremely reliable and cost effective way to route end users to Internet applications by translating names like www.example.com into the numeric IP addresses like 192.0.2.1 that computers use to connect to each other.</p>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={d036c1a4-4162-419a-9465-9fec1014515d}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>
                                        <div id="awsotherservices" className="tab-pane fade">
                                            <h3>AWS Other Services</h3>
                                            <p align="center">
                                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e4089c5e-b5e1-479f-bc9e-bc62942a1dfb}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </section>
                        </div>
                        <div id="devops" className="tab-pane fade in">
                            <h3>DevOps</h3>
                            <p>DevOps is a set of practices that combines software development and IT operations. DevOps is about removing the barriers between traditionally siloed teams, development and operations. Under a DevOps model, development and operations teams work together across the entire software application life cycle, from development and test through deployment to operations.</p>                <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8702342d-d54c-40f8-bb00-abacc9775b75}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="angulardiv" className="tab-pane fade in">
                            <h3>Angular</h3>
                            <p>Angular is a platform and framework for building single-page client applications using HTML and TypeScript. Angular is written in TypeScript. It implements core and optional functionality as a set of TypeScript libraries that you import into your apps.</p>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={47238b35-8205-40e5-b775-dab4080ef9a2}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                            <h3>Introduction To Angular</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/1.%20Introduction%20to%20Angular.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Angular Components and Data Binding</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/2.%20Angular%20components%20and%20data%20binding.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Angular - Directives</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/3.%20Angular%20-%20Directives.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Angular - Forms</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/4.%20Angular%20-%20Angular%20Forms.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Angular - Service and Dependency Injection</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/5.%20Angular%20-%20Services%20%26%20dependency%20injection.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Routing</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Routing.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Pipes</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Pipes.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Making HTTP Requests</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Making%20Http%20requests.mp4" type="video/mp4" /></video>
                            </p>
                            <h3>Observables & Working with NgRX</h3>
                            <p align="center">
                                <video width="600" height="400" controls><source src="https://cognizantonline-my.sharepoint.com/:v:/r/personal/389934_cognizant_com/Documents/LA_Playbook/New_Joiner_Handbook/Training/Angular/Observables%20%26%20Working%20with%20NgRX.mp4" type="video/mp4" /></video>
                            </p>
                        </div>
                        <div id="bdd" className="tab-pane fade in">
                            <h3>Behavior Driven Development</h3>
                            <p>Behavior Driven Development (BDD) is an Agile software development process that encourages collaboration among developers, QA and non-technical or business participants in a software project. It encourages teams to use conversation and concrete examples to formalize a shared understanding of how the application should behave. It emerged from test-driven development (TDD). Behavior-driven development combines the general techniques and principles of TDD with ideas from domain-driven design and object-oriented analysis and design to provide software development and management teams with shared tools and a shared process to collaborate on software development.</p>

                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={fb667785-d17d-4f33-be6a-6fe671a89150}&amp;action=embedview&amp;wdAr=1.3333333333333333" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="aspvideos" className="tab-pane fade in">
                            <h3>ASP.Net Core Program</h3>
                            <p>Technical sessions where conducted related to topics like MVC, Entity framework,ASP.NET & C# to Trainee Associates.Videos related to the session are listed below for reference.
                            </p>

                            <ul className="nav nav-tabs" id="asp-flters">
                                <li className="active"><a href="#aspsession1">Session 1</a></li><br />
                                <li className="active"><a href="#aspsession2">Session 2</a></li><br />
                                <li className="active"><a href="#aspsession3">Session 3</a></li><br />
                                <li className="active"><a href="#aspsession4">Session 4</a></li><br />
                                <li className="active"><a href="#aspsession5">Session 5</a></li><br />
                                <li className="active"><a href="#aspsession6">Session 6</a></li><br />
                                <li className="active"><a href="#aspsession7">Session 7</a></li><br />
                            </ul>
                            <div className="tab-content">
                                <div id="aspsession1" className="tab-pane fade in active">
                                    <h4>Session 1</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-5dd37116-5333-4355-a8b1-2cadd2613786/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: "0px" }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession2" className="tab-pane fade in active">
                                    <h4>Session 2</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-ba5ac149-cafd-4053-a16d-cf5f089affd7/nv4/embedded' allowFullScreen webkitallowFullScreen mozallowFullScreen width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession3" className="tab-pane fade in active">
                                    <h4>Session 3</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-547d7692-d4af-4002-873f-de17eaf85e1b/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession4" className="tab-pane fade in active">
                                    <h4>Session 4</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-8f2db37f-a1e2-4b1c-85c6-38df24c68bf8/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession5" className="tab-pane fade in active">
                                    <h4>Session 5</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-fdd38edc-96ba-4bf1-a4fc-d99620d1cf86/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession6" className="tab-pane fade in active">
                                    <h4>Session 6</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-2381aa59-523f-47b9-905c-d91204dba45d/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                                <div id="aspsession7" className="tab-pane fade in active">
                                    <h4>Session 7</h4>
                                    <p align="center">

                                        <iframe src='https://cognizant.kpoint.com/web/videos/gcc-45f30fcf-aed8-4c0e-8fef-d34246ff4b23/nv4/embedded' width='640' height='360' rel='nofollow' style={{ border: '0px' }}>This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <Footer/>
        </>
    )
}