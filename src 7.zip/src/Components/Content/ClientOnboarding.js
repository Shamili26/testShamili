import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

function ClientOnBoarding()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/ClientOnboarding').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
         <section id="clientonboarding" className="clientonboarding">
                    <div className="container">
                        <div className="section-title">
                            <span>Client Onboarding</span>
                            <h2>Client Onboarding</h2>
                        </div>
                        <ul className="nav nav-tabs" id="clientonboarding-flters">
                            <li className="active"><a href="#clientonboarding-vdiaccess">VDI Access</a></li>
                            <li><a href="#clientonboarding-vdiissues">VDI Access - Common Issues & Solutions</a></li>
                            <li><a href="#clientonboarding-msteamsissues">LN VDI MS-Teams Issues & Solutions</a></li>
                            <li><a href="#clientonboarding-visualstudio">Visual Studio Installation</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="clientonboarding-vdiaccess" className="tab-pane fade in active">
                                <h3>VDI Access</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={9e574d00-69f0-45b4-9734-7f09cc5a151e}&amp;action=embedview&amp;wdEmbedCode=1&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>

                            <div id="clientonboarding-vdiissues" className="tab-pane fade">
                                <h3>VDI Access - Issues & Solutions</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={3db36610-0c05-4ee6-8d89-a745d5f79ab8}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>

                            <div id="clientonboarding-msteamsissues" className="tab-pane fade">
                                <h3>LN VDI MS-Teams Issues & Solutions</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={13a49b41-23a0-4f53-8ad4-76c115d0de6d}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>

                            <div id="clientonboarding-visualstudio" className="tab-pane fade in">
                                <h3>Visual Studio Installation</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={924a46d1-819a-4307-9d5d-edeea18c0595}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>

                        </div>
                    </div>
                </section>
                <Footer/>
        </>
    )
}
export default ClientOnBoarding;