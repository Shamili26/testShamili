import Footer from "../Home/Footer"
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader"

export default function LADefinitionOfDone(){
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/LADefinitionOfDone').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section className="ladefinitionofdone" id="ladefinitionofdone">
                <h3>LA - Definition of Done</h3>
                <img src="assets\img\LA_Definition_Of_Done.jpg" width="722px" height="565px" className="img-thumbnail" alt="Responsive image" />
            </section>

            <Footer/>

        </>
    )
}