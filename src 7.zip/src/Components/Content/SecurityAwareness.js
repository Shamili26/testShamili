import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function SecurityAwareness() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/SecurityAwareness').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader/>
            <section id="others-securityawarness" className="others-securityawarness">
                <div className="container">
                    <div className="section-title">
                        <span>Security Awarness</span>
                        <h2>Malicious NuGet packages</h2>
                    </div>
                    <div className="tab-content">
                        <p align="center">
                            <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f934e2d7-3b20-4db2-80c1-240148da1db3}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe> </p>
                    </div>
                </div>
            </section>

            <Footer/>
        </>
    )
}