import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function InductionPlanJava()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/InductionPlanJava').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
           <section id="java-inductionplan" className="java-inductionplan">
                    <div className="container">
                        <div className="section-title">
                            <span>Induction Plan - Java</span>
                            <h2>Induction Plan - Java</h2>
                            <p><em>As part of Induction , the new joiners will be trained on LA specific technolgies along with Org manadate which the associate should be compliant. This Induction plan comprises of technical trainings, LA Functional trainings and Assessment details. The topics are categorized as "Self Training" , "Mentor Instructed" & "Instructor led". Training materials are available in playbook for reference. we have both detailed induction  and induction lite template available for associates. Please contact your mentor for induction type chosen.</em></p>
                        </div>
                        <ul className="nav nav-tabs" id="java-inductionplan-flters">
                            <li className="active"><a href="#inductionplan-detailed">Induction Plan - Detailed</a></li>
                            <li><a href="#inductionplan-lite">Induction Plan - Lite</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="inductionplan-detailed" className="tab-pane fade in active">
                                <h3>Induction Plan - Detailed</h3>
                                <p align="center">
                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={baac7700-385c-4329-991b-c351b951e9f3}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True"></iframe>
                                </p>
                            </div>
                            <div id="inductionplan-lite" className="tab-pane fade">
                                <h3>Induction Plan - Lite</h3>
                                <p align="center">
                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={4c1e84b8-b085-4450-8fd3-0b638f0cc235}&action=embedview&wdAllowInteractivity=False&wdDownloadButton=True&wdInConfigurator=True"></iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer/>
        </>
    )
}