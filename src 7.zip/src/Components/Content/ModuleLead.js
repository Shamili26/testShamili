import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function ModuleLead()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/ModuleLead').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
        <section id="modulelead" className="modulelead">
                    <div className="container">
                        <div className="section-title">
                            <span>Module Lead</span>
                            <h2>Module Lead</h2>
                        </div>
                        <ul className="nav nav-tabs" id="modulelead-flters">
                            <li><a href="#ml-handoverTurnoverDocumentTemplate">HandOver TurnOver Document Template</a></li>
                            <li><a href="#ml-rootcauseanalysis">Root Cause Analysis</a></li>
                            <li><a href="#ml-trainingPlanTemplate">Training Plan Template</a></li>
                            <li><a href="#ml-skillSetMatrixTemplate">SkillSet Matrix Template</a></li>
                            <li><a href="#ml-whatsnext">What's Next</a></li>
                        </ul>

                        <div className="tab-content">
                            <div id="ml-handoverTurnoverDocumentTemplate" className="tab-pane fade in">
                                <h3>HandOver TurnOver Document Template</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={2f2c4a35-176a-4446-9fc6-dbdda9b14240}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                            <div id="ml-rootcauseanalysis" className="tab-pane fade in">
                                <h3>Root Cause Analysis</h3>
                                <p align="center">
                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={38cf173b-bc82-404c-a431-7a7ca3a09057}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"></iframe>
                                </p>
                            </div>
                            <div id="ml-trainingPlanTemplate" className="tab-pane fade in">
                                <h3>Training Plan Template</h3>
                                <p align="center">
                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6a0996ee-b4b5-4120-aff9-cf5784355cbe}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"></iframe>
                                </p>
                            </div>
                            <div id="ml-skillSetMatrixTemplate" className="tab-pane fade in">
                                <section id="skillSetMatrixTemplate" className="skillSetMatrixTemplate">
                                    <div className="container">
                                        <div className="section-title">
                                            <span>SkillSet Matrix Template</span>
                                            <h2>SkillSet Matrix Template</h2>
                                        </div>
                                        <ul className="nav nav-tabs" id="skillSetMatrixTemplate-flters">
                                            <li className="active"><a href="#javaskillSetMatrixTemplate">Java</a></li>
                                            <li><a href="#DotNetskillSetMatrixTemplate">.Net</a></li>
                                        </ul>
                                        <div className="tab-content">
                                            <div id="javaskillSetMatrixTemplate" className="tab-pane fade in active">
                                                <h3>Java</h3>
                                                <p align="center">
                                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={84e10542-32da-4c55-8743-03ee8aea5946}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"></iframe>
                                                </p>
                                            </div>
                                            <div id="DotNetskillSetMatrixTemplate" className="tab-pane fade in active">
                                                <h3>.Net</h3>
                                                <p align="center">
                                                    <iframe width="722" height="565" frameborder="0" scrolling="no" src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={f64e78ec-f770-450a-b911-c188c9a4a06f}&action=embedview&wdAllowInteractivity=False&wdHideGridlines=True&wdHideHeaders=True&wdDownloadButton=True&wdInConfigurator=True&wdInConfigurator=True&edesNext=false&ejss=false"></iframe>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div id="ml-whatsnext" className="tab-pane fade in">
                                <h3>What's Next</h3>
                                <p align="center"><iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={59d0d760-937f-4c2b-9d1a-01645bd234be}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        
        </>
    )
}