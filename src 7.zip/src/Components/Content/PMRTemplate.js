import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function PMRTemplate() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/PMRTemplate').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section className="pmr-template" id="pmr-template">
                <h3>PMR Template</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={06782c41-250d-4008-880e-d5d65737f694}&amp;action=embedview&amp;wdAr=1.7777777777777777&amp;wdEaa=0" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>

            <Footer/>

        </>
    )
}