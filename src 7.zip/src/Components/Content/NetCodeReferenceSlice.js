import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function NetCodeReferenceSlice() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/NetCodeReferenceSlice').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section id="net-codereferenceslice" className="net-codereferenceslice">
                <div className="container">
                    <div className="section-title">
                        <span>Code Reference Slice</span>
                        <h2>Code Reference Slice</h2>
                    </div>
                    <ul className="nav nav-tabs" id="net-codereferenceslice-flters">
                        <li><a href="#angular-crs">Angular</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="angular-crs" className="tab-pane fade in">
                            <h3>Angular</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={82a26c25-2a5d-4b3a-8137-0bdbd0f2c1d8}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>

                        </div>
                    </div>
                </div>
            </section>

            <Footer/>

        </>

    )
}