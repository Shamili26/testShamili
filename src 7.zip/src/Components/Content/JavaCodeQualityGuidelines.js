import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function JavaCodeQualityGuidelines() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/JavaCodeQualityGuidelines').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section id="java-codequalityguidelines" className="java-codequalityguidelines">
                <div className="container">
                    <div className="section-title">
                        <span>Coding Standard</span>
                        <h2>Coding Standard</h2>
                        <p><em>To build enterprise applications, which are reliable, scalable and maintainable, it is important for
                            development teams to adopt proven design techniques and good coding standards. The adoption of
                            coding standards results in code consistency, which makes it easier to understand, develop and maintain
                            the application. In addition by being aware of and following the right coding techniques at a granular
                            level, the programmer can make the code more efficient and performance effective.</em></p>
                    </div>
                    <ul className="nav nav-tabs" id="java-codequalityguidelines-flters">
                        <li className="active"><a href="#java">Java</a></li>
                        <li><a href="#oracle">Oracle</a></li>
                        <li><a href="#xquery">XQuery</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="java" className="tab-pane fade in active">
                            <h3>Java</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={67460d48-2463-4935-8e6e-78ef36257579}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="oracle" className="tab-pane fade">
                            <h3>Oracle</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={6cb50bf8-3963-4c0d-b623-89585b5ee732}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                        </div>
                        <div id="xquery" className="tab-pane fade">
                            <h3>XQuery</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={c39fddfd-0a30-41ee-b994-06d2c25afbb8}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe></p>
                        </div>
                    </div>
                </div>

            </section>

            <Footer/>
        </>
    )
}