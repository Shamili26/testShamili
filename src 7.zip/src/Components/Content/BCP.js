import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function BCP() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/BCP').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section id="bcp" className="bcp">
                <div className="container">
                    <div className="section-title">
                        <span>BCP</span>
                        <h2>BCP</h2>
                    </div>
                    <ul className="nav nav-tabs" id="bcp-flters">
                        <li className="active"><a href="#calltreetest">Call Tree Test</a></li>
                        <li><a href="#swt">SWT</a></li>
                        <li><a href="#usermanuals">User Manuals</a></li>
                        <li><a href="#bcp-curioustoknowmore">Curious to know more !!</a></li>
                    </ul>

                    <div className="tab-content">
                        <div id="calltreetest" className="tab-pane fade in active">
                            <h3>Call Tree Test</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={13b336af-2cd6-4c59-9392-8bc50babe1c3}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="swt" className="tab-pane fade">
                            <h3>Structured Walkthrough Test</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={7500084c-20e6-4665-8acb-82a40d17e1ee}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="usermanuals" className="tab-pane fade">
                            <h3>User Manuals</h3>
                            <p align="center">
                                <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={32f37533-5ca7-47d5-8627-32c7432f5b8b}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                            </p>
                        </div>
                        <div id="bcp-curioustoknowmore" className="tab-pane fade">
                            <h3>Curious to know more !!</h3>
                            <p align="center">
                                Associates can explore more about BCP by go through the below courses
                            </p>
                            <br />
                            <table className="table table-sm table-striped" style={{ width: '50%', align: "center" }}>
                                <thead>
                                    <tr>
                                        <th scope="col">Course Code</th>
                                        <th scope="col">Course Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>COPCO002</td>
                                        <td>Business Continuity Management</td>
                                    </tr>
                                    <tr>
                                        <td>COPOS004</td>
                                        <td>BCM Cognizance</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
            <Footer/>

        </>
    )
}