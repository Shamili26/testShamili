import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function OrgMandatoryCourses() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/OrgMandatoryCourses').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section id="orgmandatorycourses" className="orgmandatorycourses">
                <div className="container">

                    <div className="section-title">
                        <span>Org Mandatory Courses</span>
                        <h2>Org Mandatory Courses</h2>
                        <p align="justify"><em><b><u>Acceptable Use Policy </u></b>This policy sets forth the Cognizant mandates with respect to the acceptable and unacceptable usage of Cognizant and Cognizant's Clients' information and information technology resources.</em></p>
                        <br />
                        <p align="justify"><em><b><u>Core Values and Standards of Business Conduct </u></b>Cognizant expects all its associates to adhere to and uphold the Core Values and Standards of Business Conduct (COBE). Every Associate working with Cognizant is expected to take all the possible steps to ensure and protect the interest of Cognizant, discharge his/her duties with utmost integrity, honesty, devotion and diligency and also to refrain from doing anything which is inappropriate and unacceptable at Cognizant</em></p>
                        <br />
                        <p align="justify">All associates are expected to complete the courses every year</p>
                        <table className="table table-sm table-striped" style={{ width: "80%", align: "center" }}>
                            <thead>
                                <tr>
                                    <th scope="col">Course Code</th>
                                    <th scope="col">Course Name</th>
                                    <th scope="col">Applicability</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td align="center">NA</td>
                                    <td align="center"><a href="https://cognizant.kpoint.com/app/video/gcc-8ce69950-12c8-4ff1-80d9-580f4e7a3b1d" target="_blank">General Security Awareness Webinar </a><a /></td>
                                    <td align="center">All Associates</td>
                                </tr>
                                <tr>
                                    <td align="center">NA</td>
                                    <td align="center"><a href="https://cognizant.kpoint.com/app/playlist/9054" target="_blank">Phishing Awareness video series</a></td>
                                    <td align="center">All Associates</td>
                                </tr>
                                <tr>
                                    <td align="center">BQVCA2</td>
                                    <td align="center">Acceptable Use Policy</td>
                                    <td align="center">All Associates</td>
                                </tr>
                                <tr>
                                    <td align="center">AIEIM018</td>
                                    <td align="center">Legal Systems - KNOWLEDGE BASED ASSESSMENT [101-BASICS]</td>
                                    <td align="center">All associates</td>
                                </tr>
                                <tr>
                                    <td align="center">BQVCC1</td>
                                    <td align="center">Core Values and Standards of Business Conduct</td>
                                    <td align="center">All associates up to SA level</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                {/*<!--<img src="assets\img\LA Product suite.png" className="img-thumbnail" alt="Responsive image">--></img>*/}

            </section>

            <Footer/>
        </>
    )
}