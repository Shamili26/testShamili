import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function VersionOneGuidelines()
{
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/VersionOneGuidelines').then((response) => {

        }
        )
    }, [])

    return(
        <>
        <ContentNewHeader/>
          <section className="versiononeguidelines" id="versiononeguidelines">
                    <div className="container">
                        <div className="section-title">
                            <span>Version One Guidelines</span>
                            <h2>Version One Guidelines</h2>
                        </div>
                        <ul className="nav nav-tabs" id="versiononeguidelines-flters">
                            <li className="active"><a href="#agilebestpractices">Agile Best Practices</a></li>
                            <li><a href="#estimation">Estimation</a></li>
                        </ul>
                        <div className="tab-content">
                            <div id="agilebestpractices" className="tab-pane fade in active">
                                <h3>Agile Best Practices</h3>
                                <p> 1.	Assign the user story to your name </p>
                                <p> 2.	Add tasks as in LA Definition of Done , this is to ensure Definition of done is adhered to </p>
                                <p> 3.	Provide estimate for each task </p>
                                <p> 4.	Update the effort burnt down for that day & reduce the remaining hours before the Daily stand up </p>
                                <p> 5.	Utilize “Conversations” to update the details that the feature team should know , for their reference </p>
                                <p> 6.	Attach the screenshots of UI before & after development , if the story is for UI changes , where the UX is not provided due to minor changes </p>
                                <p> 7.	Update “Technical Notes” for Spikes /design changes , for later references </p>
                                <p> 8.	Tag “Blocker” to the User story with the reason of impediment , when you are unable to proceed with the user story due to dependency.  This needs to be called out in Retrospection </p>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={1e1e87c7-fcba-4088-a8cf-5c0a50f7b764}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                            <div id="estimation" className="tab-pane fade">
                                <h3>Estimation</h3>
                                <p align="center">
                                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={03327167-4d1f-47a4-a0cb-7033ad16a5d3}&amp;action=embedview" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer/>
        </>
    )
}