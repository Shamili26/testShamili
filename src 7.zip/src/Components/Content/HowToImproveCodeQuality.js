import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function HowToImproveCodeQuality() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/HowToImproveCodeQuality').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />
            <section className="howtoimprovecodequality" id="howtoimprovecodequality">
                <h3>Code Quality Improvement Guidelines</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={8608c023-3fc4-4b9b-a455-d1a7bc90fd7a}&amp;action=embedview&amp;wdStartOn=1" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>        </p>
            </section>

            <Footer/>
        </>
    )
}