import Footer from "../Home/Footer";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ContentNewHeader from "./ContentNewHeader";

export default function CIIIgniter() {
    useEffect(() => {
        axios.put('http://localhost:8081/pages/put/CIIIgniter').then((response) => {

        }
        )
    }, [])

    return (
        <>
            <ContentNewHeader />

            <section className="cii-igniter" id="cii-igniter">
                <h3>CII Igniter Sessions</h3>
                <p align="center">
                    <iframe src="https://cognizantonline-my.sharepoint.com/personal/389934_cognizant_com/_layouts/15/Doc.aspx?sourcedoc={e04306c6-ad1c-40fc-b6e0-ea95280d8129}&amp;action=embedview&amp;wdAr=1.7777777777777777" width="722px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                </p>
            </section>

            <Footer/>



        </>
    )
}