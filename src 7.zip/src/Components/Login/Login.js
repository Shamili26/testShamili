import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Footer from "../Home/Footer";
import Header from "../Home/Header";
import pic from "./adminblue.jpg";

const Login = () => {
  const navigate = useNavigate();

  const [associateid, setAssociateid] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});

  const submitForm = (e) => {
    e.preventDefault();
    const errors = validate();
    setErrors(errors);
    if (Object.keys(errors).length === 0) {
      handleApi();
    }
  };

  const validate = () => {
    const error = {};
    if (!associateid) {
      error.associateid = "Associate ID Required";
    }
    if (!password) {
      error.password = "Password Required";
    } else if (password.length < 8) {
      error.password = "Enter a correct password";
    }
    return error;
  };

  const handleApi = () => {
    const associate = { associateid, password };
    axios
      .post("http://localhost:8081/authenticate/custom-login", associate)
      .then((result) => {
        if (result.data.role === "Admin") {
          alert("Admin login successfully");
        } else {
          alert("Login successfully");
        }
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("username", associateid);
        localStorage.setItem("Role", result.data.role);
        navigate("/");
      })
      .catch((error) => {
        if (error.response?.status === 403) {
          alert("Invalid associate ID or password");
        } else if (error.response?.status === 401) {
          alert("Unauthorized user");
        } else {
          alert("Login failed");
        }
      });
  };
  const labelStyle = {
    fontWeight: "bold",
    color: "black",
    textAlign: "left",
  };
  const buttonStyle = {
    backgroundColor: "#4CAF50",
    border: "none",
    color: "white",
    padding: "10px 20px",
    textAlign: "center",
    textDecoration: "none",
    display: "inline-block",
    fontSize: "16px",
    margin: "10px auto",
    cursor: "pointer",
    borderRadius: "5px",
    fontWeight: "bold",
  };
  const inputStyle = {
    width: "100%",
    padding: "10px",
    marginBottom: "15px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    boxSizing: "border-box",
    fontSize: "16px",
  };

  return (
    <>
      <div
        style={{
          backgroundImage: `url(${pic})`,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
        }}
      >
        <Header />
        <section className="forms top" style={{ padding: "125px 0" }}>
          <div className="container" style={{ textAlign: "center" }}>
            <div
              className="sign-box"
              style={{
                backgroundColor: "snow",
                maxWidth: "500px",
                margin: "0 auto",
                padding: "20px",
              }}
            >
              <h2
                style={{
                  fontSize: "40px",
                  textAlign: "center",
                  marginBottom: "20px",
                  fontWeight: "bold",
                  color: "black",
                }}
              >
                Login
              </h2>
              <form onSubmit={submitForm}>
                <div>
                  {/* <label htmlFor="associateid" style={labelStyle}>
                    Enter Associate ID
                  </label> */}
                  <br />
                  <input
                    type="text"
                    name="associateid"
                    value={associateid}
                    onChange={(e) => setAssociateid(e.target.value)}
                    placeholder="Associate ID"
                    style={inputStyle}
                  />
                  {errors.associateid && (
                    <div style={{ color: "red", fontSize: "13px" }}>
                      {errors.associateid}
                    </div>
                  )}
                </div>

                {/* <label htmlFor="password" style={labelStyle}>
                  Enter Password
                </label> */}
                <br />
                <input
                  type="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  style={inputStyle}
                />
                {errors.password && (
                  <div style={{ color: "red", fontSize: "13px" }}>
                    {errors.password}
                  </div>
                )}
                <br />
                <div>
                  <button
                    type="submit"
                    className="primary-btn"
                    style={buttonStyle}
                  >
                    Sign In
                  </button>
                </div>
                <div>
                  Don't have an account?{" "}
                  <Link
                    to="/register"
                    className="nav-link"
                    style={{ color: "blue" }}
                  >
                    Register
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </>
  );
};

export default Login;
