import Header from "../Home/Header";
import React, { Component, useEffect, useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom';
import pic from './adminblue.jpg'
import axios from "axios";
import "./Admin.css"
import Footer from "../Home/Footer";
import Charts from "./Charts";



function Admin() {

const [createPage, setCreatePage] = useState("");

const handleCreatePage = (e) => {
  setCreatePage(e.target.value);
  console.log(e.target.name + " -  " + e.target.value);
}

const handleCreatePageSubmit = (e) =>{
  const page={createPage}
  console.log(page);
  axios.post('http://localhost:8081/pages/create/'+createPage).then((response)=>{
    alert("Page Added");
    setCreatePage("")
    
  })
}
  const [ pagesCount, setPagesCount] = useState([])

  const handlePagesCount =(e)=>{
    axios.get("http://localhost:8081/pages/get").then((response)=>{
      setPagesCount(response.data);
    })
  }

  const [nname, setnname] = useState([])
  const handleAssociateNotLoggedIn = (e) => {
    axios.get("http://localhost:8081/associateTracker/not").then((response) => {

      setnname(response.data)
    })
  }

  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [laoffshoredl, setLaoffshoredl] = useState([])
  const [associateid, setAssociateid] = useState("")
  const [deleteassociateid, setDeleteAssociateid] = useState("")
  const [associate, setAssociate] = useState([]);

  const [associateTracker, setAssociateTracker] = useState([]);

  const [associateloggedIn, setAssociateLoggedIn] = useState([]);

  const [associateCount, setAssociateCount] = useState([]);

  const handleDeleteAssociate = (e) => {
    axios.delete('http://localhost:8081/associate/delete/' + deleteassociateid)
      .then((response) => {
        alert("Delete associate " + deleteassociateid + " Registration list");
        setDeleteAssociateid("");
      })
  }


  const handleAssociateCount = (e) => {
    axios.get("http://localhost:8081/associateTracker/associateCount").then((response) => {
      setAssociateCount(response.data);
      console.log(response.data);
    })
  }

  const handleAssociateLoggedIn = (e) => {
    axios.get("http://localhost:8081/associateTracker/loggedIn").then((response) => {
      setAssociateLoggedIn(response.data);
    })
  }

  const handleAssociateTracker = (e) => {
    axios.get("http://localhost:8081/associateTracker/getAll").then((response) => {
      setAssociateTracker(response.data);
      console.log(response.data)
    })
  }
  const handleAssociateid = (e) => {
    setAssociateid(e.target.value);
    console.log(e.target.name + " -  " + e.target.value);
  }
  const handleName = (e) => {
    setName(e.target.value);
    console.log(e.target.name + " -" + e.target.value);
  }
  const handleClose = (e) => {
    setName("");
    setAssociateid("")
    setDeleteAssociateid("")
  }
  const handleDeleteAssociateid = (e) => {
    setDeleteAssociateid(e.target.value);
  }
  const handleDelete = (e) => {
    axios.delete('http://localhost:8081/laoffshoredl/delete/' + deleteassociateid)
      .then((response) => {
        alert("Delete associate " + deleteassociateid);
        setDeleteAssociateid("");
      })
  }

  const handleAssociateView = (e) => {
    axios.get('http://localhost:8081/associate/read').then((response) => {
      setAssociate(response.data);

    })
  }

  const handleView = (e) => {
    axios.get('http://localhost:8081/laoffshoredl/read').then((res) => {
      setLaoffshoredl(res.data);

    })
  }

  const handleSubmit = (e) => {
    const laoffshoredl = { associateid, name };

    axios.post('http://localhost:8081/laoffshoredl/create', laoffshoredl).then((response) => {
      console.log(response.data);
      alert("Associate Added");
      setName("");
      setAssociateid("")


    })
      .catch(function (error) {
        if (error.response.status === 500) {
          alert("Associate Already Present")
          setName("");
          setAssociateid("");

        }
      })
  }
  return (
    <>

      <div style={{ backgroundImage: `url(${pic})`, backgroundSize: 'cover', minHeight: '100vh', backgroundRepeat: 'no-repeat' }}>
        <Header />
        <div className="container-fluid" style={{ paddingTop: 150, paddingLeft: 100, paddingRight: 100, paddingBottom: 100 }}>
          <div className="row">
            <center>  <label> <h1 className="jsx-2391468037 title" style={{ color: 'white' }}>Admin LN Distribution List</h1></label> </center>
          </div>
          <div className="container-fluid" style={{ paddingLeft: 30 }}>
            <div className="row" style={{ paddingTop: 100 }}>
              <div className="col md-5">
                <button type="button" className="primary-btn" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Add Associates to LN Distribution List</button>


                <div className="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="exampleModalLabel">Add Associate</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <form>
                          <div className="mb-3">
                            <label for="associate id" className="col-form-label">Employee Id</label>
                            <input type="number" className="form-control" id="associateid" name="associateid" onChange={handleAssociateid} value={associateid} />
                          </div>
                          <div className="mb-3">
                            <label for="employee name" className="col-form-label">Employee Name</label>
                            <input type="text" className="form-control" id="name" name="name" onChange={handleName} value={name} />
                          </div>
                        </form>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>
                        <button type="button" className="btn btn-primary" onClick={handleSubmit}>Submit</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col md-5" style={{ paddingLeft: 350 }}>

                <button type="button" onClick={handleAssociateView} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associate">
                  View Associates of LN Associates Table
                </button>


                <div className="modal fade" id="associate" tabindex="-1" aria-labelledby="associateLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="associateLabel">View Registered Associates</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <table className="table ">
                          <thead>
                            <tr>
                              <th scope="col">Id</th>
                              <th scope="col">Full Name</th>
                              <th scope="col">Associate Id</th>
                              <th scope="col">Manager</th>
                              <th scope="col"></th>

                            </tr>
                          </thead>
                          <tbody>
                            {associate.map((response) => {
                              return (


                                <tr>
                                  <th scope="row">{response.id}</th>
                                  <td>{response.fullname}</td>
                                  <td>{response.associateid}</td>
                                  <td>{response.manager}</td>

                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row " style={{ marginTop: 100 }}>
              <div className="col md-5">

                <button type="button" onClick={handleView} className="primary-btn" data-bs-toggle="modal" data-bs-target="#example">
                  View Associates of LN Distribution List
                </button>


                <div className="modal fade" id="example" tabindex="-1" aria-labelledby="exampleLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="exampleLabel">View Associates of LN Distribution List</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <table className="table">
                          <thead>
                            <tr>
                              <th scope="col">Id</th>
                              <th scope="col">Employee Id</th>
                              <th scope="col">Employee Name</th>

                            </tr>
                          </thead>
                          <tbody>
                            {laoffshoredl.map((response) => {
                              return (
                                <tr>
                                  <th scope="row">{response.id}</th>
                                  <td>{response.associateid}</td>
                                  <td>{response.name}</td>

                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col md-5" style={{ paddingLeft: 350 }}>
                <button type="button" className="primary-btn" data-bs-toggle="modal" data-bs-target="#deleteModal" data-bs-whatever="@mdo">Delete from  LN  Distribution List By eId</button>


                <div className="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="deleteModalLabel">Delete Associate</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <form>
                          <div className="mb-3">
                            <label for="associate id" className="col-form-label">Employee Id</label>
                            <input type="number" className="form-control" id="deleteassociateid" name="deleteassociateid" onChange={handleDeleteAssociateid} value={deleteassociateid} />
                          </div>

                        </form>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>
                        <button type="button" className="btn btn-primary" onClick={handleDelete}>Submit</button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <div className="row" style={{ paddingTop: 100 }}>
              <div className="col md-5">
                <button type="button" onClick={handleAssociateTracker} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associateTrackerModal" data-bs-whatever="@mdo">View Associate Session Tracker Details</button>


                <div className="modal fade" id="associateTrackerModal" tabindex="-1" aria-labelledby="associateTrackerModalLabel" aria-hidden="true">
                  <div className="modal-dialog modal-dialog-scrollable modal-lg">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="associateTrackerModalLabel">Associate Session Tracker</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <table className="table table-success table-striped table-hover">
                          <thead>
                            <tr>
                              <th scope="col">Id</th>
                              <th scope="col">Associate Id</th>
                              <th scope="col">Associate SCount</th>

                              <th scope="col">Session Login Time</th>
                              <th scope="col">Session Logout Time</th>

                            </tr>
                          </thead>
                          <tbody>
                            {associateTracker.map((response) => {
                              return (


                                <tr>
                                  <th scope="row">{response.id}</th>
                                  <td>{response.associateid}</td>
                                  <td>{response.count}</td>

                                  <td>{response.loginTime}</td>
                                  <td>{response.logoutTime}</td>

                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col md-5" style={{ paddingLeft: 350 }}>

                <button type="button" onClick={handleAssociateLoggedIn} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associateloggedIn">
                  Associates who are Currently loggedIn
                </button>


                <div className="modal fade" id="associateloggedIn" tabindex="-1" aria-labelledby="associateloggedInLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="associateloggedInLabel">Associates who are currently logged In</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body" >
                        <table className="table table-dark table-striped" >
                          <thead>
                            <tr>
                              <th scope="col">Id</th>
                              <th scope="col">Associate ID</th>

                            </tr>
                          </thead>
                          <tbody>
                            {associateloggedIn.map((response, index) => {
                              return (


                                <tr>
                                  <th scope="row">{index + 1}</th>

                                  <td >{response.associateid}</td>


                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>




            <div className="row" style={{ paddingTop: 100 }}>
              <div className="col md-5">
                <button type="button" onClick={handleAssociateCount} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associateCountModal" data-bs-whatever="@mdo">View Registered Associate Login Count</button>


                <div className="modal fade" id="associateCountModal" tabindex="-1" aria-labelledby="associateCountModalLabel" aria-hidden="true">
                  <div className="modal-dialog modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="associateCountModalLabel">Associate Session Login Count</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <table className="table table-success table-striped table-hover">
                          <thead>
                            <tr>

                              <th scope="col">Associate Id</th>
                              <th scope="col">Associate Session Count</th>


                            </tr>
                          </thead>
                          <tbody>
                            {associateCount.map((response) => {
                              return (


                                <tr>
                                  <th scope="row">{response.associateid}</th>

                                  <td>{response.count}</td>


                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col md-5" style={{ paddingLeft: 350 }}>
                <button type="button" className="primary-btn" data-bs-toggle="modal" data-bs-target="#deleteAssociateModal" data-bs-whatever="@mdo">Delete Registered Users By AssociateId</button>


                <div className="modal fade" id="deleteAssociateModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="deleteAssociateModalLabel">Delete Registered Associate</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <form>
                          <div className="mb-3">
                            <label for="associate id" className="col-form-label">Employee Id</label>
                            <input type="number" className="form-control" id="deleteassociateid" name="deleteassociateid" onChange={handleDeleteAssociateid} value={deleteassociateid} />
                          </div>

                        </form>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>
                        <button type="button" className="btn btn-primary" onClick={handleDeleteAssociate}>Submit</button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

             






            </div>

            <div className="row" style={{ paddingTop: 100 }}>
              <div className="col md-5">
                <button type="button" onClick={handlePagesCount} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associatepagesModal" data-bs-whatever="@mdo">View Pages Count</button>


                <div className="modal fade" id="associatepagesModal" tabindex="-1" aria-labelledby="pagesCountModalLabel" aria-hidden="true">
                  <div className="modal-dialog modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="pagesCountModalLabel">View Overall Page Count</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <table className="table table-success table-striped table-hover">
                          <thead>
                            <tr>

                              {/*<th scope="col">Id</th>*/}
                              <th scope="col">Page Name</th>
                              <th scope="col">Page Count</th>


                            </tr>
                          </thead>
                          <tbody>
                            {pagesCount.map((response) => {
                              return (


                                <tr>
                                  {/*<th scope="row">{response.id}</th>*/}

                                  <td>{response.pageName}</td>
                                  <td>{response.pageCount}</td>

                                </tr>)
                            })
                            }
                          </tbody>
                        </table>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col md-5" style={{ paddingLeft: 350 }}>
                <button type="button" className="primary-btn" data-bs-toggle="modal" data-bs-target="#createPagesModal" data-bs-whatever="@mdo">Create Pages</button>


                <div className="modal fade" id="createPagesModal" tabindex="-1" aria-labelledby="createPagesLabel" aria-hidden="true">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="createPagesModalLabel">Create Pages </h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <form>
                          <div className="mb-3">
                            <label for="page name" className="col-form-label">Page Name</label>
                            <input type="text" className="form-control" id="createPageName" name="createPageName" onChange={handleCreatePage} value={createPage} />
                          </div>

                        </form>
                      </div>
                      <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>
                        <button type="button" className="btn btn-primary" onClick={handleCreatePageSubmit}>Submit</button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>








            </div>








            <center>
              <div style={{ paddingTop: 100 }}>
                <div className="col md-5">
                  <button type="button" onClick={handleAssociateNotLoggedIn} className="primary-btn" data-bs-toggle="modal" data-bs-target="#associateNotModal" data-bs-whatever="@mdo">View Asssociates who are not logged In</button>


                  <div className="modal fade" id="associateNotModal" tabindex="-1" aria-labelledby="associateNotModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-scrollable">
                      <div className="modal-content">
                        <div className="modal-header">
                          <h5 className="modal-title" id="associateNotModalLabel">Associate Who havent LoggedIn</h5>
                          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                          <table className="table table-success table-striped table-hover">
                            <thead>
                              <tr>

                                <th scope="col">Associate Id</th>
                                <th scope="col">Associate Name</th>


                              </tr>
                            </thead>
                            <tbody>
                              {nname.map((response) => {
                                return (


                                  <tr>
                                    <th scope="row">{response.associateid}</th>

                                    <td>{response.fullname}</td>


                                  </tr>)
                              })
                              }
                            </tbody>
                          </table>
                        </div>
                        <div className="modal-footer">
                          <button type="button" className="btn btn-secondary" data-bs-dismiss="modal" onClick={handleClose}>Close</button>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>


            </center>
          </div>
        </div>

       

      </div>
      
      

      <Footer />
    </>
  )
}
export default Admin;