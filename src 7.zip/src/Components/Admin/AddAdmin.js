import React, { useState, useEffect } from "react";
import axios from "axios";
import Header from "../Home/Header";
import Footer from "../Home/Footer";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Container, Table, Button } from "react-bootstrap";
import backgroundImage from "../Admin/adminblue.jpg";

const AddAdmin = () => {
  const [associates, setAssociates] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios
      .get("http://localhost:8081/associate/read")
      .then((response) => {
        setAssociates(response.data);
      })
      .catch((error) => {
        console.error("Error fetching associates:", error);
      });
  };

  const handleMakeAdmin = (associateId) => {
    axios
      .put(`http://localhost:8081/associate/${associateId}/role`, {
        role: "Admin",
      })
      .then((response) => {
        toast.success(`Associate ${associateId} is now an admin`);
        fetchData();
      })
      .catch((error) => {
        console.error("Error making associate admin:", error);
      });
  };

  const handleRemoveAdmin = (associateId) => {
    axios
      .put(`http://localhost:8081/associate/${associateId}/role`, {
        role: "Associate",
      })
      .then((response) => {
        toast.success(`Associate ${associateId} is now an associate`);
        fetchData(); //
      })
      .catch((error) => {
        console.error("Error removing admin role:", error);
      });
  };

  return (
    <div
      style={{
        backgroundImage: `url(${backgroundImage})`,
        height: "100vh",
        backgroundSize: "cover",
      }}
    >
      <Header />
      <br />
      <br />
      <div style={{ paddingBottom: "50px" }}>
        <Container className="mt-5 mb-5 shadow-lg border pb-5 rounded">
          <ToastContainer />
          <p
            className="h1 d-flex justify-content-center text-center"
            style={{ fontWeight: "bold", paddingTop: 5, color: "white" }}
          >
            ADD ADMIN
          </p>
          <Container className="pt-4">
            <Table
              striped
              bordered
              hover
              style={{
                fontFamily: "Arial, sans-serif",
                backgroundColor: "white",
                borderRadius: "10px",
              }}
            >
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Associate ID</th>
                  <th>Manager</th>
                  <th>Role</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {associates.map((associate) => (
                  <tr key={associate.id}>
                    <td>{associate.fullname}</td>
                    <td>{associate.associateid}</td>
                    <td>{associate.manager}</td>
                    <td>{associate.role}</td>
                    <td>
                      {associate.role !== "Admin" && (
                        <Button
                          variant="primary"
                          onClick={() => handleMakeAdmin(associate.associateid)}
                        >
                          Make Admin
                        </Button>
                      )}
                      {associate.role === "Admin" && (
                        <Button
                          variant="danger"
                          onClick={() =>
                            handleRemoveAdmin(associate.associateid)
                          }
                        >
                          Remove Admin
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Container>
        </Container>
        <Footer />
      </div>
    </div>
  );
};

export default AddAdmin;
