import React, { useState } from "react";
import axios from "axios";
import pic from "./adminblue.jpg";
import Header from "../Home/Header";
import Footer from "../Home/Footer";
import { Container } from "react-bootstrap";

function ImageUploadForm() {
  const [image, setImage] = useState(null);
  const [caption, setCaption] = useState("");

  const handleCaption = (e) => {
    setCaption(e.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!image || !caption) {
      window.alert("Please fill in all the fields");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("file", image);
      formData.append("caption", caption);

      await axios.post("http://localhost:8081/upload", formData);

      window.alert("Data added successfully");
      // Reset form after successful submission
      setImage(null);
      setCaption("");
    } catch (error) {
      console.error("Error during data submission:", error);
      window.alert("Failed to submit data. Please try again.");
    }
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setImage(file);
    };
    reader.readAsDataURL(file);
  };

  const containerStyle = {
    backgroundImage: `url(${pic})`,
    backgroundSize: "cover",
    height: "100vh",
    backgroundRepeat: "repeat-x",
    animation: "slide 3s linear infinite",
    backgroundAttachment: "fixed",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  };

  const inputStyle = {
    width: "100%",
    padding: "10px",
    marginBottom: "15px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    boxSizing: "border-box",
    fontSize: "16px",
  };

  const labelStyle = {
    fontWeight: "bold",
    color: "white",
    fontSize: "16px",
  };

  return (
    <div>
      <div style={containerStyle}>
        <Header />
        <Container className="mt-5 mb-5 shadow-lg border pb-5 rounded">
          <p
            className="h1 d-flex justify-content-center text-center"
            style={{ fontWeight: "bold", paddingTop: 5, color: "white" }}
          >
            ADD WHAT'S NEW
          </p>
          <form onSubmit={handleSubmit}>
            <div>
              <label htmlFor="caption" style={labelStyle}>
                Description URL:
              </label>
              <input
                type="text"
                id="caption"
                placeholder="Enter the URL"
                name="caption"
                value={caption}
                style={inputStyle}
                onChange={handleCaption}
              />
            </div>

            <div>
              <label htmlFor="image" style={labelStyle}>
                Image:
              </label>
              <input
                type="file"
                id="image"
                accept="image/*"
                name="image"
                style={inputStyle}
                onChange={handleImageChange}
              />
            </div>
            <center>
              <button className="btn btn-success">Submit</button>
            </center>
          </form>
        </Container>
      </div>
      <Footer />
    </div>
  );
}

export default ImageUploadForm;
