function LastSeen()
{
    return(

        <center>
        <h1>PlayBook Content</h1>
        </center>
    )
}
export default LastSeen;