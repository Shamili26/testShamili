import Header from '../../Components/Home/Header';
import Signup from './Signup';
import Footer from  '../../Components/Home/Footer';
import blue from './blue.jpg';
import './Signup.css'
import pic from './adminblue.jpg'

function Registration()
{
return(
    <>
    <div >
    <Header/>
    <Signup/>
    <Footer/>
    </div> 
    </>
)
}

export default Registration;