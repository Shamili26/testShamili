import React, { Component, useEffect, useState } from 'react'
import pic from './grey.jpg'
import axios from 'axios';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './Signup.css'
import './Signup.css'
import user from './register.jpg'

import { Link, useNavigate } from 'react-router-dom'

export default function SignupPage() {
  const navigate = useNavigate();

  const [manager, setManager] = useState("")
  const [associateid, setAssociateId] = useState("")

  const [fullname, setFullName] = useState("");

  const [password, setPassword] = useState("");
  const [rpassword, setRpassword] = useState("");

  const [passerror, setPassError] = useState("");
  const [rpasserror, setRpassError] = useState("");

  const [isPresent, setStatus] = useState(false)




  const handleName = (e) => {
    setFullName(e.target.value);
  }






  const uservalue = (event) => {
    let n = event.target.name;
    let v = event.target.value;
    let pErr = ""
    let eErr = ""
    let paErr = ""
    let rErr = ""

    if (n === "associateid") {
      setAssociateId(v);





    }
    if (n === "manager") {
      setManager(v);
    }
    if (n === "password") {
      setPassword(v);
      if (v !== "" && v.toString().length < 8) {
        paErr = <strong style={{ color: 'red' }}>Enter valid password with atleast 8 characters</strong>;
      }



    }
    if (n === "rpassword") {
      setRpassword(v);
      let p1 = document.getElementById("signup_pass").value;
      if (v !== "" && p1 !== v) {
        rErr = <strong style={{ color: 'red' }}>Not matching with the password</strong>
      }
      else if (p1 === v) {
        rErr = <strong style={{ color: "green" }}>Password Matching</strong>
      }



    }


    setPassError(paErr);
    setRpassError(rErr);

  }

  const handleRegistration = (e) => {
    e.preventDefault();
    const associate = { password, associateid, fullname, manager };

    console.log(associate);
    axios.get("http://localhost:8081/laoffshoredl/exists/" + associateid).then((response) => {
      if (response.data == true) {
        console.log(response.data);
        fetch("http://localhost:8081/associate/exists/" + associateid).then(res => res.json()).then((result) => {
          if (result == false) {
            fetch("http://localhost:8081/associate/add", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(associate)
            }).then(() => {
              setStatus(true);
              alert("Associate Registered")
            })
            navigate("/login")
          }
          else {
            setStatus(false);
            alert("Associate already There")
          }
        }
        )

      }
      else {
        setStatus(false);
        alert("Associate not present in LA Offshore DL")
      }
    })





    setPassword("");
    setRpassword("");
    setFullName("");
    setAssociateId("");
    setManager("");
    setRpassError("");


    console.log("Hi");
  }
  return (
    <>
      <form onSubmit={handleRegistration}>

        <div className="container signup shadow-lg rounded" style={{ backgroundColor: 'black', opacity: '0.8' }}>
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-lg-12 col-xl-11" >
              <div className="card text-black" >
                <div className="card-body p-md-5 rounded" style={{ backgroundColor: "#F0F6F7", backgroundImage: `url(${pic})`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center' }}>
                  <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                      <p className=" h1 fw-bold mb-5 mx-1 mx-md-4 mt-4 text-center "><h1 className="jsx-2391468037 title" style={{ color: 'black' }}>Sign up</h1></p>

                      <div className="d-flex flex-row align-items-center mb-4">
                        <i className="fas fa-user fa-lg me-3 fa-fw"></i>
                        <div className="form-outline flex-fill mb-0">
                          <label className="form-label" style={{ fontWeight: 'bold' }} for="signup_name">Name</label>
                          <input type="text" id="signup_name" name="username" className="form-control" onChange={handleName} value={fullname} placeholder="Enter your full name" required />

                        </div>
                      </div>



                      <div className="d-flex flex-row align-items-center mb-4">
                        <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
                        <div className="form-outline flex-fill mb-0">
                          <label className="form-label" style={{ fontWeight: 'bold' }} for="signup_email">Associate Id</label>
                          <input type="number" name="associateid" className="form-control" onChange={uservalue} value={associateid} placeholder="Enter your associate id" required />

                        </div>
                      </div>

                      <div className="d-flex flex-row align-items-center mb-4">
                        <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
                        <div className="form-outline flex-fill mb-0">
                          <label className="form-label" style={{ fontWeight: 'bold' }} for="signup_email">Manager Name</label>
                          <input type="text" name="manager" className="form-control" onChange={uservalue} value={manager} placeholder="Enter your manager name" required />

                        </div>
                      </div>

                      <div className="d-flex flex-row align-items-center mb-4">
                        <i className="fas fa-lock fa-lg me-3 fa-fw"></i>
                        <div className="form-outline flex-fill mb-0">
                          <label className="form-label" style={{ fontWeight: 'bold' }} for="signup_pass">Password</label>
                          <input type="password" name="password" id="signup_pass" className="form-control" onChange={uservalue} value={password} placeholder="Enter password" required /> {passerror}

                        </div>
                      </div>

                      <div className="d-flex flex-row align-items-center mb-4">
                        <i className="fas fa-key fa-lg me-3 fa-fw"></i>
                        <div className="form-outline flex-fill mb-0">
                          <label className="form-label" style={{ fontWeight: 'bold' }} for="signup_cpass">Confirm password</label>
                          <input type="password" id="signup_cpass" name="rpassword" onChange={uservalue} value={rpassword} className="form-control" placeholder="Confirm Password" required />{rpasserror}

                        </div>
                      </div>

                      <center><div className="justify-content-center mx-4 mb-3 mb-lg-4">
                        <button style={{ fontWeight: 'bold' }} type="submit" className="btn btn-outline-dark btn-lg mb-2"  >Submit</button>
                        <span style={{ fontWeight: 'bold' }} className="d-block" ><p>Already a member?<Link to="/login">  Login </Link></p> </span>

                      </div>
                      </center>

                    </div>

                    <div className="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                      <img src={user} className="img-fluid" style={{ borderRadius: '50%' }} alt="Sample image" />

                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </form>

    </>
  )
}

