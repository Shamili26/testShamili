import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, Navigate, useNavigate } from "react-router-dom";
import "./OrgChart.css";
import Header from "../Home/Header";
import { Tree, TreeNode } from "react-organizational-chart";
import Footer from "../Home/Footer";

export default function BasicOrgChart() {
  const [value, setValue] = useState([]);
  const [len, setlen] = useState();
  const [hname, setHname] = useState("");
  const [oname, setoname] = useState("");
  useEffect(() => {
    axios
      .get("http://localhost:8081/orgchart/" + localStorage.getItem("username"))
      .then((response) => {
        setValue(response.data.reverse());
        console.log(response.data);
        setlen(response.data.length);
      });

    axios
      .put("http://localhost:8081/pages/put/OrgChart")
      .then((response) => {});
  }, []);
  const [reportee, setReportee] = useState([]);
  const [emp, setemp] = useState(false);
  const navigate = useNavigate();
  const handleClick = (e) => {
    setoname(e.target.value);
    axios
      .get("http://localhost:8081/follow/" + e.target.value)
      .then((response) => {
        setReportee(response.data);
        console.log(reportee);
        if (response.data.length === 0) {
          setemp(true);
          console.log(oname);
        } else {
          setemp(false);
        }
      });
  };

  return (
    <>
      <Header />
      <div
        className="container"
        style={{ paddingTop: 100, paddingBottom: 100 }}
      >
        <div className="mast" style={{ padding: 50 }}>
          <center>
            <h1 className="jsx-2391468037 title" style={{ color: "white" }}>
              Organizational Chart <span className="d-lg-block"></span>
            </h1>
          </center>
          <div style={{ padding: 50 }}>
            {value.map((response, index) => {
              if (index === len - 1) {
                return (
                  <>
                    <center>
                      <button
                        type="button"
                        className="box btn"
                        data-bs-toggle="modal"
                        data-bs-target="#associate"
                        value={response}
                        onClick={handleClick}
                      >
                        {response}
                      </button>
                      <br></br>
                    </center>
                  </>
                );
              } else {
                return (
                  <center>
                    <button
                      className="box btn"
                      data-bs-toggle="modal"
                      data-bs-target="#associate"
                      value={response}
                      onClick={handleClick}
                    >
                      {response}
                    </button>
                    <br></br>
                    <br></br> <i className="arrow down"></i>
                    <br></br>
                  </center>
                );
              }
            })}
          </div>
        </div>
        <div
          className="modal fade"
          id="associate"
          tabindex="-1"
          aria-labelledby="associateLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="associateLabel">
                  {oname} Reportees
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div>
                {emp && (
                  <div className="modal-body">
                    <h2> No Reportees present for {oname}</h2>
                  </div>
                )}
                {!emp && (
                  <div className="modal-body">
                    <Tree
                      lineWidth={"2px"}
                      lineColor={"green"}
                      lineBorderRadius={"10px"}
                      label={<div className="node">{oname}</div>}
                    >
                      {reportee.map((response) => {
                        return (
                          <TreeNode
                            label={
                              <div className="node">{response.fullname}</div>
                            }
                          ></TreeNode>
                        );
                      })}
                    </Tree>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
