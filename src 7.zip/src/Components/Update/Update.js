import React, { useState } from "react";
import Header from "../Home/Header";
import backgroundImage from "../Admin/adminblue.jpg";
import { ToastContainer } from "react-toastify";
import { Container } from "react-bootstrap";
import Footer from "../Home/Footer";
import axios from "axios";

const Update = () => {
  const [formData, setFormData] = useState({
    fullname: "",
    manager: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Assuming the endpoint is '/associates/{associateId}'

    const associateId = formData.employeeId; // Change this to match your API endpoint
    axios
      .put(`/put/${associateId}`, formData)
      .then((response) => {
        // Handle success
        console.log("Profile updated successfully:", response.data);
      })
      .catch((error) => {
        // Handle error
        console.error("Error updating profile:", error);
      });
  };

  return (
    <>
      <div
        style={{
          backgroundImage: `url(${backgroundImage})`,

          height: "100vh",

          backgroundSize: "cover",
        }}
      >
        <Header />

        <br />

        <br />

        <div style={{ paddingBottom: "50px" }}>
          <Container className="mt-5 mb-5 shadow-lg border pb-5 rounded">
            <ToastContainer />

            <p
              className="h1 d-flex justify-content-center text-center"
              style={{ fontWeight: "bold", paddingTop: 5, color: "white" }}
            >
              UPDATE PROFILE
            </p>

            <Container className="pt-4">
              <form className="row g-3" onSubmit={handleSubmit}>
                <div className="col-md-6">
                  <label htmlFor="fullname" className="form-label">
                    <b style={{ color: "white" }}>Full Name</b>
                  </label>

                  <input
                    type="text"
                    name="fullname"
                    className="form-control"
                    id="fullname"
                    placeholder="Enter Your Name"
                    value={formData.fullname}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6">
                  <label htmlFor="manager" className="form-label">
                    <b style={{ color: "white" }}>MANAGER</b>
                  </label>

                  <input
                    type="text"
                    name="manager"
                    className="form-control"
                    id="manager"
                    placeholder="Enter Your Manager Name"
                    value={formData.manager}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-6">
                  <label htmlFor="password" className="form-label">
                    <b style={{ color: "white" }}>Password</b>
                  </label>

                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    id="password"
                    placeholder="Enter Your Password"
                    value={formData.password}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-12">
                  <br />

                  <br />

                  <center>
                    <button type="submit" className="btn btn-success">
                      Submit
                    </button>
                  </center>
                </div>
              </form>
            </Container>
          </Container>

          <Footer />
        </div>
      </div>
    </>
  );
};

export default Update;
