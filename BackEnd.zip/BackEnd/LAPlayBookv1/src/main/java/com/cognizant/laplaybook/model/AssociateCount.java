package com.cognizant.laplaybook.model;

import org.springframework.stereotype.Component;

@Component
public class AssociateCount implements Comparable {
	
	
	private int associateid;
	private int count;
	public AssociateCount() {
		super();

	}
	public AssociateCount(int associateid, int count) {
		super();
		this.associateid = associateid;
		this.count = count;
	}
	public int getAssociateid() {
		return associateid;
	}
	public void setAssociateid(int associateid) {
		this.associateid = associateid;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	

	
	@Override
	public int compareTo(Object o) {

		 int count=((AssociateCount)o).getCount();
	        
	        return count-this.count;
	}
	

}
