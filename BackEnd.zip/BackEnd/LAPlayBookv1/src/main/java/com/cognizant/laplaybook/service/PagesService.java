package com.cognizant.laplaybook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.laplaybook.model.Pages;
import com.cognizant.laplaybook.repository.PagesRepository;

@Service
public class PagesService {

	@Autowired
	private PagesRepository pagesRepository;

	public Pages createPages(String pageName) {

		Pages page=new Pages(pageName,0);
		return pagesRepository.save(page);
	}

	public List<Pages> getPages() {

		return pagesRepository.findAll();
	}

	public void updateCount(String pageName) {

		Pages page = pagesRepository.findByPageName(pageName);
		System.out.println(page.toString());
		int pageCount = page.getPageCount() +1;
		System.out.println(pageCount);
		pagesRepository.updateCount(pageCount, page.getId());

	}

}
