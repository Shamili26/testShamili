package com.cognizant.laplaybook.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.laplaybook.model.Associate;
import com.cognizant.laplaybook.repository.AssociateRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {
	
	@Autowired
	private AssociateRepository associateRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
		Associate associate = associateRepository.findByAssociateid(Integer.parseInt(username));
		
		return new org.springframework.security.core.userdetails.User(associate.getUsername(),associate.getPassword(), new ArrayList<>());
	}

	

}
