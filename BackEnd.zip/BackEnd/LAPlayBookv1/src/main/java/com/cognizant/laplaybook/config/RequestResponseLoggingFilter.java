package com.cognizant.laplaybook.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(1)
public class RequestResponseLoggingFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        // Log the request payload (if needed)
        // You can access request data using request.getInputStream() or request.getReader()

        // Proceed with the request
        filterChain.doFilter(request, response);

        // Log the response payload (if needed)
        // You can access response data using response.getOutputStream()
    }
}
