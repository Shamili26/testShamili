package com.cognizant.laplaybook;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
 
@SpringBootApplication
@ComponentScan(basePackages = "com.cognizant.laplaybook")
public class LAPlayBook {
 
    public static void main(String[] args) {
        SpringApplication.run(LAPlayBook.class, args);
    }
}