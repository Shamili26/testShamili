package com.cognizant.laplaybook.model;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


@Entity
@Table(name = "associate")
public class Associate implements UserDetails {
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
	
	private String fullname;
	
	private int associateid;
	
	private String manager;
	
	private String password;
	
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Associate() {
		super();
	}

//	public Associate(int id, String fullname, int associateid, String manager, String password) {
//		super();
//		this.id = id;
//		this.fullname = fullname;
//		this.associateid = associateid;
//		this.manager = manager;
//		this.password = password;
//	}

	public Associate(int id, String fullname, int associateid, String manager, String password, String role) {
		super();
		this.id = id;
		this.fullname = fullname;
		this.associateid = associateid;
		this.manager = manager;
		this.password = password;
		this.role = role;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getAssociateid() {
		return associateid;
	}

	public void setAssociateid(int associateid) {
		this.associateid = associateid;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {

		return null;
	}

	@Override
	public String getUsername() {

		return String.valueOf(this.associateid);
	}

	@Override
	public boolean isAccountNonExpired() {

		return false;
	}

	@Override
	public boolean isAccountNonLocked() {

		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {

		return false;
	}

	@Override
	public boolean isEnabled() {

		return false;
	}
	
	

	
	

	
    

}
