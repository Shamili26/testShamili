package com.cognizant.laplaybook.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.laplaybook.model.LAOffshoreDL;
import com.cognizant.laplaybook.repository.LAOffshoreDLRepository;
@Service
public class LAOffshoreDLService {
	
	@Autowired
	private LAOffshoreDLRepository laoffshoredlrepository;

	public LAOffshoreDL findByAssociateid(int associateid) {
		return laoffshoredlrepository.findByAssociateid(associateid);
	}

	public LAOffshoreDL createAssociate(LAOffshoreDL laoffshoredl) {
		
		return laoffshoredlrepository.save(laoffshoredl);
		
	}

	public List<LAOffshoreDL> readAssociate() {
		// TODO Auto-generated method stub
		return laoffshoredlrepository.findAll();
	}

	public void deleteAssociate(int associateid) {
		// TODO Auto-generated method stub
		laoffshoredlrepository.deleteByAssociateid(associateid);
	}

}
