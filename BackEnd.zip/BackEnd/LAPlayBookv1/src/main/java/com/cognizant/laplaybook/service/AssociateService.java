package com.cognizant.laplaybook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.cognizant.laplaybook.model.Associate;
import com.cognizant.laplaybook.repository.AssociateRepository;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@Service
public class AssociateService {
	
	@Autowired
	private AssociateRepository associateRepository;

	public String addAssociate(Associate associate) {
        associateRepository.save(associate);
        return associate.getFullname();
		
	}

	public Associate findByFullname(String fullname) {

		return associateRepository.findByFullname(fullname);
	}

	public List<Associate> findByManager(String manager) {

		return associateRepository.findByManager(manager);
	}

	public  Associate findByAssociateid(int associateid) {

		return associateRepository.findByAssociateid(associateid);
	}

	public List<Associate> readAssociates() {

		return associateRepository.findAll();
	}

	public void deleteById(int associateid) {

		associateRepository.deleteByAssociateid(associateid);
	}
	
	public void updateAssociateRole(int associateid, String role) {
		Associate associate=associateRepository.findByAssociateid(associateid);
		associate.setRole(role);
		associateRepository.save(associate);
	}

	 
    @Autowired
    public AssociateService(AssociateRepository associateRepository) {
        this.associateRepository = associateRepository;
    }
 
    public Associate updateAssociate(int associateId, Associate updatedAssociate) {
        Associate existingAssociate = associateRepository.findById(associateId).orElse(null);
        if (existingAssociate != null) {
            existingAssociate.setFullname(updatedAssociate.getFullname());
            existingAssociate.setManager(updatedAssociate.getManager());
            existingAssociate.setPassword(updatedAssociate.getPassword());
            return associateRepository.save(existingAssociate);
        }
        return null; // or throw an exception if the associate with given ID doesn't exist
    }
}


