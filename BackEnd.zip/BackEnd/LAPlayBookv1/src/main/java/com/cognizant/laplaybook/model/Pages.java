package com.cognizant.laplaybook.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pages")
public class Pages implements Comparable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
	
	@Column(unique=true)
	private String pageName;

	private int pageCount;

	public Pages() {
		super();

	}
	
	
	public Pages(String pageName, int pageCount) {
		super();
		this.pageName = pageName;
		this.pageCount = pageCount;
	}


	public Pages(String pageName) {
		super();
		this.pageName = pageName;
	}


	public Pages(int id, String pageName, int pageCount) {
		super();
		this.id = id;
		this.pageName = pageName;
		this.pageCount = pageCount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	@Override
	public String toString() {
		return "Pages [id=" + id + ", pageName=" + pageName + ", pageCount=" + pageCount + "]";
	}
	
	@Override
	public int compareTo(Object o) {

		 int pageCount=((Pages)o).getPageCount();
	        
	        return pageCount-this.pageCount;
	}
	

}
