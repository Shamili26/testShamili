package com.cognizant.laplaybook.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.laplaybook.model.Associate;
import com.cognizant.laplaybook.model.AssociateCount;
import com.cognizant.laplaybook.model.AssociateTracker;
import com.cognizant.laplaybook.repository.AssociateRepository;
import com.cognizant.laplaybook.repository.AssociateTrackerRepository;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class AssociateTrackerController {
	
	@Autowired
	private AssociateTrackerRepository associateTrackerRepository;
	
	@Autowired
	private AssociateRepository associateRepository;
	
	
	
	@GetMapping("/associateTracker/getAll")
	public List<AssociateTracker> getAll()
	{
		
		return associateTrackerRepository.findAll();
		
	}
	
	@GetMapping("/associateTracker/loggedIn")
	public List<AssociateTracker> getLoggedInAssociates(){
		return associateTrackerRepository.findByLoggedInState(true);
	}
	
	
	@GetMapping("/associateTracker/associateCount")
	public ArrayList<AssociateCount> getAssociateCount()
	{
	   List<AssociateTracker> list= associateTrackerRepository.findAll();
	   ArrayList<AssociateCount> result = new ArrayList<>();
	   TreeSet<Integer> val=new TreeSet<>();
	   for(AssociateTracker aa: list)
	   {
		   val.add(aa.getAssociateid());
	   }
	   for(Integer bb: val)
	   {
		   int max=0;
		for(AssociateTracker cc:list)
		{
			
			if(cc.getAssociateid()==bb)
			{
				if(cc.getCount()>max)
				{
					max=cc.getCount();
				}
			}
		}
		result.add(new AssociateCount(bb,max));
	
	   }
	   Collections.sort(result);
		return result;
	}
	
	@GetMapping("/associateTracker/not")
	public List<Associate> getAssociateNotLoggedIn()
	{
		 Set<Integer> associatesLoggedIn = new HashSet<>();
		 List<AssociateTracker> list= associateTrackerRepository.findAll();
		 List<Associate> notLoggedIn = new ArrayList<>();
		 for(AssociateTracker aa:list)
		 {
			 associatesLoggedIn.add(aa.getAssociateid());
		 }
		 List<Associate> associateList = associateRepository.findAll();
		 for(Associate bb: associateList)
		 {
			 int count=0;
			 for(Integer id:associatesLoggedIn)
			 {
				 if(id==bb.getAssociateid())
				 {
					 count++;
				 }
			 }
			 if(count==0)
			 {
				 notLoggedIn.add(associateRepository.findByAssociateid(bb.getAssociateid()));
			 }
		 }
		 return notLoggedIn;
 		
	}
	
}
