package com.cognizant.laplaybook.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.laplaybook.model.LAOffshoreDL;

@Repository
@Transactional
public interface LAOffshoreDLRepository extends JpaRepository<LAOffshoreDL,Integer> {

	LAOffshoreDL findByAssociateid(int associateid);

	void deleteByAssociateid(int associateid);

}
