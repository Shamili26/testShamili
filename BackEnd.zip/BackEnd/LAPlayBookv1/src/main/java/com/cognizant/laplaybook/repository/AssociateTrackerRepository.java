package com.cognizant.laplaybook.repository;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.laplaybook.model.AssociateTracker;

@Repository
public interface AssociateTrackerRepository extends JpaRepository<AssociateTracker, Integer> {

	List<AssociateTracker> findByAssociateid(int associateid);

	@Transactional
	@Modifying
	@Query("UPDATE AssociateTracker SET logoutTime =:logoutTime  WHERE id = :id")
	void updateLogout(int id, LocalDateTime logoutTime);

	
	@Transactional
	@Modifying
	@Query("UPDATE AssociateTracker SET loggedInState =:loggedInState  WHERE id = :id")
	void updateLoginState(int id, boolean loggedInState);

	List<AssociateTracker> findByLoggedInState(boolean b);

}
