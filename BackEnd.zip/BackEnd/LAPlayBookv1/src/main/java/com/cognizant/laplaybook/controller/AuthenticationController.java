package com.cognizant.laplaybook.controller;
 
import com.cognizant.laplaybook.model.Associate;
import com.cognizant.laplaybook.model.AssociateTracker;
import com.cognizant.laplaybook.repository.AssociateRepository;
import com.cognizant.laplaybook.repository.AssociateTrackerRepository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class AuthenticationController {
 
    @Autowired
    private AssociateRepository associateRepository;
    @Autowired
	private AssociateTrackerRepository associateTrackerRepository;

 
    @PostMapping("/authenticate/custom-login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
    	//int result=0;
        Associate associate = associateRepository.findByAssociateid(loginRequest.getAssociateid());
        if (associate == null || !associate.getPassword().equals(loginRequest.getPassword())) {
            throw new BadCredentialsException("Invalid associate ID or password");
        }
 
//        if (associateTrackerRepository.findByAssociateid(associate.getAssociateid()) == null) {
//			result=1;
//			associateTrackerRepository
//					.save(new AssociateTracker(associate.getAssociateid(), result, LocalDateTime.now(), null,true));
//		} else {
//			List<AssociateTracker> list = associateTrackerRepository.findByAssociateid(associate.getAssociateid());
//			int max = 0;
//			for (AssociateTracker aa : list) {
//				if (aa.getCount() > max) {
//					max = aa.getCount();
//				}
//			}
//			result=max+1;
//			associateTrackerRepository
//					.save(new AssociateTracker(associate.getAssociateid(), result, LocalDateTime.now(), null,true));
//
//		}
	
        return ResponseEntity.ok(new LoginResponse(associate.getRole()));
    }
 
    static class LoginRequest {
        private int associateid;
        private String password;
		public int getAssociateid() {
			return associateid;
		}
		public void setAssociateid(int associateid) {
			this.associateid = associateid;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
 
    }
 
    static class LoginResponse {
        private String role;
 
        public LoginResponse(String role) {
            this.role = role;
        }

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}
 
        
    }
}