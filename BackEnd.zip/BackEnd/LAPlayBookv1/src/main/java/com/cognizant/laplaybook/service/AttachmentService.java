package com.cognizant.laplaybook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.laplaybook.model.Attachment;
import com.cognizant.laplaybook.repository.AttachmentRepository;

@Service
public class AttachmentService {
	
	@Autowired
	private AttachmentRepository attachmentRepository;

	public Attachment saveAttachment(MultipartFile file, String caption) throws Exception {

		String fileName=StringUtils.cleanPath(file.getOriginalFilename());
		try {
			if(fileName.contains(".."))
			{
				throw new Exception("Filename contains invalid path sequence " +fileName);
			}
			Attachment attachment = new Attachment(fileName,file.getContentType(),file.getBytes(),caption);
			return attachmentRepository.save(attachment);
		}
		catch(Exception e)
		{
			throw new Exception("Could not save Files: "+fileName);
		}		
	}

	public Attachment getAttachment(String fileId) throws Exception {

		return attachmentRepository.findById(fileId)
				.orElseThrow(
						()-> new Exception("File not found with Id: "+fileId));
	}

	public List<Attachment> getAllFiles() {

		return attachmentRepository.findAll();
	}

}
