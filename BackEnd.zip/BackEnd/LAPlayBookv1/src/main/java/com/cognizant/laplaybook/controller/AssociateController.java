package com.cognizant.laplaybook.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.laplaybook.model.Associate;
import com.cognizant.laplaybook.model.AssociateTracker;
import com.cognizant.laplaybook.repository.AssociateTrackerRepository;
import com.cognizant.laplaybook.service.AssociateService;
import com.cognizant.laplaybook.service.MyUserDetailsService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class AssociateController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private MyUserDetailsService userDetailsService;

	@Autowired
	private AssociateTrackerRepository associateTrackerRepository;

	@Autowired
	private AssociateService associateService;

	@PostMapping(path = "/associate/add")
	public String saveEmployee(@RequestBody Associate associate) {
		return associateService.addAssociate(associate);

	}

	@GetMapping("/associate/exists/{associateid}")
	public boolean getById(@PathVariable("associateid") int associateid) {
		Associate result = associateService.findByAssociateid(associateid);
		if (result == null) {
			return false;
		} else {
			return true;
		}
	}

	@GetMapping("/associate/read")
	public List<Associate> readAssociate() {
		return associateService.readAssociates();
	}

	@GetMapping("/{fullname}")
	public Associate getById(@PathVariable("fullname") String fullname) {
		return associateService.findByFullname(fullname);
	}

	@GetMapping("/follow/{fullname}")
	public List<Associate> getByFollow(@PathVariable("fullname") String fullname) {
		return associateService.findByManager(fullname);
	}

	@PostMapping("/authenticate/login")
	public int validateLogin(@RequestBody Associate associate) throws Exception {
		int result=0;
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(associate.getAssociateid(), associate.getPassword()));
		} catch (BadCredentialsException e) {
			throw new Exception("Incorrect associateid or password", e);
		}

		final UserDetails userDetails = userDetailsService.loadUserByUsername(associate.getUsername());
		if (associateTrackerRepository.findByAssociateid(associate.getAssociateid()) == null) {
			result=1;
			associateTrackerRepository
					.save(new AssociateTracker(associate.getAssociateid(), result, LocalDateTime.now(), null,true));
		} else {
			List<AssociateTracker> list = associateTrackerRepository.findByAssociateid(associate.getAssociateid());
			int max = 0;
			for (AssociateTracker aa : list) {
				if (aa.getCount() > max) {
					max = aa.getCount();
				}
			}
			result=max+1;
			associateTrackerRepository
					.save(new AssociateTracker(associate.getAssociateid(), result, LocalDateTime.now(), null,true));

		}
	
		return result;
	}
	
	@GetMapping("/logout/{associateid}/{count}")
	public void logout(@PathVariable("associateid") int associateid,@PathVariable("count")int count)
	{
		List<AssociateTracker> list = associateTrackerRepository.findByAssociateid(associateid);
		
		AssociateTracker maxTracker=null;
		for (AssociateTracker aa : list) {
			if(aa.getAssociateid()==associateid && aa.getCount()==count)
			{
				maxTracker=aa;
			}
		}
		associateTrackerRepository.updateLogout(maxTracker.getId(),LocalDateTime.now());
		associateTrackerRepository.updateLoginState(maxTracker.getId(),false);
		
		
	}

	@GetMapping("/orgchart/{associateid}")
	public List<String> orgChart(@PathVariable("associateid") int associateid) {
		List<String> list = new ArrayList<>();
		String name = findByAssociateid(associateid).getFullname();
		list.add(name);

		Associate associate;
		while (name != null) {
			associate = getManager(associateid);
			name = associate.getManager();
			if (name != null) {
				list.add(name);
				System.out.println(list);
			}
			if (associateService.findByFullname(name) == null) {
				break;
			} else {
				associateid = associateService.findByFullname(name).getAssociateid();
			}
		}
		return list;
	}

	public Associate getManager(int associateid) {
		System.out.println(associateid);
		Associate associate = associateService.findByAssociateid(associateid);
		System.out.println(associate.toString());
		return associate;

	}

	@GetMapping("/associate/{associateid}")
	public Associate findByAssociateid(@PathVariable("associateid") int associateid) {
		return associateService.findByAssociateid(associateid);
	}
	
	@DeleteMapping("/associate/delete/{associateid}")
	public void deletebyId(@PathVariable("associateid") int associateid)
	{
		associateService.deleteById(associateid);
	}
	
	@PutMapping("/associate/{associateid}/role")
	public void updateAssociateRole(@PathVariable("associateid")int associateid, @RequestBody Map<String,String> roleMap) {
		String role=roleMap.get("role");
		associateService.updateAssociateRole(associateid, role);
	}

	@PostMapping("/post")
	public void postAll(@RequestBody String name1) {
		
		System.out.println(name1+" ");
	}
	@Autowired
    public AssociateController(AssociateService associateService) {
        this.associateService = associateService;
    }
 
    @PutMapping("/put/{associateId}")
    public ResponseEntity<Associate> updateAssociate(@PathVariable int associateId, @RequestBody Associate updatedAssociate) {
        Associate associate = associateService.updateAssociate(associateId, updatedAssociate);
        if (associate != null) {
            return new ResponseEntity<>(associate, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
