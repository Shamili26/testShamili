package com.cognizant.laplaybook.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="laoffshoredl")
public class LAOffshoreDL {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
  
	private int id;
	
	@Column(unique=true)
	private int associateid;
	
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAssociateid() {
		return associateid;
	}

	public void setAssociateid(int associateid) {
		this.associateid = associateid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LAOffshoreDL() {
		super();
		
	}

	public LAOffshoreDL(int id, int associateid, String name) {
		super();
		this.id = id;
		this.associateid = associateid;
		this.name = name;
	}
	
	

}
