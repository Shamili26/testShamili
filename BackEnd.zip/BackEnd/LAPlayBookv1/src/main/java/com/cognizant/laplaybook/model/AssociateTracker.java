package com.cognizant.laplaybook.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "associatetracker")
public class AssociateTracker {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
	
	private int associateid;
	
	private int count;
	
	private LocalDateTime loginTime;
	
	private LocalDateTime logoutTime;
	
	private boolean loggedInState;

	public AssociateTracker() {
		super();
	}

	

	public AssociateTracker(int associateid, int count, LocalDateTime loginTime, LocalDateTime logoutTime,
			boolean loggedInState) {
		super();
		this.associateid = associateid;
		this.count = count;
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.loggedInState = loggedInState;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAssociateid() {
		return associateid;
	}

	public void setAssociateid(int associateid) {
		this.associateid = associateid;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public LocalDateTime getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(LocalDateTime loginTime) {
		this.loginTime = loginTime;
	}

	public LocalDateTime getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(LocalDateTime logoutTime) {
		this.logoutTime = logoutTime;
	}
	
	
}
