package com.cognizant.laplaybook.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.laplaybook.model.AssociateCount;
import com.cognizant.laplaybook.model.AssociateTracker;
import com.cognizant.laplaybook.model.Pages;
import com.cognizant.laplaybook.service.PagesService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class PagesController {
	
	@Autowired
	private PagesService pagesService;
	
	@PostMapping("/pages/create/{pageName}")
	public Pages createPages(@PathVariable("pageName") String pageName)
	{
		return pagesService.createPages(pageName);
	}
	
	@GetMapping("/pages/get")
	public ArrayList<Pages> getPages()
	{
		List<Pages> list=pagesService.getPages();
		  ArrayList<Pages> result = new ArrayList<>();
		   TreeSet<String> val=new TreeSet<>();
		   for(Pages aa: list)
		   {
			   val.add(aa.getPageName());
		   }
		   for(String bb: val)
		   {
			   int max=0;
			for(Pages cc:list)
			{
				
				if(cc.getPageName()==bb)
				{
					if(cc.getPageCount()>max)
					{
						max=cc.getPageCount();
					}
				}
			}
			result.add(new Pages(bb,max));
		
		   }
		   Collections.sort(result);
		   
			return result;
	}
	
	@PutMapping("/pages/put/{pageName}")
	public void updatePages(@PathVariable("pageName") String pageName)
	{
		pagesService.updateCount(pageName);
	}
	
	

	
	
	
}
